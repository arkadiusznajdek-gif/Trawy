# Kontekst: Szkółka traw ozdobnych — aplikacja

Prowadzę od kilkunastu lat prawdziwą szkółkę traw ozdobnych. Budujemy razem
aplikację do jej zarządzania, docelowo z ambicją przekształcenia w SaaS dla
wielu szkółek. **Załączam zip projektu z poprzedniej rozmowy — to jest aktualny
stan kodu, przeczytaj go zamiast zakładać cokolwiek z tego podsumowania.**

## Co to za projekt
Aplikacja React (Vite), plik startowy `src/App.jsx`, katalog roślin
(26 prawdziwych odmian traw z moich danych, nie demo) w `src/data/plants.js`.
Struktura modułowa: `src/components/{layout,pulpit,shared,magazyn,harmonogram,
sprzedaz,etykiety}`, `src/utils/{helpers,storage,batches}.js`, `src/constants.js`,
`src/styles/GlobalStyle.jsx`. Do tego `public/` z manifestem PWA i service
workerem (dodane, żeby dało się zainstalować jako appkę na telefonie).

## Status wdrożenia — WAŻNE
**Aplikacja NIE jest jeszcze wystawiona na żadnym serwerze.** Testujemy ją
wyłącznie przez podgląd artefaktu w czacie Claude, który okazał się zawodny do
testowania trwałości danych (podejrzenie: każda nowa wersja pliku dostaje
osobną, izolowaną pamięć — dane "znikały" nie z powodu błędu w kodzie, tylko
natury tego podglądu). Ustalony plan: wystawić przez GitHub + Netlify (Netlify
samo buduje z repo, edycja plików możliwa z telefonu przez github.com), na razie
nie wykonany — czeka na dostęp do komputera na start.

**Dopiero po wdrożeniu na Netlify dane będą trwałe** (localStorage przeglądarki,
`utils/storage.js` ma już gotowy fallback na wypadek braku `window.storage`).

## Kluczowe zaimplementowane funkcje
- Magazyn: rośliny, podział, zaopatrzenie (materiały), straty, historia, koszty stałe
- Zaopatrzenie: rozmiary pojemników wynikają z materiałów oznaczonych `typ: "donica"`
  (pole `rozmiar`) — nie ma już osobnej listy rozmiarów; Receptura pojemników
  automatycznie dostaje wiersz dla każdego nowego rozmiaru
- Kalkulator nasadzeń (`shared/PlantingCalculator.jsx`): sugeruje ilość sztuk
  z gęstości nasadzeń (pola `gestosc_*` w danych roślin, sparsowane z mojego
  arkusza), tryb metry bieżące / m², z możliwością ręcznego doprecyzowania
  ilości (nie tylko widełki min-max)
- Zestawy: wielorzędowe (moduł "X mb", każdy rząd inna odmiana/gęstość),
  w Zamówieniach mnożnik modułu może być ułamkowy (np. 4,5× = odpowiednia
  liczba mb), zaokrąglane dopiero przy realizacji zamówienia
- Raport rentowności (Sprzedaż → Raporty): przychód − koszt sprzedanych −
  koszty stałe = zysk netto, rozbicie miesiąc po miesiącu, ranking odmian
  wg zysku (był kompletnie zepsuty — brakujące importy — naprawiony)
- Kopia zapasowa: eksport/import przez kopiuj-wklej tekstu JSON jako główna
  metoda (pobieranie/wybór pliku zawodne w podglądzie czatu, zostawione jako
  dodatek)

## Architektura partii (Batch/BatchSegment) — w trakcie budowy
Największy, wieloetapowy wątek tej rozmowy. Model zaakceptowany, budowany
etapami, każdy etap mały i przetestowany osobno.

**Kluczowe rozróżnienie (zatwierdzone przeze mnie):**
- **Przesadzenie** ≠ **podział/rozmnażanie**. Przesadzenie = ta sama partia
  (ten sam `batchId`), zmienia się tylko pojemnik/lokalizacja/koszt. Podział =
  ZAWSZE nowa partia, z `parentBatchId`/`parentSegmentId` wskazującym źródło.
- `Batch` (partia) = tożsamość pochodzenia, nigdy sama nie trzyma ilości —
  to suma jej `BatchSegment` (fizyczne miejsce: gatunek+pojemnik+lokalizacja,
  własna ilość i koszt). Jedna partia może mieć wiele aktywnych segmentów
  naraz (różne pojemniki/lokalizacje) — dokładnie mój przykład z Ice Dance
  (500 P9 → częściowo do C5 → częściowo do C8, wciąż jedna partia).
- Model roślin matecznych: `initialQty` na `Batch` jest NIEZMIENNE od
  założenia. `currentQty` liczone ZAWSZE na żywo z aktywnych segmentów
  (nigdy nie trzymane jako osobne pole — jedno źródło prawdy). Podział ma
  parametr `zrodloUbytek`: 0 (matka nie ubywa), częściowy, lub pełny
  (segment się zamyka, ale partia żyje dopóki ma choć jeden aktywny segment).
  Strata jest osobną operacją od podziału.

**Zaimplementowane i przetestowane (Etap 1 + statystyki):**
- `src/utils/batches.js` — czysty moduł (bez Reacta/storage): `createBatch`,
  `createSegment`, `transplantSegment` (częściowe przesadzenie w obrębie
  partii, merguje do istniejącego segmentu ważoną średnią kosztu jeśli taki
  już jest), `divideSegment` (zawsze nowa partia), `recordSegmentSale`,
  `recordSegmentLoss`, `closeSegmentIfEmpty`, `closeBatchIfAllSegmentsEmpty`,
  `aggregateSegmentsToInventory`/`aggregateSegmentsToCosts` (gotowe, ale
  NIEUŻYWANE jeszcze — nie podłączone do prawdziwego `inventory`/`costs`),
  `computeBatchStats`/`computeAllBatchStats` (initialQty/currentQty/
  propagatedQty/lossQty/soldQty/activeSegmentCount/closedSegmentCount —
  wyłącznie odczyt z historii zdarzeń, nic nie zapisuje)
- `src/App.jsx` — dodany stan `batches`/`batchSegments`, ładowanie/zapis pod
  NOWYM kluczem `tenantKey("batches-data", DEFAULT_TENANT_ID)`, całkowicie
  osobno od istniejących 3 grup zapisu. Zero zmian w istniejących ekranach.
- `src/constants.js` — `DEFAULT_TENANT_ID = "default-tenant"` (fundament pod
  przyszły multi-tenant SaaS, świadomie NIE retrofitowany na istniejące klucze
  zapisu — patrz niżej, dlaczego to ważne)
- `src/utils/storage.js` — dodana `tenantKey(key, tenantId)`, nic więcej ruszone
- **Żadne UI jeszcze nie istnieje** dla partii/segmentów — czyste funkcje,
  przetestowane osobnymi skryptami Node (niekomitowanymi do projektu),
  dokładnie na moich przykładach (Ice Dance 500 P9, scenariusze statystyk
  A-G które sam podałem) — wszystko przeszło.

**Plan dalszych etapów (ustalona kolejność, zaakceptowana):**
1. ✅ Fundament danych (Batch/BatchSegment + operacje) — zrobione
2. ✅ Statystyki partii (`computeBatchStats`) — zrobione
3. ✅ Podłączenie tworzenia partii do istniejącego ekranu Podział — zrobione.
   `PodzialPanel.jsx` ma nowy checkbox "Śledź jako partię" (domyślnie
   odznaczony, w pełni opcjonalny). Gdy zaznaczony, `performDivision` w
   `App.jsx` (po swojej dotychczasowej logice inventory/costs/supplies, bez
   żadnej zmiany w niej) dodatkowo woła `createBatch` + `createSegment`
   (jeden segment na każdą pozycję docelową) i dopisuje do stanu
   `batches`/`batchSegments`. WAŻNE uproszczenie: źródło (roślina mateczna)
   NIE jest jeszcze własnym śledzonym segmentem (bo etap 4 — podłączenie
   partii do zakupu — jeszcze nie zrobiony), więc `parentBatchId`/
   `parentSegmentId` nowej partii są `null`, nie `divideSegment` z
   batches.js (który wymaga istniejącego `sourceSegmentId`). To świadomy
   kompromis do czasu etapu 4. Zweryfikowane wizualnie w kodzie + kontrolą
   zbalansowania nawiasów (brak esbuild w tej rozmowie — rejestr npm był
   niedostępny w środowisku, 403 Forbidden) — NIE URUCHOMIONE w przeglądarce,
   warto przetestować w praktyce w kolejnej rozmowie.
4. ⬜ Podłączenie partii do zakupu (nowy model: P9 → przesadzanie) —
   NASTĘPNY KROK. Od tego momentu `divideSegment` z batches.js (istniejący,
   przetestowany) będzie można faktycznie użyć zamiast uproszczenia z
   punktu 3, bo źródło będzie miało prawdziwy `sourceSegmentId`.
5. ⬜ Realny backend + autoryzacja + baza wielodostępna (dopiero to jest
   właściwy moment przejścia na SaaS — nie da się tego zrobić samą zmianą
   modelu danych w kliencie)

## Ważne lekcje z tej rozmowy (żeby nie powtórzyć błędów)
1. **Zmiana nazw kluczy zapisu = ryzyko utraty danych.** Raz już się to
   zdarzyło (konsolidacja 17 kluczy do 3) i realnie "zgubiło" dane z
   wcześniejszej wersji. Dlatego `tenantId` dodany TYLKO do nowego klucza
   `batches-data`, celowo NIE dotyka istniejących `core-data`/`config-data`/
   `activity-data`/`photo:*`.
2. **Podgląd artefaktu w czacie nie nadaje się do testowania trwałości
   danych** — dobry do sprawdzania wyglądu/działania przycisków, zły do
   sprawdzania czy dane przetrwają. To sprawdza się dopiero po wdrożeniu.
3. Każda nietrywialna zmiana w tym projekcie była też walidowana esbuildem
   (bundlowanie całego `App.jsx` z importami) przed pokazaniem mi wyniku —
   warto kontynuować tę praktykę.
4. Jestem praktykiem, nie tylko klientem — cenię sobie precyzyjne pytania
   doprecyzowujące model biznesowy przed kodowaniem, a nie zgadywanie.

## Co dalej
Chcę kontynuować od punktu 4 planu wyżej (podłączenie partii do zakupu) —
ale zacznij od przeczytania załączonego zipu, żeby potwierdzić, że stan
kodu zgadza się z tym podsumowaniem, zanim cokolwiek zaczniesz zmieniać.
Punkt 3 (checkbox w ekranie Podział) jest zrobiony, ale jeszcze NIE
przetestowany w przeglądarce — warto to zrobić jako pierwsze, zanim
pójdziemy dalej.
