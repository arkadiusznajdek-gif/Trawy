import React from 'react';

// src/App.jsx
import { useState as useState28, useEffect as useEffect6, useMemo as useMemo6, useRef as useRef2 } from "react";
import { AlertCircle as AlertCircle2 } from "lucide-react";

// src/data/plants.js
var PLANTS = [
  { "lp": 1, "nazwa_pl": "Miskant chi\u0144ski", "odmiana": "Miscanthus sinensis 'Memory'", "wys_szer": "200\u2013225 / 100\u2013120", "stanowisko": "S\u0142o\u0144ce; \u017Byzna, stale wilgotna", "kwitnienie": "IX\u2013XI; Srebrzysto-per\u0142owe wiechy", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV\u2013V", "ciecie_months": [4], "podzial_months": [4, 5], "special": false, "opis": "Bestseller. Wielkie l\u015Bni\u0105ce wiechy. Nowoczesny \u017Cywop\u0142ot zamiast tui.", "id": "p01", "gestosc_text": "\u017Bywop\u0142ot: co 70\u201380 cm, Na m\xB2: 1\u20132 szt.", "gestosc_typ": "\u017Bywop\u0142ot", "gestosc_rozstaw_cm_min": 70, "gestosc_rozstaw_cm_max": 80, "gestosc_m2_min": 1, "gestosc_m2_max": 2, "gestosc_brak": false },
  { "lp": 2, "nazwa_pl": "Miskant chi\u0144ski", "odmiana": "Miscanthus sinensis 'Morning Light'", "wys_szer": "180\u2013200 / 80\u2013100", "stanowisko": "S\u0142o\u0144ce; Przepuszczalna, umiarkowanie wilgotna", "kwitnienie": "Rzadko (X); R\xF3\u017Cowawe", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV\u2013V", "ciecie_months": [4], "podzial_months": [4, 5], "special": false, "opis": "Rozja\u015Bnia kompozycje. Trzyma idealny pion, nie pok\u0142ada si\u0119 pod ci\u0119\u017Carem deszczu.", "id": "p02", "gestosc_text": "\u017Bywop\u0142ot: co 60 cm, Na m\xB2: 2\u20133 szt.", "gestosc_typ": "\u017Bywop\u0142ot", "gestosc_rozstaw_cm_min": 60, "gestosc_rozstaw_cm_max": 60, "gestosc_m2_min": 2, "gestosc_m2_max": 3, "gestosc_brak": false },
  { "lp": 3, "nazwa_pl": "Miskant olbrzymi", "odmiana": "Miscanthus giganteus", "wys_szer": "300\u2013350 / 120\u2013150", "stanowisko": "S\u0142o\u0144ce/P\xF3\u0142cie\u0144; \u017Byzna, wilgotna (r\xF3w)", "kwitnienie": "Rzadko (X/XI); R\xF3\u017Cowo-br\u0105zowe", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV\u2013V", "ciecie_months": [4], "podzial_months": [4, 5], "special": false, "opis": "Pot\u0119\u017Cny zielony mur. Genialna bariera d\u017Awi\u0119kowa i wzrokowa. Karpa ci\u0119\u017Cka jak ska\u0142a.", "id": "p03", "gestosc_text": "\u017Bywop\u0142ot: co 80\u2013100 cm, Na m\xB2: 1 szt.", "gestosc_typ": "\u017Bywop\u0142ot", "gestosc_rozstaw_cm_min": 80, "gestosc_rozstaw_cm_max": 100, "gestosc_m2_min": 1, "gestosc_m2_max": 1, "gestosc_brak": false },
  { "lp": 4, "nazwa_pl": "Miskant chi\u0144ski", "odmiana": "Miscanthus sinensis 'Gracillimus'", "wys_szer": "180\u2013200 / 100", "stanowisko": "S\u0142o\u0144ce; Umiarkowanie \u017Cyzna i wilgotna", "kwitnienie": "X\u2013XI; Rdzawo-br\u0105zowe (rzadko)", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV\u2013V", "ciecie_months": [4], "podzial_months": [4, 5], "special": false, "opis": "Klasyk na rynku. Pi\u0119knie szumi i faluje na wietrze. Ceniony za perfekcyjny kszta\u0142t k\u0119py.", "id": "p04", "gestosc_text": "\u017Bywop\u0142ot: co 70 cm, Na m\xB2: 2 szt.", "gestosc_typ": "\u017Bywop\u0142ot", "gestosc_rozstaw_cm_min": 70, "gestosc_rozstaw_cm_max": 70, "gestosc_m2_min": 2, "gestosc_m2_max": 2, "gestosc_brak": false },
  { "lp": 5, "nazwa_pl": "Miskant chi\u0144ski", "odmiana": "Miscanthus sinensis 'Milos'", "wys_szer": "200\u2013220 / 100", "stanowisko": "S\u0142o\u0144ce; Przeci\u0119tna ogrodowa, wilgotna", "kwitnienie": "IX\u2013XI; Srebrzysto-be\u017Cowe", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV\u2013V", "ciecie_months": [4], "podzial_months": [4, 5], "special": false, "opis": "\u015Awietna ro\u015Blina t\u0142a. Bardzo odporna na mocne mrozy. Tworzy szybkie i stabilne \u015Bciany.", "id": "p05", "gestosc_text": "\u017Bywop\u0142ot: co 60\u201370 cm, Na m\xB2: 2 szt.", "gestosc_typ": "\u017Bywop\u0142ot", "gestosc_rozstaw_cm_min": 60, "gestosc_rozstaw_cm_max": 70, "gestosc_m2_min": 2, "gestosc_m2_max": 2, "gestosc_brak": false },
  { "lp": 6, "nazwa_pl": "Miskant chi\u0144ski", "odmiana": "Miscanthus sinensis 'Etincelle'", "wys_szer": "140\u2013160 / 60\u201380", "stanowisko": "S\u0142o\u0144ce; \u017Byzna, przepuszczalna", "kwitnienie": "IX\u2013X; Czerwono-br\u0105zowe", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV\u2013V", "ciecie_months": [4], "podzial_months": [4, 5], "special": false, "opis": "Wygl\u0105da jak nakrapiany z\u0142otem. Kompaktowa alternatywa dla wielkiej odmiany 'Zebrinus'.", "id": "p06", "gestosc_text": "Szpaler: co 50 cm, Na m\xB2: 3 szt.", "gestosc_typ": "Szpaler", "gestosc_rozstaw_cm_min": 50, "gestosc_rozstaw_cm_max": 50, "gestosc_m2_min": 3, "gestosc_m2_max": 3, "gestosc_brak": false },
  { "lp": 7, "nazwa_pl": "Miskant chi\u0144ski", "odmiana": "Miscanthus sinensis 'Apache'", "wys_szer": "100\u2013110 / 50\u201360", "stanowisko": "S\u0142o\u0144ce; Umiarkowanie wilgotna, \u017Cyzna", "kwitnienie": "Rzadko (X); Be\u017Cowe", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV\u2013V", "ciecie_months": [4], "podzial_months": [4, 5], "special": false, "opis": "Zebra w wersji mini. Idealny do ma\u0142ych ogrod\xF3w, na prz\xF3d rabat oraz do donic na tarasy.", "id": "p07", "gestosc_text": "Obw\xF3dka: co 40 cm, Na m\xB2: 3\u20134 szt.", "gestosc_typ": "Obw\xF3dka", "gestosc_rozstaw_cm_min": 40, "gestosc_rozstaw_cm_max": 40, "gestosc_m2_min": 3, "gestosc_m2_max": 4, "gestosc_brak": false },
  { "lp": 8, "nazwa_pl": "Miskant chi\u0144ski", "odmiana": "Miscanthus sinensis 'Zebrinus'", "wys_szer": "180\u2013200 / 120", "stanowisko": "S\u0142o\u0144ce; \u017Byzna, stale wilgotna", "kwitnienie": "IX\u2013X; Jedwabisto-r\xF3\u017Cowe", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV\u2013V", "ciecie_months": [4], "podzial_months": [4, 5], "special": false, "opis": "Klasyczna \u201EZebra\u201D. Potrzebuje miejsca, szeroki g\xF3r\u0105. Starsze k\u0119py mog\u0105 wymaga\u0107 podwi\u0105zywania.", "id": "p08", "gestosc_text": "Szpaler: co 80 cm, Na m\xB2: 1\u20132 szt.", "gestosc_typ": "Szpaler", "gestosc_rozstaw_cm_min": 80, "gestosc_rozstaw_cm_max": 80, "gestosc_m2_min": 1, "gestosc_m2_max": 2, "gestosc_brak": false },
  { "lp": 9, "nazwa_pl": "Miskant", "odmiana": "Miscanthus lutarioriparius", "wys_szer": "350\u2013400 / Du\u017Ca", "stanowisko": "S\u0142o\u0144ce; Bardzo wilgotna, glina, r\xF3w", "kwitnienie": "X\u2013XI; Srebrzysto-bia\u0142e", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV\u2013V", "ciecie_months": [4], "podzial_months": [4, 5], "special": false, "opis": "Potw\xF3r botaniczny o pot\u0119\u017Cnym wigorze. Daje niesamowity, egzotyczny efekt d\u017Cungli w ogrodzie.", "id": "p09", "gestosc_text": "Sadzi\u0107 tylko w Mauserze / barierze HDPE!", "gestosc_typ": null, "gestosc_rozstaw_cm_min": null, "gestosc_rozstaw_cm_max": null, "gestosc_m2_min": null, "gestosc_m2_max": null, "gestosc_brak": true },
  { "lp": 10, "nazwa_pl": "Rozplenica japo\u0144ska", "odmiana": "Pennisetum 'Olimpia'", "wys_szer": "90\u2013100 / 80", "stanowisko": "S\u0142o\u0144ce; \u017Byzna, pr\xF3chniczna, wilgotna", "kwitnienie": "VIII\u2013X; Ciemnopurpurowe, grube szczotki", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: V", "ciecie_months": [4], "podzial_months": [5], "special": false, "opis": "Niezwykle obfite kwitnienie. Ciemne, grube kwiatostany pi\u0119knie kontrastuj\u0105 z jasnym otoczeniem.", "id": "p10", "gestosc_text": "Grupy: co 50\u201360 cm, Na m\xB2: 3 szt.", "gestosc_typ": "Grupy", "gestosc_rozstaw_cm_min": 50, "gestosc_rozstaw_cm_max": 60, "gestosc_m2_min": 3, "gestosc_m2_max": 3, "gestosc_brak": false },
  { "lp": 11, "nazwa_pl": "Rozplenica japo\u0144ska", "odmiana": "Pennisetum 'Hameln'", "wys_szer": "80\u201390 / 60\u201380", "stanowisko": "S\u0142o\u0144ce; \u017Byzna, przepuszczalna, wilgotna", "kwitnienie": "VII\u2013X; Jasnobe\u017Cowe, puszyste k\u0142osy", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: V", "ciecie_months": [4], "podzial_months": [5], "special": false, "opis": "Kr\xF3lowa rozplenic. Najpopularniejsza trawa miejska i ogrodowa. Kwitnie najwcze\u015Bniej i masowo.", "id": "p11", "gestosc_text": "Szpaler: co 50 cm, Na m\xB2: 4 szt.", "gestosc_typ": "Szpaler", "gestosc_rozstaw_cm_min": 50, "gestosc_rozstaw_cm_max": 50, "gestosc_m2_min": 4, "gestosc_m2_max": 4, "gestosc_brak": false },
  { "lp": 12, "nazwa_pl": "Rozplenica japo\u0144ska", "odmiana": "Pennisetum 'Hameln Gold'", "wys_szer": "40\u201350 / 40\u201350", "stanowisko": "S\u0142o\u0144ce (pe\u0142ne); Wilgotna", "kwitnienie": "VIII\u2013X; Be\u017Cowo-r\xF3\u017Cowe", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: V", "ciecie_months": [4], "podzial_months": [5], "special": false, "opis": "\u017Bywa plama \u015Bwiat\u0142a na rabacie. Idealna do donic i jako jasna obw\xF3dka. Ro\u015Bnie wolniej od zielonej.", "id": "p12", "gestosc_text": "Obw\xF3dka: co 35 cm, Na m\xB2: 5\u20136 szt.", "gestosc_typ": "Obw\xF3dka", "gestosc_rozstaw_cm_min": 35, "gestosc_rozstaw_cm_max": 35, "gestosc_m2_min": 5, "gestosc_m2_max": 6, "gestosc_brak": false },
  { "lp": 13, "nazwa_pl": "Rozplenica japo\u0144ska", "odmiana": "Pennisetum 'Black Beauty'", "wys_szer": "120\u2013140 / 100", "stanowisko": "S\u0142o\u0144ce (ciep\u0142e); \u017Byzna, wilgotna", "kwitnienie": "VIII\u2013X; Niemal czarne, ogromne k\u0142osy", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: V", "ciecie_months": [4], "podzial_months": [5], "special": false, "opis": "Odmiana Premium. Czarne, puszyste kwiatostany wygl\u0105daj\u0105 zjawiskowo pod\u015Bwietlone s\u0142o\u0144cem.", "id": "p13", "gestosc_text": "Grupy: co 70\u201380 cm, Na m\xB2: 1\u20132 szt.", "gestosc_typ": "Grupy", "gestosc_rozstaw_cm_min": 70, "gestosc_rozstaw_cm_max": 80, "gestosc_m2_min": 1, "gestosc_m2_max": 2, "gestosc_brak": false },
  { "lp": 14, "nazwa_pl": "Rozplenica japo\u0144ska", "odmiana": "Pennisetum 'Gelbstiel'", "wys_szer": "80\u201390 / 60", "stanowisko": "S\u0142o\u0144ce; \u017Byzna, umiarkowanie wilgotna", "kwitnienie": "VIII\u2013X; Jasne k\u0142osy na \u017C\xF3\u0142tych \u0142odygach", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: V", "ciecie_months": [4], "podzial_months": [5], "special": false, "opis": "\u017B\xF3\u0142te p\u0119dy kwiatowe daj\u0105 pi\u0119kny, geometryczny detal w masowych nasadzeniach jednoodmianowych.", "id": "p14", "gestosc_text": "Grupy: co 50 cm, Na m\xB2: 3\u20134 szt.", "gestosc_typ": "Grupy", "gestosc_rozstaw_cm_min": 50, "gestosc_rozstaw_cm_max": 50, "gestosc_m2_min": 3, "gestosc_m2_max": 4, "gestosc_brak": false },
  { "lp": 15, "nazwa_pl": "Rozplenica japo\u0144ska", "odmiana": "Pennisetum 'Burgundy Bunny'", "wys_szer": "30\u201340 / 30", "stanowisko": "S\u0142o\u0144ce (pe\u0142ne); \u017Byzna", "kwitnienie": "VIII\u2013X; Czerwonawo-br\u0105zowe, ma\u0142e", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: V", "ciecie_months": [4], "podzial_months": [5], "special": false, "opis": "Karze\u0142ek o ognistym kolorze. Idealna na obw\xF3dki nowoczesnych rabat oraz do skrzynek tarasowych.", "id": "p15", "gestosc_text": "Obw\xF3dka: co 25\u201330 cm, Na m\xB2: 7\u20139 szt.", "gestosc_typ": "Obw\xF3dka", "gestosc_rozstaw_cm_min": 25, "gestosc_rozstaw_cm_max": 30, "gestosc_m2_min": 7, "gestosc_m2_max": 9, "gestosc_brak": false },
  { "lp": 16, "nazwa_pl": "Proso r\xF3zgowate", "odmiana": "Panicum virgatum 'Northwind'", "wys_szer": "160\u2013170 / 50\u201360", "stanowisko": "S\u0142o\u0144ce; Ka\u017Cda, nawet sucha i piaszczysta", "kwitnienie": "VIII\u2013X; A\u017Curowe, delikatne wiechy", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV", "ciecie_months": [4], "podzial_months": [4], "special": false, "opis": "\u017Belazna struktura. Nigdy si\u0119 nie pok\u0142ada, znosi silne wichury, susz\u0119, miejskie spaliny.", "id": "p16", "gestosc_text": "\u017Bywop\u0142ot: co 50 cm, Na m\xB2: 3 szt.", "gestosc_typ": "\u017Bywop\u0142ot", "gestosc_rozstaw_cm_min": 50, "gestosc_rozstaw_cm_max": 50, "gestosc_m2_min": 3, "gestosc_m2_max": 3, "gestosc_brak": false },
  { "lp": 17, "nazwa_pl": "Imperata cylindryczna", "odmiana": "Imperata cylindrica 'Red Baron'", "wys_szer": "50\u201380 / Wolna", "stanowisko": "S\u0142o\u0144ce (pe\u0142ne); \u017Byzna, wilgotna", "kwitnienie": "W Polsce zwykle nie kwitnie", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV\u2013V", "ciecie_months": [4], "podzial_months": [4, 5], "special": false, "opis": "Magnes wzrokowy. Sprzedaje si\u0119 sama, gdy tylko klient zobaczy jej jaskrawoczerwone li\u015Bcie.", "id": "p17", "gestosc_text": "Plamy barwne: co 30 cm, Na m\xB2: 7\u20139 szt.", "gestosc_typ": "Plamy barwne", "gestosc_rozstaw_cm_min": 30, "gestosc_rozstaw_cm_max": 30, "gestosc_m2_min": 7, "gestosc_m2_max": 9, "gestosc_brak": false },
  { "lp": 18, "nazwa_pl": "Ostnica cienkolistna", "odmiana": "Stipa tenuissima 'Pony Tails'", "wys_szer": "40\u201350 / 30\u201340", "stanowisko": "S\u0142o\u0144ce; Sucha, piaszczysta, uboga. Nie znosi gliny", "kwitnienie": "VI\u2013IX; Jedwabiste, kremowo-bia\u0142e pi\xF3ra", "zimozielona": "Nie", "ciecie_text": "Wyczesywanie lub niskie ci\u0119cie w V", "podzial_text": "", "ciecie_months": [5], "podzial_months": [], "special": true, "opis": "Mocno si\u0119 rozsiewa! Faluje przy najmniejszym powiewie powietrza. Niezwykle mi\u0119kka w dotyku.", "id": "p18", "gestosc_text": "Grupy: co 30 cm, Na m\xB2: 7\u20139 szt.", "gestosc_typ": "Grupy", "gestosc_rozstaw_cm_min": 30, "gestosc_rozstaw_cm_max": 30, "gestosc_m2_min": 7, "gestosc_m2_max": 9, "gestosc_brak": false },
  { "lp": 19, "nazwa_pl": "Strz\u0119plica sina", "odmiana": "Koeleria glauca 'Coolio'", "wys_szer": "30\u201340 / 25\u201330", "stanowisko": "S\u0142o\u0144ce; Sucha, uboga, piaszczysta, skalniaki", "kwitnienie": "V\u2013VII; Srebrzysto-zielone wiechy", "zimozielona": "Tak", "ciecie_text": "Nie \u015Bcina\u0107! Tylko wyczesywanie w IV", "podzial_text": "", "ciecie_months": [4], "podzial_months": [], "special": true, "opis": "Idealna na pe\u0142ne, pal\u0105ce s\u0142o\u0144ce i piach. Tworzy pi\u0119kne, niebieskie poduszki strukturalne.", "id": "p19", "gestosc_text": "Skalniaki: co 25 cm, Na m\xB2: 9\u201311 szt.", "gestosc_typ": "Skalniaki", "gestosc_rozstaw_cm_min": 25, "gestosc_rozstaw_cm_max": 25, "gestosc_m2_min": 9, "gestosc_m2_max": 11, "gestosc_brak": false },
  { "lp": 20, "nazwa_pl": "Trz\u0119\u015Blica trzcinowata", "odmiana": "Molinia 'Transparent'", "wys_szer": "150\u2013170 / 80\u2013100", "stanowisko": "S\u0142o\u0144ce/P\xF3\u0142cie\u0144; Wilgotna, kwa\u015Bna, torf (r\xF3w)", "kwitnienie": "VIII\u2013X; Purpurowo-br\u0105zowe, delikatne mgie\u0142ki", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV", "podzial_text": "Podzia\u0142: IV", "ciecie_months": [4], "podzial_months": [4], "special": false, "opis": "Idealna na okna widokowe. Tworzy mgie\u0142k\u0119, przez kt\xF3r\u0105 wida\u0107 ogr\xF3d. Przepi\u0119kny jesienny kolor.", "id": "p20", "gestosc_text": "Soliter / Grupy: co 60-70 cm, Na m\xB2: 2 szt.", "gestosc_typ": "Soliter / Grupy", "gestosc_rozstaw_cm_min": 60, "gestosc_rozstaw_cm_max": 70, "gestosc_m2_min": 2, "gestosc_m2_max": 2, "gestosc_brak": false },
  { "lp": 21, "nazwa_pl": "Sesleria jesienna", "odmiana": "Sesleria autumnalis", "wys_szer": "40\u201350 / 40", "stanowisko": "S\u0142o\u0144ce/P\xF3\u0142cie\u0144; Ka\u017Cda, sucha, wapienna", "kwitnienie": "VIII\u2013X; Drobne, bia\u0142awo-kremowe k\u0142oski", "zimozielona": "Tak", "ciecie_text": "Nie \u015Bcina\u0107! Tylko czyszczenie w IV", "podzial_text": "", "ciecie_months": [4], "podzial_months": [], "special": true, "opis": "Terminator. Zim\u0105 wygl\u0105da jak \u017Cywa. Tworzy idealne dywany pod drzewami, ca\u0142kowicie blokuje chwasty.", "id": "p21", "gestosc_text": "Okrywowa: co 30\u201335 cm, Na m\xB2: 7\u20139 szt.", "gestosc_typ": "Okrywowa", "gestosc_rozstaw_cm_min": 30, "gestosc_rozstaw_cm_max": 35, "gestosc_m2_min": 7, "gestosc_m2_max": 9, "gestosc_brak": false },
  { "lp": 22, "nazwa_pl": "\u015Amia\u0142ek darniowy", "odmiana": "Deschampsia 'Goldtau'", "wys_szer": "60\u201380 / 50\u201360", "stanowisko": "P\xF3\u0142cie\u0144/S\u0142o\u0144ce; Wilgotna, \u017Cyzna (znosi bagnisko)", "kwitnienie": "VI\u2013VIII; Miliony z\u0142otych, drobnych k\u0142osk\xF3w", "zimozielona": "Cz\u0119\u015Bciowo", "ciecie_text": "Ci\u0119cie: III/IV", "podzial_text": "Podzia\u0142: III-IV lub IX", "ciecie_months": [3, 4], "podzial_months": [3, 4, 9], "special": false, "opis": "Efekt \u201Ez\u0142otej rosy\u201D o poranku. Kwitnie wcze\u015Bnie i obficie. Idealna do umacniania skarp rowu.", "id": "p22", "gestosc_text": "Szpaler / Grupy: co 40 cm, Na m\xB2: 4\u20135 szt.", "gestosc_typ": "Szpaler / Grupy", "gestosc_rozstaw_cm_min": 40, "gestosc_rozstaw_cm_max": 40, "gestosc_m2_min": 4, "gestosc_m2_max": 5, "gestosc_brak": false },
  { "lp": 23, "nazwa_pl": "Muhlenbergia", "odmiana": "Muhlenbergia capillaris", "wys_szer": "60\u201380 / 50\u201360", "stanowisko": "S\u0142o\u0144ce (ciep\u0142e); Przepuszczalna, sucha zim\u0105", "kwitnienie": "IX\u2013XI; Jaskrawor\xF3\u017Cowa, watowata, wielka chmura", "zimozielona": "Nie", "ciecie_text": "Ci\u0119cie: IV/V", "podzial_text": "Podzia\u0142: V", "ciecie_months": [4, 5], "podzial_months": [5], "special": false, "opis": "Hit Instagrama. R\xF3\u017Cowa chmura kwiat\xF3w wygl\u0105da nierealnie. Wymaga bezwzgl\u0119dnego drena\u017Cu na zim\u0119.", "id": "p23", "gestosc_text": "Grupy / Donice: co 40 cm, Na m\xB2: 4\u20135 szt.", "gestosc_typ": "Grupy / Donice", "gestosc_rozstaw_cm_min": 40, "gestosc_rozstaw_cm_max": 40, "gestosc_m2_min": 4, "gestosc_m2_max": 5, "gestosc_brak": false },
  { "lp": 24, "nazwa_pl": "Turzyca", "odmiana": "Carex morrowii 'Ice Dance'", "wys_szer": "30\u201340 / 40\u201350", "stanowisko": "P\xF3\u0142cie\u0144\u2013cie\u0144; wilgotna", "kwitnienie": "Niepozorne", "zimozielona": "Tak", "ciecie_text": "Ci\u0119cie: III", "podzial_text": "", "ciecie_months": [3], "podzial_months": [], "special": false, "opis": "Zimozielona.", "id": "p24", "gestosc_text": "30 cm; 7\u20139/m\xB2", "gestosc_typ": null, "gestosc_rozstaw_cm_min": 30, "gestosc_rozstaw_cm_max": 30, "gestosc_m2_min": 7, "gestosc_m2_max": 9, "gestosc_brak": false },
  { "lp": 25, "nazwa_pl": "Turzyca", "odmiana": "Carex oshimensis 'The Beatles'", "wys_szer": "20\u201330 / 35\u201345", "stanowisko": "P\xF3\u0142cie\u0144; przepuszczalna", "kwitnienie": "Niepozorne", "zimozielona": "Tak", "ciecie_text": "Ci\u0119cie: III", "podzial_text": "", "ciecie_months": [3], "podzial_months": [], "special": false, "opis": "Kulista forma.", "id": "p25", "gestosc_text": "30 cm; 7\u20139/m\xB2", "gestosc_typ": null, "gestosc_rozstaw_cm_min": 30, "gestosc_rozstaw_cm_max": 30, "gestosc_m2_min": 7, "gestosc_m2_max": 9, "gestosc_brak": false },
  { "lp": 26, "nazwa_pl": "Turzyca", "odmiana": "Carex oshimensis 'Greenwell'", "wys_szer": "25\u201335 / 35\u201345", "stanowisko": "P\xF3\u0142cie\u0144; przepuszczalna", "kwitnienie": "Niepozorne", "zimozielona": "Tak", "ciecie_text": "Ci\u0119cie: III", "podzial_text": "", "ciecie_months": [3], "podzial_months": [], "special": false, "opis": "Zimozielona.", "id": "p26", "gestosc_text": "30 cm; 7\u20139/m\xB2", "gestosc_typ": null, "gestosc_rozstaw_cm_min": 30, "gestosc_rozstaw_cm_max": 30, "gestosc_m2_min": 7, "gestosc_m2_max": 9, "gestosc_brak": false }
];

// src/constants.js
var MONTHS = ["", "Stycze\u0144", "Luty", "Marzec", "Kwiecie\u0144", "Maj", "Czerwiec", "Lipiec", "Sierpie\u0144", "Wrzesie\u0144", "Pa\u017Adziernik", "Listopad", "Grudzie\u0144"];
var DEFAULT_POT_SIZES = ["P9", "C3", "C5"];
var LOSS_REASONS = ["Choroba", "Wymarzni\u0119cie", "Susza", "Uszkodzenie mechaniczne", "Szkodniki", "Przesuszenie", "Nadmiar wody", "Nieprzyj\u0119cie si\u0119", "Inne"];
var DEFAULT_SUPPLIES = [
  { id: "sup-p9", nazwa: "Donice P9 (puste)", ilosc: 0, jednostka: "szt.", prog: null, cena: 0, typ: "donica", rozmiar: "P9" },
  { id: "sup-c3", nazwa: "Donice C3 (puste)", ilosc: 0, jednostka: "szt.", prog: null, cena: 0, typ: "donica", rozmiar: "C3" },
  { id: "sup-c5", nazwa: "Donice C5 (puste)", ilosc: 0, jednostka: "szt.", prog: null, cena: 0, typ: "donica", rozmiar: "C5" },
  { id: "sup-podloze", nazwa: "Pod\u0142o\u017Ce uniwersalne", ilosc: 0, jednostka: "l", prog: null, cena: 0, typ: "podloze", rozmiar: null }
];
var TAB_TITLES = {
  pulpit: "Pulpit",
  magazyn: "Magazyn",
  harmonogram: "Harmonogram prac",
  sprzedaz: "Sprzeda\u017C",
  etykiety: "Etykiety"
};
var TASK_STATUS_META = {
  todo: { label: "Do zrobienia", cls: "status-todo" },
  progress: { label: "W trakcie", cls: "status-progress" },
  done: { label: "Gotowe", cls: "status-done" }
};
var DEFAULT_TENANT_ID = "default-tenant";

// src/utils/helpers.js
function suggestPlantingQty(plant, mode, value) {
  const v = Number(value);
  if (!plant || !v || v <= 0 || plant.gestosc_brak) return null;
  if (mode === "mb") {
    const { gestosc_rozstaw_cm_min: rMin, gestosc_rozstaw_cm_max: rMax } = plant;
    if (!rMin || !rMax) return null;
    const cm = v * 100;
    const max = Math.ceil(cm / rMin);
    const min = Math.floor(cm / rMax);
    return { min: Math.max(1, min), max: Math.max(1, max) };
  }
  if (mode === "m2") {
    const { gestosc_m2_min: mMin, gestosc_m2_max: mMax } = plant;
    if (mMin == null || mMax == null) return null;
    return { min: Math.max(1, Math.round(v * mMin)), max: Math.max(1, Math.round(v * mMax)) };
  }
  return null;
}
function containerLabel(c) {
  return c === "grunt" ? "Grunt" : c;
}
function uid2(prefix) {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}
function resolveContainers(plantContainerSizes, catalog, plantId) {
  const arr = plantContainerSizes[plantId];
  return arr && arr.length ? arr : catalog;
}
function resolvePotContainers(plantContainerSizes, potSizes, plantId) {
  const catalog = [...potSizes, "grunt"];
  return resolveContainers(plantContainerSizes, catalog, plantId).filter((c) => c !== "grunt");
}
function costOfContainer(potRecipes, substrateCostPerL, size) {
  const r = potRecipes[size];
  if (!r) return 0;
  return Number(r.koszt_donicy || 0) + Number(r.podloze_l || 0) * Number(substrateCostPerL || 0);
}
function findSupplyByContainer(supplies, size) {
  const typed = supplies.find((s) => s.typ === "donica" && s.rozmiar === size);
  if (typed) return typed;
  return supplies.find((s) => !s.typ && s.nazwa.toLowerCase().includes(size.toLowerCase()));
}
function findSubstrateSupply(supplies) {
  const typed = supplies.find((s) => s.typ === "podloze");
  if (typed) return typed;
  return supplies.find((s) => {
    const n = s.nazwa.toLowerCase();
    return !s.typ && (n.includes("pod\u0142o\u017C") || n.includes("podloz"));
  });
}
function deriveContainerSizes(supplies) {
  const sizes = [];
  supplies.forEach((s) => {
    if (s.typ === "donica" && s.rozmiar && !sizes.includes(s.rozmiar)) sizes.push(s.rozmiar);
  });
  return sizes;
}
function migrateSupplies(rawSupplies, legacySizes) {
  const known = legacySizes && legacySizes.length ? legacySizes : [];
  let changed = false;
  const migrated = (rawSupplies || []).map((s) => {
    if (s.typ) return s;
    changed = true;
    const n = s.nazwa.toLowerCase();
    if (n.includes("pod\u0142o\u017C") || n.includes("podloz")) return { ...s, typ: "podloze", rozmiar: null, cena: s.cena ?? 0 };
    const matched = known.find((sz) => n.includes(sz.toLowerCase()));
    if (matched) return { ...s, typ: "donica", rozmiar: matched, cena: s.cena ?? 0 };
    return { ...s, typ: "inne", rozmiar: null, cena: s.cena ?? 0 };
  });
  known.forEach((sz) => {
    const has = migrated.some((s) => s.typ === "donica" && s.rozmiar === sz);
    if (!has) {
      changed = true;
      migrated.push({ id: uid2("sup"), nazwa: `Donice ${sz} (puste)`, ilosc: 0, jednostka: "szt.", prog: null, cena: 0, typ: "donica", rozmiar: sz });
    }
  });
  return { supplies: migrated, changed };
}
function money(n) {
  const v = Number(n);
  return (Number.isFinite(v) ? v : 0).toFixed(2);
}
function clampInt(v, min = 0) {
  const n = Math.round(Number(v));
  if (!Number.isFinite(n)) return min;
  return Math.max(min, n);
}
function monthsToRomanText(months) {
  return months.map((m) => ROMAN_BY_MONTH[m]).join("/");
}
function monthKey(year, month) {
  return `${year}-${month}`;
}
function taskKey(year, month, plantId, type) {
  return `${year}-${month}-${plantId}-${type}`;
}
function formatLogTime(ts) {
  const d = new Date(ts);
  return d.toLocaleString("pl-PL", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}
function orderCogsBreakdown(order, zestawy, costs, batchSegments) {
  const needed = {};
  function addNeed(plantId, container, qty) {
    needed[plantId] = needed[plantId] || {};
    needed[plantId][container] = (needed[plantId][container] || 0) + qty;
  }
  (order.pozycje || []).forEach((it) => {
    if (it.kind === "plant") {
      addNeed(it.plantId, it.container, Number(it.ilosc || 0));
    } else if (it.kind === "zestaw") {
      const z = zestawy.find((zz) => zz.id === it.zestawId);
      if (z) (z.pozycje || []).forEach((comp) => addNeed(comp.plantId, comp.container, Number(comp.ilosc || 0) * Number(it.ilosc || 0)));
    }
  });
  const soldFromSegments = {};
  (batchSegments || []).forEach((s) => {
    (s.historia || []).forEach((h) => {
      if (h.typ !== "sprzedaz" || h.dane?.orderId !== order.id) return;
      soldFromSegments[s.plantId] = soldFromSegments[s.plantId] || {};
      const row = soldFromSegments[s.plantId][s.container] || { ilosc: 0, koszt: 0 };
      row.ilosc += Number(h.dane.ilosc || 0);
      row.koszt += Number(h.dane.koszt || 0);
      soldFromSegments[s.plantId][s.container] = row;
    });
  });
  const rows = [];
  Object.entries(needed).forEach(([plantId, row]) => {
    Object.entries(row).forEach(([container, ilosc]) => {
      const tracked = soldFromSegments[plantId]?.[container] || { ilosc: 0, koszt: 0 };
      const trackedQty = Math.min(ilosc, tracked.ilosc);
      const untrackedQty = Math.max(0, ilosc - trackedQty);
      const untrackedCogs = untrackedQty * Number(costs[plantId]?.[container] || 0);
      rows.push({ plantId, container, ilosc, cogs: tracked.koszt + untrackedCogs, trackedQty, untrackedQty });
    });
  });
  return rows;
}
function computeYearlyProfitReport(orders, zestawy, costs, overheadCosts, year, batchSegments) {
  const monthly = Array.from({ length: 12 }, (_, i) => ({ month: i + 1, revenue: 0, cogs: 0, overhead: 0, ordersCount: 0 }));
  orders.forEach((o) => {
    if (o.status !== "zrealizowane") return;
    const parts = (o.data || "").split("-");
    const y = Number(parts[0]);
    const m = Number(parts[1]);
    if (y !== year || !m || m < 1 || m > 12) return;
    const row = monthly[m - 1];
    row.revenue += Number(o.suma || 0);
    row.cogs += orderCogsBreakdown(o, zestawy, costs, batchSegments).reduce((s, r) => s + r.cogs, 0);
    row.ordersCount += 1;
  });
  (overheadCosts || []).forEach((it) => {
    const kwota = Number(it.kwota || 0);
    if (it.okres === "miesi\u0119cznie") {
      monthly.forEach((row) => {
        row.overhead += kwota;
      });
    } else if (it.okres === "rocznie") {
      monthly.forEach((row) => {
        row.overhead += kwota / 12;
      });
    } else if (it.okres === "jednorazowo") {
      const parts = (it.data || "").split("-");
      const y = Number(parts[0]);
      const m = Number(parts[1]);
      if (y === year && m >= 1 && m <= 12) monthly[m - 1].overhead += kwota;
    }
  });
  monthly.forEach((row) => {
    row.grossProfit = row.revenue - row.cogs;
    row.netProfit = row.grossProfit - row.overhead;
  });
  const totals = monthly.reduce(
    (acc, row) => ({
      revenue: acc.revenue + row.revenue,
      cogs: acc.cogs + row.cogs,
      overhead: acc.overhead + row.overhead,
      grossProfit: acc.grossProfit + row.grossProfit,
      netProfit: acc.netProfit + row.netProfit,
      ordersCount: acc.ordersCount + row.ordersCount
    }),
    { revenue: 0, cogs: 0, overhead: 0, grossProfit: 0, netProfit: 0, ordersCount: 0 }
  );
  return { monthly, totals };
}
function computeTopVarietiesByProfit(orders, zestawy, costs, year, limit = 5, batchSegments) {
  const map = {};
  orders.forEach((o) => {
    if (o.status !== "zrealizowane") return;
    if (Number((o.data || "").split("-")[0]) !== year) return;
    (o.pozycje || []).forEach((it) => {
      if (it.kind === "plant") {
        const key = `${it.plantId}|${it.container}`;
        if (!map[key]) map[key] = { plantId: it.plantId, container: it.container, ilosc: 0, revenue: 0, cogs: 0, fromZestaw: false };
        map[key].ilosc += Number(it.ilosc || 0);
        map[key].revenue += Number(it.ilosc || 0) * Number(it.cena || 0);
      } else if (it.kind === "zestaw") {
        const z = zestawy.find((zz) => zz.id === it.zestawId);
        if (!z) return;
        (z.pozycje || []).forEach((comp) => {
          const key = `${comp.plantId}|${comp.container}`;
          const compQty = Number(comp.ilosc || 0) * Number(it.ilosc || 0);
          if (!map[key]) map[key] = { plantId: comp.plantId, container: comp.container, ilosc: 0, revenue: 0, cogs: 0, fromZestaw: true };
          map[key].ilosc += compQty;
          map[key].fromZestaw = true;
        });
      }
    });
    orderCogsBreakdown(o, zestawy, costs, batchSegments).forEach((row) => {
      const key = `${row.plantId}|${row.container}`;
      if (!map[key]) map[key] = { plantId: row.plantId, container: row.container, ilosc: 0, revenue: 0, cogs: 0, fromZestaw: false };
      map[key].cogs += row.cogs;
    });
  });
  return Object.values(map).map((v) => ({ ...v, profit: v.revenue - v.cogs })).sort((a, b) => b.profit - a.profit).slice(0, limit);
}
function computeMonthlySales(orders) {
  const map = {};
  orders.forEach((o) => {
    const d = o.data || "";
    const parts = d.split("-");
    if (parts.length < 2) return;
    const y = Number(parts[0]);
    const m = Number(parts[1]);
    if (!y || !m) return;
    const key = `${y}-${m}`;
    if (!map[key]) map[key] = { key, year: y, month: m, count: 0, sum: 0, countDone: 0, sumDone: 0, orders: [] };
    map[key].count += 1;
    map[key].sum += Number(o.suma || 0);
    if (o.status === "zrealizowane") {
      map[key].countDone += 1;
      map[key].sumDone += Number(o.suma || 0);
    }
    map[key].orders.push(o);
  });
  return Object.values(map).sort((a, b) => b.year - a.year || b.month - a.month);
}
function resizeImageToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("read-failed"));
    reader.onload = (e) => {
      const img = new window.Image();
      img.onerror = () => reject(new Error("decode-failed"));
      img.onload = () => {
        const scale = Math.min(1, PHOTO_MAX_W / img.width);
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, w, h);
        try {
          resolve(canvas.toDataURL("image/jpeg", PHOTO_QUALITY));
        } catch (err) {
          reject(err);
        }
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}
function formatShortDate(dateStr) {
  if (!dateStr) return "";
  const parts = dateStr.split("-");
  if (parts.length < 3) return dateStr;
  const day = parts[2];
  const month = Number(parts[1]);
  return `${day} ${MONTHS[month] ? MONTHS[month].slice(0, 3).toLowerCase() : ""}`;
}

// src/utils/storage.js
import { useRef, useEffect } from "react";
var hasNativeStorage = typeof window !== "undefined" && !!window.storage;
var localStorageShim = {
  async get(key) {
    if (typeof window === "undefined") return null;
    const raw = window.localStorage.getItem(`szkolka:${key}`);
    if (raw == null) return null;
    return { key, value: raw };
  },
  async set(key, value) {
    if (typeof window === "undefined") return null;
    window.localStorage.setItem(`szkolka:${key}`, value);
    return { key, value };
  },
  async delete(key) {
    if (typeof window === "undefined") return null;
    window.localStorage.removeItem(`szkolka:${key}`);
    return { key, deleted: true };
  },
  async list(prefix) {
    if (typeof window === "undefined") return { keys: [] };
    const keys = [];
    for (let i = 0; i < window.localStorage.length; i++) {
      const k = window.localStorage.key(i);
      if (k && k.startsWith(`szkolka:${prefix || ""}`)) keys.push(k.replace("szkolka:", ""));
    }
    return { keys };
  }
};
var store = hasNativeStorage ? window.storage : localStorageShim;
async function loadKey(key, fallback) {
  try {
    const res = await store.get(key, false);
    if (res && res.value) return JSON.parse(res.value);
    return fallback;
  } catch (e) {
    return fallback;
  }
}
async function saveKey(key, value) {
  try {
    await store.set(key, JSON.stringify(value), false);
    return true;
  } catch (e) {
    return false;
  }
}
async function deleteKey(key) {
  try {
    await store.delete(key, false);
    return true;
  } catch (e) {
    return false;
  }
}
async function listPhotoKeys() {
  try {
    const res = await store.list("photo:");
    return res && res.keys || [];
  } catch (e) {
    return [];
  }
}
function useDebouncedSave(key, value, ready, onError, delay = 500) {
  const timer = useRef(null);
  useEffect(() => {
    if (!ready) return;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(async () => {
      const ok = await saveKey(key, value);
      if (!ok && onError) onError();
    }, delay);
    return () => clearTimeout(timer.current);
  }, [value, ready]);
}
function tenantKey(key, tenantId) {
  return `${tenantId}:${key}`;
}

// src/utils/batches.js
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function historyEvent(typ, opis, dane) {
  return { id: uid2("hev"), ts: nowIso(), typ, opis, dane: dane || null };
}
function weightedCost(qtyA, costA, qtyB, costB) {
  const totalQty = Number(qtyA || 0) + Number(qtyB || 0);
  if (totalQty <= 0) return 0;
  const raw = (Number(qtyA || 0) * Number(costA || 0) + Number(qtyB || 0) * Number(costB || 0)) / totalQty;
  return Math.round(raw * 100) / 100;
}
function slugify(text) {
  return (text || "").trim().toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 24);
}
function createBatch({ tenantId, plantId, source, initialQty, opis, existingBatches, customLabel }) {
  const numer = Math.max(0, ...(existingBatches || []).map((b) => Number(b.numer) || 0)) + 1;
  const now = nowIso();
  const dateStr = now.slice(0, 10).replace(/-/g, "");
  const sameDay = (existingBatches || []).filter((b) => (b.createdAt || "").slice(0, 10) === now.slice(0, 10));
  const dailySeq = sameDay.length + 1;
  const slug = slugify(customLabel);
  const kod = `${dateStr}-${dailySeq}${slug ? `-${slug}` : ""}`;
  const batch = {
    id: uid2("batch"),
    numer,
    kod,
    customLabel: customLabel || "",
    tenantId,
    plantId,
    source: source || { type: "zakup", parentBatchId: null, parentSegmentId: null },
    initialQty: Number(initialQty || 0),
    createdAt: now,
    status: "aktywna",
    closedAt: null,
    historia: []
  };
  batch.historia.push(historyEvent("zalozenie", opis || `Za\u0142o\u017Cono parti\u0119 (${batch.source.type}).`, { source: batch.source, initialQty: batch.initialQty }));
  return batch;
}
function closeBatchIfAllSegmentsEmpty(batch, allSegments) {
  if (!batch || batch.status === "zamknieta") return batch;
  const own = allSegments.filter((s) => s.batchId === batch.id);
  if (own.length === 0) return batch;
  const allEmpty = own.every((s) => s.status === "zamkniety" || Number(s.ilosc || 0) <= 0);
  if (!allEmpty) return batch;
  return {
    ...batch,
    status: "zamknieta",
    closedAt: nowIso(),
    historia: [...batch.historia, historyEvent("zamkniecie", "Zamkni\u0119to parti\u0119 \u2014 wszystkie segmenty wyzerowane.")]
  };
}
function createSegment({ tenantId, batchId, plantId, container, location, ilosc, kosztJednostkowy, originEventOpis, originEventDane, jakosc }) {
  const segment = {
    id: uid2("seg"),
    tenantId,
    batchId,
    plantId,
    container,
    location: location || null,
    ilosc: Number(ilosc || 0),
    kosztJednostkowy: Math.round(Number(kosztJednostkowy || 0) * 100) / 100,
    jakosc: jakosc || null,
    createdAt: nowIso(),
    updatedAt: nowIso(),
    status: "aktywny",
    closedAt: null,
    historia: []
  };
  segment.historia.push(historyEvent("zalozenie", originEventOpis || "Utworzono segment.", originEventDane));
  return segment;
}
var SEGMENT_QUALITY_VALUES = ["dobra", "do_obserwacji", "slaba"];
function setSegmentQuality({ segments, segmentId, jakosc }) {
  const segment = segments.find((s) => s.id === segmentId);
  if (!segment) return { ok: false, error: "Nie znaleziono segmentu.", segments };
  if (jakosc !== null && !SEGMENT_QUALITY_VALUES.includes(jakosc)) {
    return { ok: false, error: "Nieprawid\u0142owa warto\u015B\u0107 jako\u015Bci.", segments };
  }
  const updated = {
    ...segment,
    jakosc,
    historia: [...segment.historia, historyEvent("jakosc", `Oznaczono jako\u015B\u0107: ${jakosc || "brak"}.`, { jakosc })]
  };
  return { ok: true, segments: segments.map((s) => s.id === segmentId ? updated : s) };
}
function closeSegmentIfEmpty(segment) {
  if (!segment || segment.status === "zamkniety") return segment;
  if (Number(segment.ilosc || 0) > 0) return segment;
  return { ...segment, status: "zamkniety", closedAt: nowIso(), historia: [...segment.historia, historyEvent("zamkniecie", "Segment wyzerowany.")] };
}
function findActiveSegment(segments, { batchId, container, location }) {
  return segments.find(
    (s) => s.batchId === batchId && s.container === container && (s.location || null) === (location || null) && s.status === "aktywny"
  );
}
function transplantSegment({ segments, sourceSegmentId, ilosc, toContainer, toLocation = null, extraCostPerUnit = 0 }) {
  const source = segments.find((s) => s.id === sourceSegmentId);
  if (!source) return { ok: false, error: "Nie znaleziono segmentu \u017Ar\xF3d\u0142owego.", segments };
  const qty = Number(ilosc || 0);
  if (qty <= 0) return { ok: false, error: "Ilo\u015B\u0107 do przesadzenia musi by\u0107 wi\u0119ksza od zera.", segments };
  if (qty > Number(source.ilosc || 0)) return { ok: false, error: "Ilo\u015B\u0107 do przesadzenia przekracza stan segmentu \u017Ar\xF3d\u0142owego.", segments };
  if (toContainer === source.container && (toLocation || null) === (source.location || null)) {
    return { ok: false, error: "Pojemnik i lokalizacja docelowa s\u0105 takie same jak \u017Ar\xF3d\u0142owe.", segments };
  }
  const newUnitCost = Math.round((Number(source.kosztJednostkowy || 0) + Number(extraCostPerUnit || 0)) * 100) / 100;
  const existingTarget = findActiveSegment(segments, { batchId: source.batchId, container: toContainer, location: toLocation });
  const targetSegmentId = existingTarget ? existingTarget.id : uid2("seg");
  const commonDane = {
    batchId: source.batchId,
    ilosc: qty,
    zSegmentu: source.id,
    doSegmentu: targetSegmentId,
    zContainer: source.container,
    zLocation: source.location || null,
    doContainer: toContainer,
    doLocation: toLocation || null
  };
  let sourceUpdated = {
    ...source,
    ilosc: Number(source.ilosc || 0) - qty,
    updatedAt: nowIso(),
    historia: [
      ...source.historia,
      historyEvent("przesadzenie_z", `Przesadzono ${qty} szt. ${source.container}${source.location ? ` (${source.location})` : ""} \u2192 ${toContainer}${toLocation ? ` (${toLocation})` : ""}.`, commonDane)
    ]
  };
  sourceUpdated = closeSegmentIfEmpty(sourceUpdated);
  let next;
  if (existingTarget) {
    const blendedCost = weightedCost(existingTarget.ilosc, existingTarget.kosztJednostkowy, qty, newUnitCost);
    const targetUpdated = {
      ...existingTarget,
      ilosc: Number(existingTarget.ilosc || 0) + qty,
      kosztJednostkowy: blendedCost,
      updatedAt: nowIso(),
      historia: [
        ...existingTarget.historia,
        historyEvent("przesadzenie_do", `Przyj\u0119to ${qty} szt. z segmentu ${source.id} (${source.container}${source.location ? `, ${source.location}` : ""}).`, commonDane)
      ]
    };
    next = segments.map((s) => s.id === sourceUpdated.id ? sourceUpdated : s.id === targetUpdated.id ? targetUpdated : s);
  } else {
    const created = createSegment({
      tenantId: source.tenantId,
      batchId: source.batchId,
      plantId: source.plantId,
      container: toContainer,
      location: toLocation,
      ilosc: qty,
      kosztJednostkowy: newUnitCost,
      originEventOpis: `Utworzono przez przesadzenie ${qty} szt. z segmentu ${source.id} (${source.container}${source.location ? `, ${source.location}` : ""}).`,
      originEventDane: commonDane
    });
    const createdWithId = { ...created, id: targetSegmentId };
    next = segments.map((s) => s.id === sourceUpdated.id ? sourceUpdated : s).concat(createdWithId);
  }
  return { ok: true, segments: next, sourceSegmentId: sourceUpdated.id, targetSegmentId };
}
function divideSegment({ batches, segments, sourceSegmentId, zrodloUbytek = 0, nowePozycje, tenantId, opis }) {
  const source = segments.find((s) => s.id === sourceSegmentId);
  if (!source) return { ok: false, error: "Nie znaleziono segmentu \u017Ar\xF3d\u0142owego.", batches, segments };
  const ubytek = Number(zrodloUbytek || 0);
  if (ubytek < 0 || ubytek > Number(source.ilosc || 0)) {
    return { ok: false, error: "Nieprawid\u0142owy ubytek segmentu \u017Ar\xF3d\u0142owego.", batches, segments };
  }
  const pozycje = (nowePozycje || []).filter((p) => Number(p.ilosc || 0) > 0);
  if (pozycje.length === 0) return { ok: false, error: "Podaj przynajmniej jedn\u0105 now\u0105 pozycj\u0119 z ilo\u015Bci\u0105 wi\u0119ksz\u0105 od zera.", batches, segments };
  const totalNewQty = pozycje.reduce((s, p) => s + Number(p.ilosc || 0), 0);
  const newBatch = createBatch({
    tenantId: tenantId || source.tenantId,
    plantId: source.plantId,
    source: { type: "podzial", parentBatchId: source.batchId, parentSegmentId: source.id },
    initialQty: totalNewQty,
    opis: opis || `Powsta\u0142a z podzia\u0142u segmentu ${source.id} (partia ${source.batchId}).`,
    existingBatches: batches
  });
  const newSegments = pozycje.map(
    (p) => createSegment({
      tenantId: tenantId || source.tenantId,
      batchId: newBatch.id,
      plantId: source.plantId,
      container: p.container,
      location: p.location || null,
      ilosc: p.ilosc,
      kosztJednostkowy: p.kosztJednostkowy,
      originEventOpis: `Podzia\u0142: ${p.ilosc} szt. z segmentu ${source.id}.`,
      originEventDane: { zSegmentu: source.id, zPartii: source.batchId }
    })
  );
  let sourceUpdated = {
    ...source,
    ilosc: Number(source.ilosc || 0) - ubytek,
    updatedAt: nowIso(),
    historia: [
      ...source.historia,
      historyEvent("podzial_zrodlo", `Podzia\u0142: -${ubytek} szt. \u2192 nowa partia ${newBatch.id} (${totalNewQty} szt.).`, { ubytek, doPartii: newBatch.id, nowaIlosc: totalNewQty })
    ]
  };
  sourceUpdated = closeSegmentIfEmpty(sourceUpdated);
  let nextSegments = segments.map((s) => s.id === sourceUpdated.id ? sourceUpdated : s).concat(newSegments);
  let nextBatches = batches.concat(newBatch);
  const sourceBatch = nextBatches.find((b) => b.id === source.batchId);
  if (sourceBatch) {
    const maybeClosedSourceBatch = closeBatchIfAllSegmentsEmpty(sourceBatch, nextSegments);
    nextBatches = nextBatches.map((b) => b.id === maybeClosedSourceBatch.id ? maybeClosedSourceBatch : b);
  }
  return { ok: true, batches: nextBatches, segments: nextSegments, newBatchId: newBatch.id };
}
function decreaseSegment({ batches, segments, segmentId, ilosc, typ, opis, dane }) {
  const segment = segments.find((s) => s.id === segmentId);
  if (!segment) return { ok: false, error: "Nie znaleziono segmentu.", batches, segments };
  const qty = Number(ilosc || 0);
  if (qty <= 0 || qty > Number(segment.ilosc || 0)) return { ok: false, error: "Nieprawid\u0142owa ilo\u015B\u0107.", batches, segments };
  let updated = {
    ...segment,
    ilosc: Number(segment.ilosc || 0) - qty,
    updatedAt: nowIso(),
    historia: [...segment.historia, historyEvent(typ, opis, dane)]
  };
  updated = closeSegmentIfEmpty(updated);
  let nextSegments = segments.map((s) => s.id === updated.id ? updated : s);
  let nextBatches = batches;
  const batch = batches.find((b) => b.id === segment.batchId);
  if (batch) {
    const maybeClosed = closeBatchIfAllSegmentsEmpty(batch, nextSegments);
    nextBatches = batches.map((b) => b.id === maybeClosed.id ? maybeClosed : b);
  }
  return { ok: true, batches: nextBatches, segments: nextSegments };
}
function recordSegmentLoss({ batches, segments, segmentId, ilosc, powod, komentarz }) {
  const segment = segments.find((s) => s.id === segmentId);
  const qty = Number(ilosc || 0);
  const wartosc = segment ? Math.round(qty * Number(segment.kosztJednostkowy || 0) * 100) / 100 : 0;
  return decreaseSegment({
    batches,
    segments,
    segmentId,
    ilosc,
    typ: "strata",
    opis: `Strata: ${qty} szt. \u2014 ${powod || "brak podanego powodu"}.${komentarz ? ` (${komentarz})` : ""}`,
    dane: { ilosc: qty, powod: powod || null, komentarz: komentarz || null, wartosc }
  });
}
function recordSegmentRemoval({ batches, segments, segmentId, ilosc, powod, komentarz }) {
  const qty = Number(ilosc || 0);
  return decreaseSegment({
    batches,
    segments,
    segmentId,
    ilosc,
    typ: "usuniecie",
    opis: `Usuni\u0119cie: ${qty} szt. \u2014 ${powod || "brak podanego powodu"}.${komentarz ? ` (${komentarz})` : ""}`,
    dane: { ilosc: qty, powod: powod || null, komentarz: komentarz || null }
  });
}
function recordSegmentInventoryCorrection({ batches, segments, segmentId, stanSystemowy, stanFizyczny, powod }) {
  const roznica = Number(stanFizyczny || 0) - Number(stanSystemowy || 0);
  const ubytek = Math.abs(roznica);
  return decreaseSegment({
    batches,
    segments,
    segmentId,
    ilosc: ubytek,
    typ: "inwentaryzacja_korekta",
    opis: `Inwentaryzacja: ${roznica} szt. Stan systemowy: ${stanSystemowy}. Stan fizyczny: ${stanFizyczny}. Pow\xF3d: ${powod || "brak podanego powodu"}.`,
    dane: { stanSystemowy: Number(stanSystemowy || 0), stanFizyczny: Number(stanFizyczny || 0), roznica, powod: powod || null }
  });
}
function recordSegmentSale({ batches, segments, segmentId, ilosc, cena, orderId }) {
  const segment = segments.find((s) => s.id === segmentId);
  if (!segment) return { ok: false, error: "Nie znaleziono segmentu.", batches, segments };
  const qty = Number(ilosc || 0);
  if (qty <= 0 || qty > Number(segment.ilosc || 0)) return { ok: false, error: "Nieprawid\u0142owa ilo\u015B\u0107 sprzeda\u017Cy.", batches, segments };
  const kosztCalosci = Math.round(qty * Number(segment.kosztJednostkowy || 0) * 100) / 100;
  let updated = {
    ...segment,
    ilosc: Number(segment.ilosc || 0) - qty,
    updatedAt: nowIso(),
    historia: [...segment.historia, historyEvent("sprzedaz", `Sprzedano ${qty} szt.`, { ilosc: qty, cena: Number(cena || 0), koszt: kosztCalosci, orderId: orderId || null })]
  };
  updated = closeSegmentIfEmpty(updated);
  let nextSegments = segments.map((s) => s.id === updated.id ? updated : s);
  let nextBatches = batches;
  const batch = batches.find((b) => b.id === segment.batchId);
  if (batch) {
    const maybeClosed = closeBatchIfAllSegmentsEmpty(batch, nextSegments);
    nextBatches = batches.map((b) => b.id === maybeClosed.id ? maybeClosed : b);
  }
  return { ok: true, batches: nextBatches, segments: nextSegments };
}
function sumEventQty(historia, typ) {
  return historia.filter((h) => h.typ === typ).reduce((sum, h) => sum + Number(h.dane && (h.dane.nowaIlosc ?? h.dane.ilosc) || 0), 0);
}
function computeBatchStats(batch, allSegments) {
  const own = allSegments.filter((s) => s.batchId === batch.id);
  const active = own.filter((s) => s.status === "aktywny");
  const closed = own.filter((s) => s.status === "zamkniety");
  const currentQty = active.reduce((sum, s) => sum + Number(s.ilosc || 0), 0);
  const propagatedQty = own.reduce((sum, s) => sum + sumEventQty(s.historia, "podzial_zrodlo"), 0);
  const lossQty = own.reduce((sum, s) => sum + sumEventQty(s.historia, "strata"), 0);
  const soldQty = own.reduce((sum, s) => sum + sumEventQty(s.historia, "sprzedaz"), 0);
  return {
    initialQty: Number(batch.initialQty || 0),
    currentQty,
    propagatedQty,
    lossQty,
    soldQty,
    activeSegmentCount: active.length,
    closedSegmentCount: closed.length
  };
}
function computeAllBatchStats(batches, segments) {
  const result = {};
  batches.forEach((b) => {
    result[b.id] = computeBatchStats(b, segments);
  });
  return result;
}

// src/utils/productionPlans.js
var PLAN_STATUS_VALUES = ["planowane", "wykonane", "anulowane"];
function createProductionPlan({ plantId, sourceSegmentId, targetContainer, targetLocation, expectedQty, plannedYear, plannedMonth, note }) {
  return {
    id: uid2("plan"),
    plantId,
    sourceSegmentId: sourceSegmentId || null,
    targetContainer: targetContainer || null,
    targetLocation: targetLocation || null,
    expectedQty: Number(expectedQty || 0),
    plannedYear: Number(plannedYear),
    plannedMonth: Number(plannedMonth),
    note: note || "",
    status: "planowane",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function setPlanStatus(plans, planId, status) {
  if (!PLAN_STATUS_VALUES.includes(status)) return { ok: false, error: "Nieprawid\u0142owy status.", plans };
  const plan = plans.find((p) => p.id === planId);
  if (!plan) return { ok: false, error: "Nie znaleziono planu.", plans };
  const updated = { ...plan, status, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  return { ok: true, plans: plans.map((p) => p.id === planId ? updated : p) };
}

// src/components/layout/GrassMark.jsx
function GrassMark() {
  return /* @__PURE__ */ React.createElement("svg", { width: "30", height: "30", viewBox: "0 0 30 30", className: "grass-mark" }, /* @__PURE__ */ React.createElement("path", { d: "M15 28 C 13 20, 13 12, 9 3", fill: "none", stroke: "var(--brand)", strokeWidth: "1.6", strokeLinecap: "round", className: "blade b1" }), /* @__PURE__ */ React.createElement("path", { d: "M15 28 C 15 19, 15 10, 15 2", fill: "none", stroke: "var(--gold)", strokeWidth: "1.6", strokeLinecap: "round", className: "blade b2" }), /* @__PURE__ */ React.createElement("path", { d: "M15 28 C 17 20, 17 12, 21 3", fill: "none", stroke: "var(--brand)", strokeWidth: "1.6", strokeLinecap: "round", className: "blade b3" }));
}
function GrassDivider() {
  const blades = Array.from({ length: 18 });
  return /* @__PURE__ */ React.createElement("div", { className: "grass-divider", "aria-hidden": "true" }, blades.map((_, i) => /* @__PURE__ */ React.createElement("span", { key: i, className: `gd-blade gd-${i % 3}`, style: { animationDelay: `${i % 6 * 0.18}s` } })));
}

// src/components/layout/Header.jsx
function Header({ tab, potsTotal }) {
  return /* @__PURE__ */ React.createElement("header", { className: "app-header" }, /* @__PURE__ */ React.createElement("div", { className: "app-header-row" }, /* @__PURE__ */ React.createElement("div", { className: "brand" }, /* @__PURE__ */ React.createElement(GrassMark, null), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "brand-title" }, "Szk\xF3\u0142ka traw"), /* @__PURE__ */ React.createElement("div", { className: "brand-sub" }, TAB_TITLES[tab]))), /* @__PURE__ */ React.createElement("div", { className: "header-totals" }, /* @__PURE__ */ React.createElement("span", null, potsTotal), /* @__PURE__ */ React.createElement("small", null, "szt. w donicach"))), /* @__PURE__ */ React.createElement(GrassDivider, null));
}

// src/components/layout/BottomNav.jsx
import { Home, Package, Calendar, ShoppingCart, Tag } from "lucide-react";
function BottomNav({ tab, setTab }) {
  const items = [
    { id: "pulpit", label: "Pulpit", icon: Home },
    { id: "magazyn", label: "Magazyn", icon: Package },
    { id: "harmonogram", label: "Terminarz", icon: Calendar },
    { id: "sprzedaz", label: "Sprzeda\u017C", icon: ShoppingCart },
    { id: "etykiety", label: "Etykiety", icon: Tag }
  ];
  return /* @__PURE__ */ React.createElement("nav", { className: "bottom-nav" }, items.map((it) => {
    const Icon = it.icon;
    const active = tab === it.id;
    return /* @__PURE__ */ React.createElement("button", { key: it.id, className: `nav-btn ${active ? "active" : ""}`, onClick: () => setTab(it.id) }, /* @__PURE__ */ React.createElement(Icon, { size: 20, strokeWidth: active ? 2.4 : 1.9 }), /* @__PURE__ */ React.createElement("span", null, it.label));
  }));
}

// src/components/pulpit/PulpitTab.jsx
import { useState as useState4 } from "react";
import { AlertTriangle, Clock, Shield, Download, Upload, X, Copy, ClipboardPaste, Search } from "lucide-react";

// src/components/magazyn/PartiePanel.jsx
import { useState, useMemo, useEffect as useEffect2 } from "react";
import { ChevronLeft, ChevronRight, Camera, Trash2 } from "lucide-react";
function shortId(id) {
  return id ? id.slice(-6) : "\u2014";
}
function batchLabel(batch) {
  if (!batch) return "\u2014";
  if (batch.kod) return batch.kod;
  return batch.numer ? `#${batch.numer}` : `ID ${shortId(batch.id)}`;
}
function sourceLabel(batch) {
  const src = batch.source || {};
  if (src.type === "podzial") return "Podzia\u0142";
  if (src.type === "korekta") return "Korekta (nieznane pochodzenie)";
  return "Zakup";
}
function plantName(plants, plantId) {
  const p = plants.find((pp) => pp.id === plantId);
  return p ? `${p.nazwa_pl} \u2014 ${p.odmiana}` : plantId;
}
function PartiePanel({ plants, batches, batchSegments, onSetSegmentQuality, batchPhotos, onAddBatchPhoto, onDeleteBatchPhoto, photos, onPhotoError, jumpToBatchId, jumpToken }) {
  const [filterPlantId, setFilterPlantId] = useState("");
  const [showClosed, setShowClosed] = useState(false);
  const [selectedBatchId, setSelectedBatchId] = useState(null);
  useEffect2(() => {
    if (jumpToken) setSelectedBatchId(jumpToBatchId);
  }, [jumpToken]);
  const stats = useMemo(() => computeAllBatchStats(batches, batchSegments), [batches, batchSegments]);
  const visibleBatches = useMemo(() => {
    let list = batches;
    if (filterPlantId) list = list.filter((b) => b.plantId === filterPlantId);
    if (!showClosed) list = list.filter((b) => b.status === "aktywna");
    return [...list].sort((a, b) => {
      if (a.status !== b.status) return a.status === "aktywna" ? -1 : 1;
      return new Date(b.createdAt) - new Date(a.createdAt);
    });
  }, [batches, filterPlantId, showClosed]);
  const selectedBatch = selectedBatchId ? batches.find((b) => b.id === selectedBatchId) : null;
  if (selectedBatch) {
    return /* @__PURE__ */ React.createElement(
      BatchDetail,
      {
        batch: selectedBatch,
        batches,
        batchSegments,
        plants,
        onSelectBatch: setSelectedBatchId,
        onBack: () => setSelectedBatchId(null),
        onSetSegmentQuality,
        batchPhotos,
        onAddBatchPhoto,
        onDeleteBatchPhoto,
        photos,
        onPhotoError
      }
    );
  }
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 12 } }, "Przegl\u0105d partii i ich pochodzenia \u2014 wy\u0142\u0105cznie do odczytu. Kliknij parti\u0119, \u017Ceby zobaczy\u0107 segmenty, histori\u0119 i powi\u0105zania rodzic/dziecko."), /* @__PURE__ */ React.createElement("div", { className: "order-form", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana"), /* @__PURE__ */ React.createElement("select", { value: filterPlantId, onChange: (e) => setFilterPlantId(e.target.value) }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 wszystkie \u2014"), plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana)))), /* @__PURE__ */ React.createElement("label", { className: "checkbox-field" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: showClosed, onChange: (e) => setShowClosed(e.target.checked) }), /* @__PURE__ */ React.createElement("span", null, "Poka\u017C te\u017C zamkni\u0119te partie"))), /* @__PURE__ */ React.createElement("div", { className: "order-list" }, visibleBatches.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, batches.length === 0 ? "Brak jeszcze \u017Cadnej \u015Bledzonej partii. Partie powstaj\u0105, gdy w Zakupie/Podziale/Inwentaryzacji zaznaczysz \u201E\u015Aled\u017A jako parti\u0119\u201D." : "Brak partii pasuj\u0105cych do filtra."), visibleBatches.map((b) => {
    const s = stats[b.id];
    return /* @__PURE__ */ React.createElement("div", { key: b.id, className: "order-card" }, /* @__PURE__ */ React.createElement("button", { className: "order-card-head", onClick: () => setSelectedBatchId(b.id) }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, plantName(plants, b.plantId), " ", /* @__PURE__ */ React.createElement("span", { className: "order-date" }, "\xB7 Partia ", batchLabel(b))), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, sourceLabel(b, plants), " \xB7 ", s.currentQty, " / ", b.initialQty, " szt. \xB7 ", s.activeSegmentCount, " aktywn.", s.activeSegmentCount === 1 ? "y segment" : " segmenty/\xF3w", b.status === "zamknieta" ? " \xB7 zamkni\u0119ta" : "")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement(ChevronRight, { size: 16 }))));
  })));
}
var QUALITY_LABELS = { dobra: "Dobra", do_obserwacji: "Do obserwacji", slaba: "S\u0142aba" };
function QualityBadge({ jakosc }) {
  if (!jakosc) return null;
  if (jakosc === "slaba") {
    return /* @__PURE__ */ React.createElement("span", { className: "status-badge new", style: { background: "transparent", border: "1px solid var(--danger, #c0392b)", color: "var(--danger, #c0392b)" } }, QUALITY_LABELS.slaba);
  }
  return /* @__PURE__ */ React.createElement("span", { className: `status-badge ${jakosc === "dobra" ? "ok" : "new"}` }, QUALITY_LABELS[jakosc] || jakosc);
}
function BatchDetail({ batch, batches, batchSegments, plants, onSelectBatch, onBack, onSetSegmentQuality, batchPhotos, onAddBatchPhoto, onDeleteBatchPhoto, photos, onPhotoError }) {
  const s = computeAllBatchStats([batch], batchSegments)[batch.id];
  const ownSegments = batchSegments.filter((seg) => seg.batchId === batch.id);
  const activeSegments = ownSegments.filter((seg) => seg.status === "aktywny");
  const closedSegments = ownSegments.filter((seg) => seg.status === "zamkniety");
  const [showClosedSegments, setShowClosedSegments] = useState(false);
  const parentBatch = batch.source?.parentBatchId ? batches.find((b) => b.id === batch.source.parentBatchId) : null;
  const parentSegment = batch.source?.parentSegmentId ? batchSegments.find((seg) => seg.id === batch.source.parentSegmentId) : null;
  const childBatches = batches.filter((b) => b.source?.parentBatchId === batch.id);
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("button", { className: "ghost-btn", style: { marginTop: 12 }, onClick: onBack }, /* @__PURE__ */ React.createElement(ChevronLeft, { size: 15 }), " Wszystkie partie"), /* @__PURE__ */ React.createElement("div", { className: "order-card", style: { marginTop: 10 } }, /* @__PURE__ */ React.createElement("div", { className: "order-card-head static" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, plantName(plants, batch.plantId)), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, "Partia ", batchLabel(batch), " \xB7 ", sourceLabel(batch, plants), " \xB7 ", batch.status === "aktywna" ? "aktywna" : "zamkni\u0119ta")))), onAddBatchPhoto && /* @__PURE__ */ React.createElement(
    BatchPhotoGallery,
    {
      batchId: batch.id,
      entries: (batchPhotos || {})[batch.id] || [],
      photos: photos || {},
      onAdd: onAddBatchPhoto,
      onDelete: onDeleteBatchPhoto,
      onError: onPhotoError
    }
  ), parentBatch && /* @__PURE__ */ React.createElement("div", { className: "order-card", style: { marginTop: 8 } }, /* @__PURE__ */ React.createElement("button", { className: "order-card-head", onClick: () => onSelectBatch(parentBatch.id) }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, /* @__PURE__ */ React.createElement(ChevronLeft, { size: 14, style: { verticalAlign: "middle" } }), " Partia \u017Ar\xF3d\u0142owa"), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, plantName(plants, parentBatch.plantId), " \xB7 Partia ", batchLabel(parentBatch), parentSegment ? ` \xB7 segment: ${containerLabel(parentSegment.container)}${parentSegment.location ? ` (${parentSegment.location})` : ""}` : "")))), /* @__PURE__ */ React.createElement("div", { className: "totals-row", style: { marginTop: 12 } }, /* @__PURE__ */ React.createElement("div", { className: "totals-chip" }, /* @__PURE__ */ React.createElement("span", { className: "totals-num" }, s.initialQty), /* @__PURE__ */ React.createElement("span", { className: "totals-label" }, "pocz\u0105tkowa")), /* @__PURE__ */ React.createElement("div", { className: "totals-chip" }, /* @__PURE__ */ React.createElement("span", { className: "totals-num" }, s.currentQty), /* @__PURE__ */ React.createElement("span", { className: "totals-label" }, "obecna")), /* @__PURE__ */ React.createElement("div", { className: "totals-chip" }, /* @__PURE__ */ React.createElement("span", { className: "totals-num" }, s.propagatedQty), /* @__PURE__ */ React.createElement("span", { className: "totals-label" }, "rozmno\u017Cona")), /* @__PURE__ */ React.createElement("div", { className: "totals-chip" }, /* @__PURE__ */ React.createElement("span", { className: "totals-num" }, s.lossQty), /* @__PURE__ */ React.createElement("span", { className: "totals-label" }, "strata")), /* @__PURE__ */ React.createElement("div", { className: "totals-chip" }, /* @__PURE__ */ React.createElement("span", { className: "totals-num" }, s.soldQty), /* @__PURE__ */ React.createElement("span", { className: "totals-label" }, "sprzedana"))), /* @__PURE__ */ React.createElement("div", { className: "section-title small-title", style: { marginTop: 16 } }, "Aktywne segmenty (", activeSegments.length, ")"), activeSegments.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak aktywnych segment\xF3w."), activeSegments.map((seg) => /* @__PURE__ */ React.createElement("div", { key: seg.id, className: "order-card" }, /* @__PURE__ */ React.createElement("div", { className: "order-card-head static" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, containerLabel(seg.container), seg.location ? ` \u2014 ${seg.location}` : "", " ", /* @__PURE__ */ React.createElement(QualityBadge, { jakosc: seg.jakosc })), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, seg.ilosc, " szt. \xD7 ", money(seg.kosztJednostkowy), " z\u0142/szt.")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement("span", { className: "order-sum" }, money(seg.ilosc * seg.kosztJednostkowy), " z\u0142"))), onSetSegmentQuality && /* @__PURE__ */ React.createElement("div", { className: "order-card-body" }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Jako\u015B\u0107 (obserwacja \u2014 nie wp\u0142ywa na ilo\u015B\u0107 ani koszt)"), /* @__PURE__ */ React.createElement("select", { value: seg.jakosc || "", onChange: (e) => onSetSegmentQuality(seg.id, e.target.value || null) }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 nieoznaczona \u2014"), /* @__PURE__ */ React.createElement("option", { value: "dobra" }, "Dobra"), /* @__PURE__ */ React.createElement("option", { value: "do_obserwacji" }, "Do obserwacji"), /* @__PURE__ */ React.createElement("option", { value: "slaba" }, "S\u0142aba")))))), /* @__PURE__ */ React.createElement("div", { className: "section-title small-title", style: { marginTop: 16, cursor: "pointer" }, onClick: () => setShowClosedSegments((v) => !v) }, "Zamkni\u0119te segmenty (", closedSegments.length, ") ", closedSegments.length > 0 ? showClosedSegments ? "\u25BE" : "\u25B8" : ""), showClosedSegments && closedSegments.map((seg) => /* @__PURE__ */ React.createElement("div", { key: seg.id, className: "order-card" }, /* @__PURE__ */ React.createElement("div", { className: "order-card-head static" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, containerLabel(seg.container), seg.location ? ` \u2014 ${seg.location}` : ""), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, "0 szt. (zamkni\u0119ty) \xB7 ostatni koszt ", money(seg.kosztJednostkowy), " z\u0142/szt."))))), childBatches.length > 0 && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "section-title small-title", style: { marginTop: 16 } }, "Partie potomne (", childBatches.length, ")"), childBatches.map((cb) => /* @__PURE__ */ React.createElement("div", { key: cb.id, className: "order-card" }, /* @__PURE__ */ React.createElement("button", { className: "order-card-head", onClick: () => onSelectBatch(cb.id) }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, plantName(plants, cb.plantId), " \xB7 Partia ", batchLabel(cb)), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, cb.status === "aktywna" ? "aktywna" : "zamkni\u0119ta")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement(ChevronRight, { size: 16 })))))), /* @__PURE__ */ React.createElement("div", { className: "section-title small-title", style: { marginTop: 16 } }, "Historia partii"), /* @__PURE__ */ React.createElement("div", { className: "log-list" }, batch.historia.map((h) => /* @__PURE__ */ React.createElement("div", { key: h.id, className: "log-row" }, /* @__PURE__ */ React.createElement("span", { className: "log-time" }, formatLogTime(h.ts)), /* @__PURE__ */ React.createElement("span", { className: "log-text" }, h.opis)))));
}
function BatchPhotoGallery({ batchId, entries, photos, onAdd, onDelete, onError }) {
  const sorted = [...entries].sort((a, b) => new Date(b.ts) - new Date(a.ts));
  async function handleFile(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    try {
      const dataUrl = await resizeImageToDataUrl(file);
      onAdd(batchId, dataUrl);
    } catch (err) {
      onError && onError();
    }
  }
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "section-title small-title", style: { marginTop: 16 } }, "Zdj\u0119cia partii w czasie (", sorted.length, ")"), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 8 } }, sorted.map((entry) => /* @__PURE__ */ React.createElement("div", { key: entry.id, style: { position: "relative" } }, /* @__PURE__ */ React.createElement("div", { className: "photo-thumb", style: { width: 72, height: 72, cursor: "default" } }, photos[entry.id] ? /* @__PURE__ */ React.createElement("img", { src: photos[entry.id], alt: "" }) : /* @__PURE__ */ React.createElement(Camera, { size: 16 })), /* @__PURE__ */ React.createElement(
    "button",
    {
      className: "icon-btn danger",
      style: { position: "absolute", top: -6, right: -6, background: "var(--surface)", borderRadius: "50%" },
      onClick: () => onDelete(batchId, entry.id),
      "aria-label": "Usu\u0144 zdj\u0119cie"
    },
    /* @__PURE__ */ React.createElement(Trash2, { size: 12 })
  ), /* @__PURE__ */ React.createElement("div", { className: "order-date", style: { textAlign: "center", marginTop: 2, fontSize: 10 } }, formatLogTime(entry.ts)))), /* @__PURE__ */ React.createElement("label", { className: "photo-thumb", style: { width: 72, height: 72 }, "aria-label": "Dodaj zdj\u0119cie partii" }, /* @__PURE__ */ React.createElement(Camera, { size: 16 }), /* @__PURE__ */ React.createElement("input", { type: "file", accept: "image/*", onChange: handleFile, className: "visually-hidden-input" }))));
}

// src/components/harmonogram/helpers.js
function buildMonthTasks(plants, month, batchSegments, batches) {
  const tasks = [];
  plants.forEach((p) => {
    if (p.ciecie_months.includes(month)) tasks.push({ plant: p, type: p.special ? "pielegnacja" : "ciecie" });
    if (p.podzial_months.includes(month)) {
      const segments = (batchSegments || []).filter((s) => s.plantId === p.id && s.status === "aktywny" && Number(s.ilosc || 0) > 0).map((s) => ({ ...s, resolvedBatchLabel: batchLabel((batches || []).find((b) => b.id === s.batchId)) }));
      tasks.push({ plant: p, type: "podzial", segments });
    }
  });
  return tasks;
}
var TASK_META = {
  ciecie: { label: "Ci\u0119cie", cls: "tag-ciecie" },
  podzial: { label: "Podzia\u0142", cls: "tag-podzial" },
  pielegnacja: { label: "Piel\u0119gnacja", cls: "tag-pielegnacja" }
};
function tasksForMonth(tasks, year, month) {
  return tasks.filter((t) => {
    if (!t.date) return false;
    const parts = t.date.split("-");
    return Number(parts[0]) === year && Number(parts[1]) === month;
  });
}

// src/components/pulpit/TasksSection.jsx
import { useState as useState2 } from "react";
import { ListPlus, Trash2 as Trash22, Calendar as Calendar2 } from "lucide-react";
function TasksSection({ tasks, onAdd, onCycle, onDelete }) {
  const [text, setText] = useState2("");
  const [date, setDate] = useState2("");
  const [dateOpen, setDateOpen] = useState2(false);
  const [showDone, setShowDone] = useState2(false);
  const pending = tasks.filter((t) => t.status !== "done");
  const doneTasks = tasks.filter((t) => t.status === "done");
  function submit() {
    if (!text.trim()) return;
    onAdd(text, date || null);
    setText("");
    setDate("");
    setDateOpen(false);
  }
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "section-title", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement(ListPlus, { size: 17 }), /* @__PURE__ */ React.createElement("span", null, "Zadania", pending.length ? ` (${pending.length})` : "")), /* @__PURE__ */ React.createElement("div", { className: "add-task-form", style: { marginBottom: date || dateOpen ? 6 : 10 } }, /* @__PURE__ */ React.createElement(
    "input",
    {
      placeholder: "np. Zam\xF3wi\u0107 C5, umy\u0107 tunel\u2026",
      value: text,
      onChange: (e) => setText(e.target.value),
      onKeyDown: (e) => {
        if (e.key === "Enter") submit();
      }
    }
  ), /* @__PURE__ */ React.createElement("button", { type: "button", className: `icon-btn calendar-toggle ${date ? "active" : ""}`, onClick: () => setDateOpen(!dateOpen), "aria-label": "Ustaw termin" }, /* @__PURE__ */ React.createElement(Calendar2, { size: 16 })), /* @__PURE__ */ React.createElement("button", { className: "primary-btn small", onClick: submit, disabled: !text.trim() }, "Dodaj")), dateOpen && /* @__PURE__ */ React.createElement("div", { className: "add-task-form", style: { marginBottom: 10 } }, /* @__PURE__ */ React.createElement("input", { type: "date", value: date, onChange: (e) => setDate(e.target.value) }), date && /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => setDate("") }, "Wyczy\u015B\u0107")), pending.length === 0 ? /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak zada\u0144 w toku.") : /* @__PURE__ */ React.createElement("div", { className: "task-list", style: { marginBottom: 8 } }, pending.map((t) => {
    const meta = TASK_STATUS_META[t.status];
    return /* @__PURE__ */ React.createElement("div", { key: t.id, className: "task-row custom-row" }, t.date && /* @__PURE__ */ React.createElement("span", { className: "task-date-badge" }, /* @__PURE__ */ React.createElement(Calendar2, { size: 11 }), " ", formatShortDate(t.date)), /* @__PURE__ */ React.createElement("button", { className: "task-text-btn", onClick: () => onCycle(t.id) }, /* @__PURE__ */ React.createElement("span", { className: "task-plant" }, t.text)), /* @__PURE__ */ React.createElement("button", { className: `task-tag status-tag ${meta.cls}`, onClick: () => onCycle(t.id) }, meta.label), /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => onDelete(t.id) }, /* @__PURE__ */ React.createElement(Trash22, { size: 14 })));
  })), doneTasks.length > 0 && /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("button", { className: "ghost-btn", style: { width: "100%", justifyContent: "center" }, onClick: () => setShowDone(!showDone) }, showDone ? "Ukryj" : "Poka\u017C", " zako\u0144czone (", doneTasks.length, ")"), showDone && /* @__PURE__ */ React.createElement("div", { className: "task-list", style: { marginTop: 8 } }, doneTasks.map((t) => /* @__PURE__ */ React.createElement("div", { key: t.id, className: "task-row custom-row done" }, /* @__PURE__ */ React.createElement("button", { className: "task-text-btn", onClick: () => onCycle(t.id) }, /* @__PURE__ */ React.createElement("span", { className: "task-plant" }, t.text)), /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => onDelete(t.id) }, /* @__PURE__ */ React.createElement(Trash22, { size: 14 })))))));
}

// src/components/magazyn/ZaleglosciPanel.jsx
import { useState as useState3, useMemo as useMemo2 } from "react";
function daysSince(iso, nowMs) {
  if (!iso) return null;
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return null;
  return Math.max(0, Math.floor((nowMs - then) / (1e3 * 60 * 60 * 24)));
}
function sortByStaleness(batchSegments, nowMs) {
  return (batchSegments || []).filter((s) => s.status === "aktywny" && Number(s.ilosc || 0) > 0).map((s) => ({ ...s, daysIdle: daysSince(s.updatedAt, nowMs) })).sort((a, b) => (b.daysIdle ?? 0) - (a.daysIdle ?? 0));
}
function ZaleglosciPanel({ plants, batches, batchSegments }) {
  const [filterPlantId, setFilterPlantId] = useState3("");
  const nowMs = useMemo2(() => Date.now(), []);
  const sorted = useMemo2(() => sortByStaleness(batchSegments, nowMs), [batchSegments, nowMs]);
  const visible = useMemo2(
    () => filterPlantId ? sorted.filter((s) => s.plantId === filterPlantId) : sorted,
    [sorted, filterPlantId]
  );
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 12 } }, "Aktywne segmenty posortowane od najd\u0142u\u017Cej bez \u017Cadnej operacji (podzia\u0142u, przesadzenia, sprzeda\u017Cy, straty...) \u2014 pomaga wychwyci\u0107 towar, kt\xF3ry si\u0119 zalega."), /* @__PURE__ */ React.createElement("div", { className: "order-form", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana"), /* @__PURE__ */ React.createElement("select", { value: filterPlantId, onChange: (e) => setFilterPlantId(e.target.value) }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 wszystkie \u2014"), plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana))))), /* @__PURE__ */ React.createElement("div", { className: "order-list" }, visible.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak aktywnych segment\xF3w", filterPlantId ? " dla wybranej odmiany" : "", "."), visible.map((s) => {
    const batch = (batches || []).find((b) => b.id === s.batchId);
    return /* @__PURE__ */ React.createElement("div", { key: s.id, className: "order-card" }, /* @__PURE__ */ React.createElement("div", { className: "order-card-head static" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, plantName(plants, s.plantId), s.jakosc ? ` \xB7 ${QUALITY_LABELS[s.jakosc] || s.jakosc}` : ""), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, containerLabel(s.container), s.location ? ` \u2014 ${s.location}` : "", " \xB7 ", s.ilosc, " szt. \xD7 ", money(s.kosztJednostkowy), " z\u0142/szt. \xB7 Partia ", batchLabel(batch))), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement("span", { className: "order-sum" }, s.daysIdle, " dni"), /* @__PURE__ */ React.createElement("span", { className: "order-date" }, "bez ruchu"))));
  })));
}

// src/components/pulpit/PulpitTab.jsx
function buildAttentionCenter(now, productionPlans, batchSegments, supplies, orders) {
  const nowMs = now.getTime();
  const plansDue = (productionPlans || []).filter(
    (p) => p.status === "planowane" && p.plannedYear === now.getFullYear() && p.plannedMonth === now.getMonth() + 1
  );
  const staleSegments = (batchSegments || []).filter((s) => s.status === "aktywny" && Number(s.ilosc || 0) > 0).map((s) => ({ ...s, daysIdle: daysSince(s.updatedAt, nowMs) })).filter((s) => (s.daysIdle ?? 0) > 60).sort((a, b) => (b.daysIdle || 0) - (a.daysIdle || 0));
  const lowSupplies = (supplies || []).filter((s) => s.prog != null && Number(s.ilosc) <= Number(s.prog));
  const pendingOrders = (orders || []).filter((o) => o.status !== "zrealizowane");
  return { plansDue, staleSegments, lowSupplies, pendingOrders };
}
function searchBatches(batches, plants, rawQuery) {
  const query = (rawQuery || "").trim();
  if (!query) return [];
  const numericQuery = query.replace(/^#/, "");
  const isNumeric = /^\d+$/.test(numericQuery);
  const lowerQuery = query.toLowerCase();
  const results = batches.filter((b) => {
    if (isNumeric && b.numer === Number(numericQuery)) return true;
    const p = plants.find((pp) => pp.id === b.plantId);
    if (p && (p.nazwa_pl.toLowerCase().includes(lowerQuery) || p.odmiana.toLowerCase().includes(lowerQuery))) return true;
    return false;
  });
  return results.sort((a, b) => {
    const aExact = isNumeric && a.numer === Number(numericQuery) ? 0 : 1;
    const bExact = isNumeric && b.numer === Number(numericQuery) ? 0 : 1;
    if (aExact !== bExact) return aExact - bExact;
    return (b.numer || 0) - (a.numer || 0);
  }).slice(0, 8);
}
function BackupModal({ onClose, getBackupText, onImportText }) {
  const [mode, setMode] = useState4("export");
  const [pasteValue, setPasteValue] = useState4("");
  const [copyStatus, setCopyStatus] = useState4("");
  const backupText = mode === "export" ? getBackupText() : "";
  function copyToClipboard(text, onDone, target) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(onDone).catch(() => fallbackCopy(target, onDone));
    } else {
      fallbackCopy(target, onDone);
    }
  }
  function fallbackCopy(target, onDone) {
    try {
      if (target) {
        target.select();
        document.execCommand("copy");
        onDone();
      }
    } catch (e) {
      setCopyStatus("Nie uda\u0142o si\u0119 skopiowa\u0107 \u2014 zaznacz tekst r\u0119cznie i skopiuj.");
    }
  }
  return /* @__PURE__ */ React.createElement("div", { className: "modal-overlay", onClick: onClose }, /* @__PURE__ */ React.createElement("div", { className: "modal-box", onClick: (e) => e.stopPropagation() }, /* @__PURE__ */ React.createElement("div", { className: "modal-header" }, /* @__PURE__ */ React.createElement("span", null, "Kopia zapasowa"), /* @__PURE__ */ React.createElement("button", { className: "icon-btn", onClick: onClose }, /* @__PURE__ */ React.createElement(X, { size: 18 }))), /* @__PURE__ */ React.createElement("div", { className: "form-actions", style: { marginBottom: 10 } }, /* @__PURE__ */ React.createElement("button", { className: `chip-btn ${mode === "export" ? "chip-active" : ""}`, onClick: () => setMode("export") }, "Eksportuj"), /* @__PURE__ */ React.createElement("button", { className: `chip-btn ${mode === "import" ? "chip-active" : ""}`, onClick: () => setMode("import") }, "Importuj")), mode === "export" ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Zaznacz i skopiuj poni\u017Cszy tekst (albo dotknij \u201EKopiuj do schowka\u201D) i zapisz go u siebie, np. w notatkach."), /* @__PURE__ */ React.createElement(
    "textarea",
    {
      readOnly: true,
      className: "backup-textarea",
      value: backupText,
      onFocus: (e) => e.target.select(),
      id: "backup-export-textarea"
    }
  ), /* @__PURE__ */ React.createElement("div", { className: "form-actions", style: { marginTop: 10 } }, /* @__PURE__ */ React.createElement(
    "button",
    {
      className: "primary-btn",
      onClick: () => {
        const ta = document.getElementById("backup-export-textarea");
        copyToClipboard(backupText, () => setCopyStatus("Skopiowano do schowka."), ta);
      }
    },
    /* @__PURE__ */ React.createElement(Copy, { size: 15 }),
    " Kopiuj do schowka"
  )), copyStatus && /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, copyStatus)) : /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Wklej tutaj wcze\u015Bniej skopiowany tekst kopii zapasowej i dotknij \u201EWczytaj\u201D."), /* @__PURE__ */ React.createElement(
    "textarea",
    {
      className: "backup-textarea",
      placeholder: "Wklej tekst kopii zapasowej\u2026",
      value: pasteValue,
      onChange: (e) => setPasteValue(e.target.value)
    }
  ), /* @__PURE__ */ React.createElement("div", { className: "form-actions", style: { marginTop: 10 } }, /* @__PURE__ */ React.createElement(
    "button",
    {
      className: "primary-btn",
      disabled: !pasteValue.trim(),
      onClick: () => {
        const ok = onImportText(pasteValue);
        if (ok) onClose();
      }
    },
    /* @__PURE__ */ React.createElement(ClipboardPaste, { size: 15 }),
    " Wczytaj"
  )))));
}
function PulpitTab({ plants, inventory, potsTotal, magazynValue, salesValue, orders, done, customTasks, log, supplies, tasks, onAddTask, onCycleTask, onDeleteTask, onNavigate, onExport, onImport, onGetBackupText, onImportText, batches, onJumpToBatch, batchSegments, productionPlans }) {
  const [backupOpen, setBackupOpen] = useState4(false);
  const [searchQuery, setSearchQuery] = useState4("");
  const searchResults = searchBatches(batches || [], plants, searchQuery);
  const attention = buildAttentionCenter(/* @__PURE__ */ new Date(), productionPlans, batchSegments, supplies, orders);
  const attentionTotal = attention.plansDue.length + attention.staleSegments.length + attention.lowSupplies.length + attention.pendingOrders.length;
  const now = /* @__PURE__ */ new Date();
  const curMonth = now.getMonth() + 1;
  const curYear = now.getFullYear();
  const monthTasks = buildMonthTasks(plants, curMonth);
  const doneCount = monthTasks.filter((t) => done[taskKey(curYear, curMonth, t.plant.id, t.type)]).length;
  const custom = customTasks[monthKey(curYear, curMonth)] || [];
  const customDoneCount = custom.filter((t) => t.done).length;
  const pendingCount = monthTasks.length - doneCount + (custom.length - customDoneCount);
  const sales = computeMonthlySales(orders);
  const thisMonthSales = sales.find((s) => s.year === curYear && s.month === curMonth) || { count: 0, sum: 0, countDone: 0, sumDone: 0 };
  const lowSupplies = supplies.filter((s) => s.prog != null && s.prog !== "" && Number(s.ilosc) <= Number(s.prog));
  return /* @__PURE__ */ React.createElement("div", { className: "tab-pad" }, /* @__PURE__ */ React.createElement("label", { className: "field", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("span", null, "Szybkie wyszukiwanie partii (numer albo nazwa odmiany)"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "np. #7 albo Ice Dance", value: searchQuery, onChange: (e) => setSearchQuery(e.target.value) })), searchQuery.trim() && /* @__PURE__ */ React.createElement("div", { className: "order-list", style: { marginTop: 4, marginBottom: 8 } }, searchResults.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak partii pasuj\u0105cych do \u201E", searchQuery, "\u201D."), searchResults.map((b) => /* @__PURE__ */ React.createElement("div", { key: b.id, className: "order-card" }, /* @__PURE__ */ React.createElement("button", { className: "order-card-head", onClick: () => onJumpToBatch(b.id) }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, plantName(plants, b.plantId), " ", /* @__PURE__ */ React.createElement("span", { className: "order-date" }, "\xB7 Partia ", batchLabel(b))), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, sourceLabel(b), " \xB7 ", b.status === "aktywna" ? "aktywna" : "zamkni\u0119ta")), /* @__PURE__ */ React.createElement(Search, { size: 15 }))))), attentionTotal > 0 && /* @__PURE__ */ React.createElement("div", { className: "order-card", style: { marginBottom: 12 } }, /* @__PURE__ */ React.createElement("div", { className: "order-card-body" }, /* @__PURE__ */ React.createElement("div", { className: "section-title small-title", style: { marginTop: 0 } }, "Centrum uwagi (", attentionTotal, ")"), attention.pendingOrders.length > 0 && /* @__PURE__ */ React.createElement("button", { className: "order-card-head", style: { padding: "6px 0" }, onClick: () => onNavigate("sprzedaz") }, /* @__PURE__ */ React.createElement("span", null, "Niezrealizowane zam\xF3wienia"), /* @__PURE__ */ React.createElement("span", { className: "status-badge new" }, attention.pendingOrders.length)), attention.plansDue.length > 0 && /* @__PURE__ */ React.createElement("button", { className: "order-card-head", style: { padding: "6px 0" }, onClick: () => onNavigate("magazyn") }, /* @__PURE__ */ React.createElement("span", null, "Plany produkcji na ten miesi\u0105c"), /* @__PURE__ */ React.createElement("span", { className: "status-badge new" }, attention.plansDue.length)), attention.staleSegments.length > 0 && /* @__PURE__ */ React.createElement("button", { className: "order-card-head", style: { padding: "6px 0" }, onClick: () => onNavigate("magazyn") }, /* @__PURE__ */ React.createElement("span", null, "Segmenty bez ruchu ponad 60 dni"), /* @__PURE__ */ React.createElement("span", { className: "status-badge new" }, attention.staleSegments.length)), attention.lowSupplies.length > 0 && /* @__PURE__ */ React.createElement("button", { className: "order-card-head", style: { padding: "6px 0" }, onClick: () => onNavigate("magazyn") }, /* @__PURE__ */ React.createElement("span", null, "Niski stan zaopatrzenia"), /* @__PURE__ */ React.createElement("span", { className: "status-badge new" }, attention.lowSupplies.length)))), /* @__PURE__ */ React.createElement("div", { className: "dash-grid" }, /* @__PURE__ */ React.createElement("button", { className: "dash-card", onClick: () => onNavigate("harmonogram") }, /* @__PURE__ */ React.createElement("span", { className: "dash-num" }, pendingCount), /* @__PURE__ */ React.createElement("span", { className: "dash-label" }, "zada\u0144 do zrobienia w ", MONTHS[curMonth].toLowerCase())), /* @__PURE__ */ React.createElement("button", { className: "dash-card", onClick: () => onNavigate("sprzedaz") }, /* @__PURE__ */ React.createElement("span", { className: "dash-num" }, money(thisMonthSales.sumDone), " z\u0142"), /* @__PURE__ */ React.createElement("span", { className: "dash-label" }, "sprzeda\u017C zrealizowana w ", MONTHS[curMonth].toLowerCase())), /* @__PURE__ */ React.createElement("button", { className: "dash-card", onClick: () => onNavigate("magazyn") }, /* @__PURE__ */ React.createElement("span", { className: "dash-num" }, potsTotal), /* @__PURE__ */ React.createElement("span", { className: "dash-label" }, "ro\u015Blin w donicach \u0142\u0105cznie")), /* @__PURE__ */ React.createElement("button", { className: "dash-card", onClick: () => onNavigate("magazyn") }, /* @__PURE__ */ React.createElement("span", { className: "dash-num" }, lowSupplies.length), /* @__PURE__ */ React.createElement("span", { className: "dash-label" }, "materia\u0142\xF3w na wyczerpaniu")), /* @__PURE__ */ React.createElement("button", { className: "dash-card dash-card-wide dash-card-split", onClick: () => onNavigate("sprzedaz") }, /* @__PURE__ */ React.createElement("div", { className: "dash-split-item" }, /* @__PURE__ */ React.createElement("span", { className: "dash-num-sm" }, money(magazynValue), " z\u0142"), /* @__PURE__ */ React.createElement("span", { className: "dash-label" }, "koszt zakupu (magazyn)")), /* @__PURE__ */ React.createElement("div", { className: "dash-split-item" }, /* @__PURE__ */ React.createElement("span", { className: "dash-num-sm" }, money(salesValue), " z\u0142"), /* @__PURE__ */ React.createElement("span", { className: "dash-label" }, "potencjalna warto\u015B\u0107 sprzeda\u017Cy")), /* @__PURE__ */ React.createElement("div", { className: "dash-split-item" }, /* @__PURE__ */ React.createElement("span", { className: "dash-num-sm" }, money(salesValue - magazynValue), " z\u0142"), /* @__PURE__ */ React.createElement("span", { className: "dash-label" }, "potencjalny zysk")))), /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: -6 } }, "Koszt i zysk licz\u0105 si\u0119 tylko tam, gdzie masz wpisany koszt/szt. w Cenniku \u2014 brakuj\u0105ce pozycje licz\u0105 si\u0119 jako 0 z\u0142."), lowSupplies.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "alert-box" }, /* @__PURE__ */ React.createElement(AlertTriangle, { size: 15 }), /* @__PURE__ */ React.createElement("span", null, "Ko\u0144czy si\u0119: ", lowSupplies.map((s) => s.nazwa).join(", "))), /* @__PURE__ */ React.createElement(TasksSection, { tasks, onAdd: onAddTask, onCycle: onCycleTask, onDelete: onDeleteTask }), /* @__PURE__ */ React.createElement("div", { className: "section-title", style: { marginTop: 18 } }, /* @__PURE__ */ React.createElement(Clock, { size: 17 }), /* @__PURE__ */ React.createElement("span", null, "Ostatnia aktywno\u015B\u0107")), log.length === 0 ? /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak zarejestrowanych zmian \u2014 historia zacznie si\u0119 wype\u0142nia\u0107, gdy zaczniesz korzysta\u0107 z aplikacji.") : /* @__PURE__ */ React.createElement("div", { className: "log-list" }, log.slice(0, 8).map((entry) => /* @__PURE__ */ React.createElement("div", { key: entry.id, className: "log-row" }, /* @__PURE__ */ React.createElement("span", { className: "log-time" }, formatLogTime(entry.ts)), /* @__PURE__ */ React.createElement("span", { className: "log-text" }, entry.text)))), /* @__PURE__ */ React.createElement("div", { className: "section-title", style: { marginTop: 20 } }, /* @__PURE__ */ React.createElement(Shield, { size: 17 }), /* @__PURE__ */ React.createElement("span", null, "Kopia zapasowa")), /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Wszystkie dane (magazyn, zam\xF3wienia, klienci, historia) trzymane s\u0105 tylko na Twoim koncie w tej aplikacji. Warto od czasu do czasu zrobi\u0107 kopi\u0119 na wszelki wypadek."), /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: () => setBackupOpen(true) }, /* @__PURE__ */ React.createElement(Shield, { size: 15 }), " Kopia zapasowa (kopiuj/wklej)")), /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 6 } }, "Ewentualnie, je\u015Bli Twoja przegl\u0105darka na to pozwala:"), /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: onExport }, /* @__PURE__ */ React.createElement(Download, { size: 15 }), " Pobierz plik"), /* @__PURE__ */ React.createElement("label", { className: "secondary-btn file-label" }, /* @__PURE__ */ React.createElement(Upload, { size: 15 }), " Wczytaj z pliku", /* @__PURE__ */ React.createElement("input", { type: "file", accept: "application/json", className: "visually-hidden-input", onChange: onImport }))), backupOpen && /* @__PURE__ */ React.createElement(BackupModal, { onClose: () => setBackupOpen(false), getBackupText: onGetBackupText, onImportText }));
}

// src/components/magazyn/MagazynTab.jsx
import { useState as useState18, useEffect as useEffect5 } from "react";

// src/components/magazyn/RoslinyPanel.jsx
import { useState as useState8, useEffect as useEffect4 } from "react";
import { ChevronDown as ChevronDown2, ChevronRight as ChevronRight3, Minus, Plus as Plus2, PlusCircle, Search as Search2, Trash2 as Trash23, X as X2 } from "lucide-react";

// src/components/shared/PhotoThumb.jsx
import { Camera as Camera2 } from "lucide-react";
function PhotoThumb({ plantId, photos, setPhotos, onError, size = 46 }) {
  const src = photos[plantId];
  async function handleFile(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    try {
      const dataUrl = await resizeImageToDataUrl(file);
      setPhotos((prev) => ({ ...prev, [plantId]: dataUrl }));
    } catch (err) {
      onError && onError();
    }
  }
  return /* @__PURE__ */ React.createElement(
    "label",
    {
      className: "photo-thumb",
      style: { width: size, height: size },
      onClick: (e) => e.stopPropagation(),
      "aria-label": "Dodaj zdj\u0119cie"
    },
    src ? /* @__PURE__ */ React.createElement("img", { src, alt: "" }) : /* @__PURE__ */ React.createElement(Camera2, { size: 16 }),
    /* @__PURE__ */ React.createElement("input", { type: "file", accept: "image/*", onChange: handleFile, className: "visually-hidden-input" })
  );
}

// src/components/shared/PlantingCalculator.jsx
import { useState as useState5, useEffect as useEffect3 } from "react";
import { Calculator } from "lucide-react";
function PlantingCalculator({ plant, onApply, compact, lockedMb }) {
  const [mode, setMode] = useState5("mb");
  const [value, setValue] = useState5("");
  const [chosenQty, setChosenQty] = useState5("");
  const canMb = plant && plant.gestosc_rozstaw_cm_min != null;
  const canM2 = plant && plant.gestosc_m2_min != null;
  const useLocked = lockedMb != null && canMb;
  const effectiveMode = useLocked ? "mb" : mode;
  const effectiveValue = useLocked ? lockedMb : value;
  const result = plant ? suggestPlantingQty(plant, effectiveMode, effectiveValue) : null;
  useEffect3(() => {
    if (result) setChosenQty(String(Math.round((result.min + result.max) / 2)));
    else setChosenQty("");
  }, [result?.min, result?.max]);
  if (!plant) return null;
  if (plant.gestosc_brak) {
    return /* @__PURE__ */ React.createElement("p", { className: "hint-text calc-note" }, plant.gestosc_text || "Brak danych o g\u0119sto\u015Bci nasadze\u0144 dla tej odmiany.");
  }
  return /* @__PURE__ */ React.createElement("div", { className: `planting-calc ${compact ? "compact" : ""}` }, /* @__PURE__ */ React.createElement("div", { className: "planting-calc-head" }, /* @__PURE__ */ React.createElement(Calculator, { size: 13 }), " Kalkulator nasadze\u0144 ", plant.gestosc_typ ? `\xB7 ${plant.gestosc_typ}` : ""), useLocked ? /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { margin: "0 0 4px" } }, "Rz\u0105d: ", /* @__PURE__ */ React.createElement("b", null, lockedMb, " mb"), " \xB7 rozstaw co ", plant.gestosc_rozstaw_cm_min, plant.gestosc_rozstaw_cm_max !== plant.gestosc_rozstaw_cm_min ? `\u2013${plant.gestosc_rozstaw_cm_max}` : "", " cm") : /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "planting-calc-row" }, /* @__PURE__ */ React.createElement("div", { className: "chip-btn-group" }, canMb && /* @__PURE__ */ React.createElement("button", { type: "button", className: `chip-btn ${mode === "mb" ? "chip-active" : ""}`, onClick: () => setMode("mb") }, "metry bie\u017C\u0105ce"), canM2 && /* @__PURE__ */ React.createElement("button", { type: "button", className: `chip-btn ${mode === "m2" ? "chip-active" : ""}`, onClick: () => setMode("m2") }, "powierzchnia m\xB2")), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      inputMode: "decimal",
      min: "0",
      step: "0.1",
      placeholder: mode === "mb" ? "np. 12" : "np. 8",
      value,
      onChange: (e) => setValue(e.target.value)
    }
  )), /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { margin: "4px 0" } }, mode === "mb" ? `Rozstaw co ${plant.gestosc_rozstaw_cm_min}${plant.gestosc_rozstaw_cm_max !== plant.gestosc_rozstaw_cm_min ? `\u2013${plant.gestosc_rozstaw_cm_max}` : ""} cm` : `G\u0119sto\u015B\u0107 ${plant.gestosc_m2_min}${plant.gestosc_m2_max !== plant.gestosc_m2_min ? `\u2013${plant.gestosc_m2_max}` : ""} szt./m\xB2`)), result && /* @__PURE__ */ React.createElement("div", { className: "planting-calc-result" }, /* @__PURE__ */ React.createElement("span", null, "Wide\u0142ki: ", result.min, "\u2013", result.max, " szt."), /* @__PURE__ */ React.createElement("div", { className: "planting-calc-pick" }, /* @__PURE__ */ React.createElement("button", { type: "button", className: "chip-btn tiny", onClick: () => setChosenQty(String(result.min)) }, "Min"), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "0", className: "qty-pick-input", value: chosenQty, onChange: (e) => setChosenQty(e.target.value) }), /* @__PURE__ */ React.createElement("button", { type: "button", className: "chip-btn tiny", onClick: () => setChosenQty(String(result.max)) }, "Maks")), onApply && /* @__PURE__ */ React.createElement("button", { type: "button", className: "primary-btn small", onClick: () => onApply(Math.max(1, Number(chosenQty) || 0)), disabled: !(Number(chosenQty) > 0) }, "Zastosuj ", chosenQty || "", " szt.")));
}

// src/components/magazyn/PotSizeManager.jsx
import { useState as useState6 } from "react";
import { ChevronDown, ChevronRight as ChevronRight2, Plus } from "lucide-react";
function PotSizeManager({ sizesOpen, setSizesOpen, potSizes, onAdd }) {
  const [text, setText] = useState6("");
  function submit() {
    if (!text.trim()) return;
    onAdd(text);
    setText("");
  }
  return /* @__PURE__ */ React.createElement("div", { className: "pot-size-manager" }, /* @__PURE__ */ React.createElement("button", { className: "pot-size-toggle", onClick: () => setSizesOpen(!sizesOpen) }, /* @__PURE__ */ React.createElement("span", null, "Rozmiary pojemnik\xF3w w u\u017Cyciu: ", potSizes.join(", ")), sizesOpen ? /* @__PURE__ */ React.createElement(ChevronDown, { size: 15 }) : /* @__PURE__ */ React.createElement(ChevronRight2, { size: 15 })), sizesOpen && /* @__PURE__ */ React.createElement("div", { className: "pot-size-body" }, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { margin: "0 0 8px" } }, "Rozmiary pochodz\u0105 z materia\u0142\xF3w oznaczonych jako \u201Edonica\u201D w Zaopatrzeniu \u2014 ka\u017Cda taka pozycja pojawia si\u0119 tu automatycznie, w cenniku i w zam\xF3wieniach. \u017Beby usun\u0105\u0107 rozmiar, usu\u0144 odpowiadaj\u0105cy mu materia\u0142 w Zaopatrzeniu (nie da si\u0119, je\u015Bli s\u0105 w nim jeszcze ro\u015Bliny)."), /* @__PURE__ */ React.createElement("div", { className: "month-chips" }, potSizes.map((s) => /* @__PURE__ */ React.createElement("span", { key: s, className: "pot-size-chip" }, s))), /* @__PURE__ */ React.createElement("div", { className: "add-task-form", style: { marginTop: 8 } }, /* @__PURE__ */ React.createElement(
    "input",
    {
      placeholder: "np. C10 lub Kontener 30L",
      value: text,
      onChange: (e) => setText(e.target.value),
      onKeyDown: (e) => {
        if (e.key === "Enter") submit();
      }
    }
  ), /* @__PURE__ */ React.createElement("button", { className: "primary-btn small", onClick: submit, disabled: !text.trim() }, /* @__PURE__ */ React.createElement(Plus, { size: 14 }), " Dodaj"))));
}

// src/components/magazyn/AddPlantForm.jsx
import { useState as useState7 } from "react";
function MonthChips({ selected, onToggle }) {
  return /* @__PURE__ */ React.createElement("div", { className: "month-chips" }, MONTHS.slice(1).map((name, i) => {
    const m = i + 1;
    const active = selected.includes(m);
    return /* @__PURE__ */ React.createElement("button", { type: "button", key: m, className: `month-chip ${active ? "active" : ""}`, onClick: () => onToggle(m) }, name.slice(0, 3));
  }));
}
function AddPlantForm({ onSave, onCancel }) {
  const [f, setF] = useState7({
    nazwa_pl: "",
    odmiana: "",
    wys_szer: "",
    stanowisko: "",
    kwitnienie: "",
    zimozielona: "Nie",
    opis: "",
    ciecie_months: [],
    podzial_months: [],
    special: false
  });
  function toggleMonth(field, m) {
    setF((prev) => {
      const arr = prev[field].includes(m) ? prev[field].filter((x) => x !== m) : [...prev[field], m].sort((a, b) => a - b);
      return { ...prev, [field]: arr };
    });
  }
  function submit() {
    if (!f.nazwa_pl.trim() || !f.odmiana.trim()) return;
    onSave(f);
  }
  return /* @__PURE__ */ React.createElement("div", { className: "order-form" }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Nazwa polska"), /* @__PURE__ */ React.createElement("input", { value: f.nazwa_pl, onChange: (e) => setF({ ...f, nazwa_pl: e.target.value }), placeholder: "np. Rozplenica" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana / nazwa \u0142aci\u0144ska"), /* @__PURE__ */ React.createElement("input", { value: f.odmiana, onChange: (e) => setF({ ...f, odmiana: e.target.value }), placeholder: "np. Pennisetum 'Nowa'" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Wys./szer. (cm)"), /* @__PURE__ */ React.createElement("input", { value: f.wys_szer, onChange: (e) => setF({ ...f, wys_szer: e.target.value }), placeholder: "80-100 / 60" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Stanowisko"), /* @__PURE__ */ React.createElement("input", { value: f.stanowisko, onChange: (e) => setF({ ...f, stanowisko: e.target.value }), placeholder: "S\u0142o\u0144ce; \u017Cyzna, wilgotna" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Kwitnienie"), /* @__PURE__ */ React.createElement("input", { value: f.kwitnienie, onChange: (e) => setF({ ...f, kwitnienie: e.target.value }), placeholder: "VIII-X; be\u017Cowe" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Zimozielona"), /* @__PURE__ */ React.createElement("select", { value: f.zimozielona, onChange: (e) => setF({ ...f, zimozielona: e.target.value }) }, /* @__PURE__ */ React.createElement("option", { value: "Nie" }, "Nie"), /* @__PURE__ */ React.createElement("option", { value: "Tak" }, "Tak"), /* @__PURE__ */ React.createElement("option", { value: "Cz\u0119\u015Bciowo" }, "Cz\u0119\u015Bciowo"))), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Kr\xF3tki opis (sprzeda\u017Cowy)"), /* @__PURE__ */ React.createElement("input", { value: f.opis, onChange: (e) => setF({ ...f, opis: e.target.value }), placeholder: "1 zdanie \u2014 do czego si\u0119 nadaje" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Miesi\u0105ce ci\u0119cia"), /* @__PURE__ */ React.createElement(MonthChips, { selected: f.ciecie_months, onToggle: (m) => toggleMonth("ciecie_months", m) })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Miesi\u0105ce podzia\u0142u"), /* @__PURE__ */ React.createElement(MonthChips, { selected: f.podzial_months, onToggle: (m) => toggleMonth("podzial_months", m) })), /* @__PURE__ */ React.createElement("label", { className: "checkbox-field" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: f.special, onChange: (e) => setF({ ...f, special: e.target.checked }) }), /* @__PURE__ */ React.createElement("span", null, "Nie \u015Bcina\u0107 \u2014 tylko piel\u0119gnacja/wyczesywanie")), /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: onCancel }, "Anuluj"), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", disabled: !f.nazwa_pl.trim() || !f.odmiana.trim(), onClick: submit }, "Zapisz odmian\u0119")));
}

// src/components/magazyn/RoslinyPanel.jsx
function PlantInfoGrid({ plant: p }) {
  const [wys, szer] = (p.wys_szer || "").split("/").map((s) => (s || "").trim());
  const uwagi = [p.ciecie_text, p.podzial_text].filter(Boolean).join(" | ");
  return /* @__PURE__ */ React.createElement("div", { className: "plant-info-grid-wrap" }, /* @__PURE__ */ React.createElement("div", { className: "plant-info-grid" }, /* @__PURE__ */ React.createElement("div", { className: "info-item" }, /* @__PURE__ */ React.createElement("span", { className: "info-label" }, "Wysoko\u015B\u0107"), /* @__PURE__ */ React.createElement("span", { className: "info-value" }, wys || "\u2014", " cm")), /* @__PURE__ */ React.createElement("div", { className: "info-item" }, /* @__PURE__ */ React.createElement("span", { className: "info-label" }, "Szeroko\u015B\u0107"), /* @__PURE__ */ React.createElement("span", { className: "info-value" }, szer || "\u2014", " cm")), /* @__PURE__ */ React.createElement("div", { className: "info-item" }, /* @__PURE__ */ React.createElement("span", { className: "info-label" }, "Stanowisko"), /* @__PURE__ */ React.createElement("span", { className: "info-value" }, p.stanowisko || "\u2014")), /* @__PURE__ */ React.createElement("div", { className: "info-item" }, /* @__PURE__ */ React.createElement("span", { className: "info-label" }, "Zimozielona"), /* @__PURE__ */ React.createElement("span", { className: "info-value" }, p.zimozielona || "\u2014")), /* @__PURE__ */ React.createElement("div", { className: "info-item" }, /* @__PURE__ */ React.createElement("span", { className: "info-label" }, "Kwitnienie"), /* @__PURE__ */ React.createElement("span", { className: "info-value" }, p.kwitnienie || "\u2014"))), p.opis && /* @__PURE__ */ React.createElement("div", { className: "info-block" }, /* @__PURE__ */ React.createElement("b", null, "Zastosowanie:"), " ", p.opis), uwagi && /* @__PURE__ */ React.createElement("div", { className: "info-block" }, /* @__PURE__ */ React.createElement("b", null, "Uwagi produkcyjne:"), " ", uwagi), p.gestosc_text && /* @__PURE__ */ React.createElement("div", { className: "info-block" }, /* @__PURE__ */ React.createElement("b", null, "G\u0119sto\u015B\u0107:"), " ", p.gestosc_text));
}
function RoslinyPanel({ plants, inventory, onQtyChange, totals, containers, potSizes, onAddPotSize, plantContainerSizes, onTogglePlantContainer, photos, setPhotos, onPhotoError, onAddPlant, onRemovePlant, onSettleDivision }) {
  const [query, setQuery] = useState8("");
  const [openId, setOpenId] = useState8(null);
  const [addOpen, setAddOpen] = useState8(false);
  const [sizesOpen, setSizesOpen] = useState8(false);
  const [sessionDeltas, setSessionDeltas] = useState8({});
  const [confirmingRemoveId, setConfirmingRemoveId] = useState8(null);
  useEffect4(() => {
    setSessionDeltas({});
  }, [openId]);
  function handleQtyChange(plantId, container, nextVal, oldVal) {
    const n = clampInt(nextVal, 0);
    onQtyChange(plantId, container, n);
    const delta = n - oldVal;
    if (delta !== 0) {
      setSessionDeltas((prev) => ({ ...prev, [container]: (prev[container] || 0) + delta }));
    }
  }
  const filtered = plants.filter((p) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return p.nazwa_pl.toLowerCase().includes(q) || p.odmiana.toLowerCase().includes(q);
  });
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "totals-row" }, containers.map((c) => /* @__PURE__ */ React.createElement("div", { key: c, className: "totals-chip" }, /* @__PURE__ */ React.createElement("span", { className: "totals-num" }, totals[c] || 0), /* @__PURE__ */ React.createElement("span", { className: "totals-label" }, containerLabel(c))))), /* @__PURE__ */ React.createElement(PotSizeManager, { sizesOpen, setSizesOpen, potSizes, onAdd: onAddPotSize }), !addOpen ? /* @__PURE__ */ React.createElement("button", { className: "ghost-btn add-plant-btn", onClick: () => setAddOpen(true) }, /* @__PURE__ */ React.createElement(PlusCircle, { size: 15 }), " Dodaj now\u0105 odmian\u0119") : /* @__PURE__ */ React.createElement(AddPlantForm, { onSave: (data) => {
    onAddPlant(data);
    setAddOpen(false);
  }, onCancel: () => setAddOpen(false) }), !addOpen && /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Odmiany dodane tutaj \u017Cyj\u0105 tylko w tej aplikacji \u2014 nie synchronizuj\u0105 si\u0119 automatycznie z Twoim plikiem Excel."), /* @__PURE__ */ React.createElement("div", { className: "search-bar", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement(Search2, { size: 17 }), /* @__PURE__ */ React.createElement("input", { placeholder: "Szukaj odmiany\u2026", value: query, onChange: (e) => setQuery(e.target.value) }), query && /* @__PURE__ */ React.createElement("button", { className: "icon-btn", onClick: () => setQuery("") }, /* @__PURE__ */ React.createElement(X2, { size: 16 }))), /* @__PURE__ */ React.createElement("div", { className: "plant-list" }, filtered.map((p) => {
    const row = inventory[p.id] || {};
    const plantContainers = resolveContainers(plantContainerSizes, containers, p.id);
    const rowTotal = plantContainers.reduce((s, c) => s + Number(row[c] || 0), 0);
    const isOpen = openId === p.id;
    return /* @__PURE__ */ React.createElement("div", { key: p.id, className: `plant-card ${isOpen ? "open" : ""}` }, /* @__PURE__ */ React.createElement("div", { className: "plant-card-head" }, /* @__PURE__ */ React.createElement(PhotoThumb, { plantId: p.id, photos, setPhotos, onError: onPhotoError }), /* @__PURE__ */ React.createElement("button", { className: "plant-card-head-btn", onClick: () => setOpenId(isOpen ? null : p.id) }, /* @__PURE__ */ React.createElement("div", { className: "plant-card-info" }, /* @__PURE__ */ React.createElement("div", { className: "plant-name" }, p.nazwa_pl, " ", p.custom && /* @__PURE__ */ React.createElement("span", { className: "custom-badge" }, "w\u0142asna")), /* @__PURE__ */ React.createElement("div", { className: "plant-variety" }, p.odmiana), /* @__PURE__ */ React.createElement("div", { className: "plant-opis-preview" }, p.opis)), /* @__PURE__ */ React.createElement("div", { className: "plant-card-right" }, /* @__PURE__ */ React.createElement("span", { className: "plant-total-badge" }, rowTotal, " szt."), isOpen ? /* @__PURE__ */ React.createElement(ChevronDown2, { size: 18 }) : /* @__PURE__ */ React.createElement(ChevronRight3, { size: 18 })))), isOpen && /* @__PURE__ */ React.createElement("div", { className: "plant-card-body" }, /* @__PURE__ */ React.createElement(PlantInfoGrid, { plant: p }), /* @__PURE__ */ React.createElement(PlantingCalculator, { plant: p }), plantContainers.map((c) => /* @__PURE__ */ React.createElement("div", { key: c, className: "qty-row" }, /* @__PURE__ */ React.createElement("span", { className: "qty-label" }, containerLabel(c)), /* @__PURE__ */ React.createElement("div", { className: "stepper" }, /* @__PURE__ */ React.createElement("button", { className: "stepper-btn", onClick: () => handleQtyChange(p.id, c, Number(row[c] || 0) - 1, Number(row[c] || 0)) }, /* @__PURE__ */ React.createElement(Minus, { size: 15 })), /* @__PURE__ */ React.createElement(
      "input",
      {
        className: "stepper-input",
        type: "number",
        min: "0",
        inputMode: "numeric",
        value: row[c] || 0,
        onChange: (e) => handleQtyChange(p.id, c, e.target.value, Number(row[c] || 0))
      }
    ), /* @__PURE__ */ React.createElement("button", { className: "stepper-btn", onClick: () => handleQtyChange(p.id, c, Number(row[c] || 0) + 1, Number(row[c] || 0)) }, /* @__PURE__ */ React.createElement(Plus2, { size: 15 }))))), (() => {
      const negEntries = Object.entries(sessionDeltas).filter(([, d]) => d < 0);
      const posEntries = Object.entries(sessionDeltas).filter(([, d]) => d > 0);
      if (negEntries.length === 0 || posEntries.length === 0) return null;
      const fromText = negEntries.map(([c, d]) => `${Math.abs(d)}\xD7 ${containerLabel(c)}`).join(" + ");
      const toText = posEntries.map(([c, d]) => `${d}\xD7 ${containerLabel(c)}`).join(" + ");
      return /* @__PURE__ */ React.createElement("div", { className: "division-banner" }, /* @__PURE__ */ React.createElement("span", null, "Wygl\u0105da na podzia\u0142: ", fromText, " \u2192 ", toText, ". Rozliczy\u0107 jak podzia\u0142 (donice, pod\u0142o\u017Ce, koszt)?"), /* @__PURE__ */ React.createElement("div", { className: "confirm-actions" }, /* @__PURE__ */ React.createElement("button", { className: "primary-btn small", onClick: () => {
        onSettleDivision(p.id, sessionDeltas);
        setSessionDeltas({});
      } }, "Tak, rozlicz"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => setSessionDeltas({}) }, "Nie, to korekta")));
    })(), /* @__PURE__ */ React.createElement("div", { className: "plant-containers-editor" }, /* @__PURE__ */ React.createElement("span", { className: "plant-containers-label" }, "Dost\u0119pne pojemniki dla tej odmiany:"), /* @__PURE__ */ React.createElement("div", { className: "month-chips" }, containers.map((c) => {
      const active = plantContainers.includes(c);
      return /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          key: c,
          className: `month-chip ${active ? "active" : ""}`,
          onClick: () => onTogglePlantContainer(p.id, c)
        },
        containerLabel(c)
      );
    }))), p.custom && (confirmingRemoveId !== p.id ? /* @__PURE__ */ React.createElement("button", { className: "remove-plant-btn", onClick: () => setConfirmingRemoveId(p.id) }, /* @__PURE__ */ React.createElement(Trash23, { size: 14 }), " Usu\u0144 w\u0142asn\u0105 odmian\u0119") : /* @__PURE__ */ React.createElement("div", { className: "confirm-box" }, /* @__PURE__ */ React.createElement("span", null, "Usun\u0105\u0107 t\u0119 odmian\u0119?"), /* @__PURE__ */ React.createElement("div", { className: "confirm-actions" }, /* @__PURE__ */ React.createElement("button", { className: "danger-btn small", onClick: () => {
      onRemovePlant(p.id);
      setConfirmingRemoveId(null);
    } }, "Usu\u0144"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => setConfirmingRemoveId(null) }, "Anuluj"))))));
  }), filtered.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak wynik\xF3w dla \u201E", query, "\u201D.")));
}

// src/components/magazyn/ZakupPanel.jsx
import { useState as useState9 } from "react";
function ZakupPanel({ plants, containers, plantContainerSizes, onPerformPurchase }) {
  const [plantId, setPlantId] = useState9(plants[0] ? plants[0].id : "");
  const avail = resolveContainers(plantContainerSizes, containers, plantId);
  const [container, setContainer] = useState9(avail[0] || "grunt");
  const [ilosc, setIlosc] = useState9(1);
  const [kosztJednostkowy, setKosztJednostkowy] = useState9(0);
  const [location, setLocation] = useState9("");
  const [trackAsBatch, setTrackAsBatch] = useState9(false);
  const [customLabel, setCustomLabel] = useState9("");
  function selectPlant(id) {
    setPlantId(id);
    const a = resolveContainers(plantContainerSizes, containers, id);
    setContainer(a[0] || "grunt");
  }
  function submit() {
    onPerformPurchase({
      plantId,
      container,
      ilosc: clampInt(ilosc, 0),
      kosztJednostkowy: Math.max(0, Number(kosztJednostkowy) || 0),
      location: location.trim() || null,
      trackAsBatch,
      customLabel: customLabel.trim()
    });
    setIlosc(1);
    setLocation("");
    setCustomLabel("");
  }
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 12 } }, "Zarejestruj zakup lub dostaw\u0119 ro\u015Blin \u2014 zwi\u0119ksza stan magazynowy i koszt jednostkowy (\u015Brednia wa\u017Cona z tym, co ju\u017C jest). Opcjonalnie zak\u0142ada now\u0105 \u015Bledzon\u0105 parti\u0119 z pochodzeniem."), /* @__PURE__ */ React.createElement("div", { className: "order-form", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana"), /* @__PURE__ */ React.createElement("select", { value: plantId, onChange: (e) => selectPlant(e.target.value) }, plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana)))), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Pojemnik"), /* @__PURE__ */ React.createElement("select", { value: container, onChange: (e) => setContainer(e.target.value) }, avail.map((c) => /* @__PURE__ */ React.createElement("option", { key: c, value: c }, containerLabel(c))))), /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "1", value: ilosc, onChange: (e) => setIlosc(clampInt(e.target.value, 1)) }), /* @__PURE__ */ React.createElement("span", { style: { fontSize: 12, color: "var(--ink-muted)" } }, "szt.")), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Koszt / szt."), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", step: "0.01", value: kosztJednostkowy, onChange: (e) => setKosztJednostkowy(e.target.value) })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Lokalizacja (opcjonalnie)"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "np. Kwatera A", value: location, onChange: (e) => setLocation(e.target.value) })), /* @__PURE__ */ React.createElement("label", { className: "checkbox-field" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: trackAsBatch, onChange: (e) => setTrackAsBatch(e.target.checked) }), /* @__PURE__ */ React.createElement("span", null, "\u015Aled\u017A jako parti\u0119 (zak\u0142ada now\u0105 parti\u0119 i pierwszy segment z tym pochodzeniem)")), trackAsBatch && /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Opis partii (opcjonalnie \u2014 trafi do kodu partii i na Paszport ro\u015Blin)"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "np. wiosna-2026", value: customLabel, onChange: (e) => setCustomLabel(e.target.value) })), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", disabled: clampInt(ilosc, 0) <= 0, onClick: submit }, "Zarejestruj zakup")));
}

// src/components/magazyn/PodzialPanel.jsx
import { useState as useState10 } from "react";
import { Plus as Plus3, Trash2 as Trash24 } from "lucide-react";
function emptyDivisionTarget(containers, sourceContainer) {
  const opts = containers.filter((c) => c !== sourceContainer && c !== "grunt");
  return { container: opts[0] || containers[0] || "P9", ilosc: 1, location: "" };
}
function PodzialPanel({ plants, inventory, containers, plantContainerSizes, costs, potRecipes, substrateCostPerL, onPerformDivision, batchSegments, batches }) {
  const [plantId, setPlantId] = useState10(plants[0] ? plants[0].id : "");
  const avail = resolveContainers(plantContainerSizes, containers, plantId);
  const [sourceContainer, setSourceContainer] = useState10(avail[0] || "grunt");
  const [sourceQty, setSourceQty] = useState10(1);
  const [deductSource, setDeductSource] = useState10(true);
  const [trackAsBatch, setTrackAsBatch] = useState10(false);
  const [sourceSegmentId, setSourceSegmentId] = useState10("");
  const [targets, setTargets] = useState10([emptyDivisionTarget(avail, avail[0])]);
  const [lastResult, setLastResult] = useState10(null);
  const [formError, setFormError] = useState10("");
  const matchingSegments = (batchSegments || []).filter(
    (s) => s.plantId === plantId && s.container === sourceContainer && s.status === "aktywny"
  );
  function selectPlant(id) {
    setPlantId(id);
    const a = resolveContainers(plantContainerSizes, containers, id);
    setSourceContainer(a[0] || "grunt");
    setSourceSegmentId("");
    setTargets([emptyDivisionTarget(a, a[0])]);
    setFormError("");
  }
  function selectSource(c) {
    setSourceContainer(c);
    setSourceSegmentId("");
    setTargets((prev) => prev.map((t) => t.container === c ? { ...t, container: avail.find((x) => x !== c) || c } : t));
    setFormError("");
  }
  function updateTarget(idx, patch) {
    setTargets((prev) => prev.map((t, i) => i === idx ? { ...t, ...patch } : t));
  }
  function addTarget() {
    setTargets((prev) => [...prev, emptyDivisionTarget(avail, sourceContainer)]);
  }
  function removeTarget(idx) {
    setTargets((prev) => prev.filter((_, i) => i !== idx));
  }
  const validTargets = targets.filter((t) => t.container && clampInt(t.ilosc, 0) > 0);
  const hasInvalidTarget = targets.some((t) => !t.container || clampInt(t.ilosc, 0) <= 0);
  const totalNewUnits = validTargets.reduce((s, t) => s + clampInt(t.ilosc, 0), 0);
  const selectedSourceSegment = matchingSegments.find((s) => s.id === sourceSegmentId) || null;
  const srcCostPerSzt = trackAsBatch && selectedSourceSegment ? Number(selectedSourceSegment.kosztJednostkowy || 0) : Number(costs[plantId]?.[sourceContainer] || 0);
  const totalSrcCost = deductSource ? clampInt(sourceQty, 0) * srcCostPerSzt : 0;
  const srcCostPerNewUnit = totalNewUnits > 0 ? totalSrcCost / totalNewUnits : 0;
  const currentStock = Number(inventory[plantId]?.[sourceContainer] || 0);
  const trackingBlocked = trackAsBatch && !sourceSegmentId;
  function submit() {
    setFormError("");
    if (!plantId) {
      setFormError("Wybierz odmian\u0119.");
      return;
    }
    if (validTargets.length === 0) {
      setFormError("Podaj przynajmniej jedn\u0105 pozycj\u0119 docelow\u0105: pojemnik i ilo\u015B\u0107 wi\u0119ksz\u0105 od zera.");
      return;
    }
    if (hasInvalidTarget) {
      setFormError("Usu\u0144 lub uzupe\u0142nij pozycje z pustym pojemnikiem albo ilo\u015Bci\u0105 \u2264 0.");
      return;
    }
    if (deductSource && clampInt(sourceQty, 0) > currentStock) {
      setFormError(`Ubytek \u017Ar\xF3d\u0142a (${clampInt(sourceQty, 0)}) przekracza dost\u0119pn\u0105 ilo\u015B\u0107 (${currentStock} szt.).`);
      return;
    }
    if (trackingBlocked) {
      setFormError("Zaznaczy\u0142e\u015B \u201E\u015Aled\u017A jako parti\u0119\u201D \u2014 wybierz rzeczywisty segment \u017Ar\xF3d\u0142owy, albo odznacz \u015Bledzenie.");
      return;
    }
    const result = onPerformDivision({
      plantId,
      sourceContainer,
      sourceQty: clampInt(sourceQty, 0),
      deductSource,
      targets: validTargets.map((t) => ({ container: t.container, ilosc: clampInt(t.ilosc, 0), location: (t.location || "").trim() || null })),
      trackAsBatch,
      sourceSegmentId: trackAsBatch && sourceSegmentId ? sourceSegmentId : null
    });
    if (result) setLastResult(result);
    setTargets([emptyDivisionTarget(avail, sourceContainer)]);
    setSourceQty(1);
  }
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 12 } }, "Podziel ro\u015Blin\u0119 matczyn\u0105 (np. z gruntu) na nowe sztuki w doniczkach \u2014 jednym ruchem, na kilka rozmiar\xF3w naraz. Koszt nowych sztuk liczy si\u0119 sam na podstawie receptury pojemnik\xF3w (zak\u0142adka Zaopatrzenie)."), /* @__PURE__ */ React.createElement("div", { className: "order-form", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana"), /* @__PURE__ */ React.createElement("select", { value: plantId, onChange: (e) => selectPlant(e.target.value) }, plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana)))), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "\u0179r\xF3d\u0142o (ro\u015Blina matczyna) \u2014 obecny stan: ", currentStock, " szt."), /* @__PURE__ */ React.createElement("select", { value: sourceContainer, onChange: (e) => selectSource(e.target.value) }, avail.map((c) => /* @__PURE__ */ React.createElement("option", { key: c, value: c }, containerLabel(c))))), /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "1", value: sourceQty, onChange: (e) => setSourceQty(clampInt(e.target.value, 1)) }), /* @__PURE__ */ React.createElement("span", { style: { fontSize: 12, color: "var(--ink-muted)" } }, "szt. \u017Ar\xF3d\u0142a wykorzystane (ubytek \u2014 niezale\u017Cne od liczby nowych ro\u015Blin)")), /* @__PURE__ */ React.createElement("label", { className: "checkbox-field" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: deductSource, onChange: (e) => setDeductSource(e.target.checked) }), /* @__PURE__ */ React.createElement("span", null, "Odejmij t\u0119 ilo\u015B\u0107 ze \u017Ar\xF3d\u0142a (odznacz, je\u015Bli ro\u015Blina mateczna zostaje \u2014 np. dzielisz k\u0119p\u0119 w gruncie)")), /* @__PURE__ */ React.createElement("label", { className: "checkbox-field" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: trackAsBatch, onChange: (e) => {
    setTrackAsBatch(e.target.checked);
    setFormError("");
  } }), /* @__PURE__ */ React.createElement("span", null, "\u015Aled\u017A jako parti\u0119 (wymaga wskazania rzeczywistego segmentu \u017Ar\xF3d\u0142owego)")), trackAsBatch && matchingSegments.length > 0 && /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Segment \u017Ar\xF3d\u0142owy partii (rzeczywiste pochodzenie)"), /* @__PURE__ */ React.createElement("select", { value: sourceSegmentId, onChange: (e) => {
    setSourceSegmentId(e.target.value);
    setFormError("");
  } }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 wybierz segment \u2014"), matchingSegments.map((s) => /* @__PURE__ */ React.createElement("option", { key: s.id, value: s.id }, s.ilosc, " szt. ", s.location ? `\u2014 ${s.location}` : "\u2014 bez lokalizacji", " (partia ", batchLabel((batches || []).find((b) => b.id === s.batchId)), ")")))), trackAsBatch && matchingSegments.length === 0 && /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Brak \u015Bledzonej partii dla tej odmiany i pojemnika \u2014 nie mo\u017Cna tu zaznaczy\u0107 \u015Bledzenia. Odznacz \u201E\u015Aled\u017A jako parti\u0119\u201D (podzia\u0142 zostanie wykonany po staremu) albo najpierw zarejestruj to \u017Ar\xF3d\u0142o jako parti\u0119 (np. przez Zakup z opcj\u0105 \u015Bledzenia)."), /* @__PURE__ */ React.createElement("div", { className: "section-title small-title" }, "Dok\u0105d (mo\u017Cna kilka naraz, ka\u017Cda pozycja mo\u017Ce mie\u0107 w\u0142asn\u0105 lokalizacj\u0119)"), targets.map((t, idx) => {
    const containerCost = costOfContainer(potRecipes, substrateCostPerL, t.container);
    const unitCost = srcCostPerNewUnit + containerCost;
    return /* @__PURE__ */ React.createElement("div", { key: idx, className: "order-item-row" }, /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement("select", { value: t.container, onChange: (e) => updateTarget(idx, { container: e.target.value }) }, avail.filter((c) => c !== "grunt" || true).map((c) => /* @__PURE__ */ React.createElement("option", { key: c, value: c }, containerLabel(c)))), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "1", value: t.ilosc, onChange: (e) => updateTarget(idx, { ilosc: clampInt(e.target.value, 1) }) }), targets.length > 1 && /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => removeTarget(idx) }, /* @__PURE__ */ React.createElement(Trash24, { size: 15 }))), /* @__PURE__ */ React.createElement(
      "input",
      {
        type: "text",
        placeholder: "Lokalizacja (opcjonalnie, np. Kwatera B)",
        value: t.location || "",
        onChange: (e) => updateTarget(idx, { location: e.target.value }),
        style: { marginTop: 4 }
      }
    ), /* @__PURE__ */ React.createElement("div", { className: "order-item-subtotal" }, "koszt/szt.: ~", money(unitCost), " z\u0142"));
  }), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn", onClick: addTarget }, /* @__PURE__ */ React.createElement(Plus3, { size: 15 }), " Dodaj kolejny rozmiar docelowy"), /* @__PURE__ */ React.createElement("div", { className: "order-total" }, "Nowych sztuk \u0142\u0105cznie: ", /* @__PURE__ */ React.createElement("strong", null, totalNewUnits)), formError && /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { color: "var(--danger, #c0392b)" } }, formError), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", disabled: validTargets.length === 0 || trackingBlocked, onClick: submit }, "Wykonaj podzia\u0142"), lastResult && /* @__PURE__ */ React.createElement("div", { className: "division-result-banner", style: { marginTop: 12, padding: 10, border: "1px solid var(--line, #ddd)", borderRadius: 8 } }, lastResult.source && /* @__PURE__ */ React.createElement("div", { style: { marginBottom: 8 } }, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 600 } }, "\u0179R\xD3D\u0141O:"), /* @__PURE__ */ React.createElement("div", null, lastResult.source.label, lastResult.source.location ? ` \u2014 ${lastResult.source.location}` : ""), /* @__PURE__ */ React.createElement("div", null, lastResult.source.before, " \u2192 ", lastResult.source.after)), /* @__PURE__ */ React.createElement("div", { style: { marginBottom: lastResult.newBatch ? 8 : 0 } }, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 600 } }, "PRODUKCJA:"), lastResult.production.map((p, i) => /* @__PURE__ */ React.createElement("div", { key: i }, p.ilosc, " \xD7 ", containerLabel(p.container), p.location ? ` \u2192 ${p.location}` : ""))), lastResult.newBatch && /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 600 } }, "NOWA PARTIA:"), /* @__PURE__ */ React.createElement("div", null, "#", lastResult.newBatch.id), /* @__PURE__ */ React.createElement("div", null, "pochodzenie: ", lastResult.newBatch.originLabel)))));
}

// src/components/magazyn/PrzesadzeniePanel.jsx
import { useState as useState11 } from "react";
import { ArrowRight } from "lucide-react";
function PrzesadzeniePanel({ plants, inventory, containers, plantContainerSizes, costs, potRecipes, substrateCostPerL, batchSegments, batches, onPerformTransplant }) {
  const [plantId, setPlantId] = useState11(plants[0] ? plants[0].id : "");
  const avail = resolveContainers(plantContainerSizes, containers, plantId);
  const [sourceContainer, setSourceContainer] = useState11(avail[0] || "grunt");
  const [trackAsBatch, setTrackAsBatch] = useState11(false);
  const [sourceSegmentId, setSourceSegmentId] = useState11("");
  const [ilosc, setIlosc] = useState11(1);
  const [toContainer, setToContainer] = useState11(avail.find((c) => c !== (avail[0] || "grunt")) || avail[0] || "P9");
  const [toLocation, setToLocation] = useState11("");
  const [formError, setFormError] = useState11("");
  const [lastResult, setLastResult] = useState11(null);
  const matchingSegments = (batchSegments || []).filter(
    (s) => s.plantId === plantId && s.container === sourceContainer && s.status === "aktywny"
  );
  const selectedSegment = matchingSegments.find((s) => s.id === sourceSegmentId) || null;
  function selectPlant(id) {
    setPlantId(id);
    const a = resolveContainers(plantContainerSizes, containers, id);
    setSourceContainer(a[0] || "grunt");
    setToContainer(a.find((c) => c !== (a[0] || "grunt")) || a[0] || "P9");
    setSourceSegmentId("");
    setFormError("");
  }
  function selectSourceContainer(c) {
    setSourceContainer(c);
    setSourceSegmentId("");
    if (toContainer === c) setToContainer(avail.find((x) => x !== c) || c);
    setFormError("");
  }
  const currentStock = Number(inventory[plantId]?.[sourceContainer] || 0);
  const sourceUnitCost = selectedSegment ? Number(selectedSegment.kosztJednostkowy || 0) : Number(costs[plantId]?.[sourceContainer] || 0);
  const recipeMissing = toContainer !== "grunt" && !potRecipes[toContainer];
  const extraCostPerUnit = recipeMissing ? 0 : costOfContainer(potRecipes, substrateCostPerL, toContainer);
  const newUnitCost = sourceUnitCost + extraCostPerUnit;
  const sameAsSource = toContainer === sourceContainer && (!trackAsBatch || (toLocation.trim() || null) === (selectedSegment?.location || null));
  function submit() {
    setFormError("");
    if (!plantId) {
      setFormError("Wybierz odmian\u0119.");
      return;
    }
    const qty = clampInt(ilosc, 0);
    if (qty <= 0) {
      setFormError("Podaj ilo\u015B\u0107 wi\u0119ksz\u0105 od zera.");
      return;
    }
    if (!toContainer) {
      setFormError("Wybierz pojemnik docelowy.");
      return;
    }
    if (recipeMissing) {
      setFormError(`Brak receptury dla pojemnika ${containerLabel(toContainer)} \u2014 uzupe\u0142nij j\u0105 w Zaopatrzeniu przed przesadzeniem.`);
      return;
    }
    if (sameAsSource) {
      setFormError("Cel jest identyczny ze \u017Ar\xF3d\u0142em \u2014 to nie by\u0142oby przesadzenie.");
      return;
    }
    if (trackAsBatch && !sourceSegmentId) {
      setFormError("Zaznaczy\u0142e\u015B \u201E\u015Aled\u017A jako parti\u0119\u201D \u2014 wybierz rzeczywisty segment \u017Ar\xF3d\u0142owy, albo odznacz \u015Bledzenie.");
      return;
    }
    if (trackAsBatch && selectedSegment && qty > Number(selectedSegment.ilosc || 0)) {
      setFormError(`Ilo\u015B\u0107 do przesadzenia (${qty}) przekracza stan segmentu \u017Ar\xF3d\u0142owego (${selectedSegment.ilosc} szt.).`);
      return;
    }
    if (!trackAsBatch && qty > currentStock) {
      setFormError(`Ilo\u015B\u0107 do przesadzenia (${qty}) przekracza stan \u017Ar\xF3d\u0142a (${currentStock} szt.).`);
      return;
    }
    const result = onPerformTransplant({
      plantId,
      sourceContainer,
      ilosc: qty,
      toContainer,
      toLocation: toLocation.trim() || null,
      trackAsBatch,
      sourceSegmentId: trackAsBatch && sourceSegmentId ? sourceSegmentId : null
    });
    if (result) setLastResult(result);
    setIlosc(1);
    setToLocation("");
  }
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 12 } }, "Przesad\u017A lub przenie\u015B istniej\u0105ce ro\u015Bliny do innego pojemnika i/lub lokalizacji. To NIE jest podzia\u0142 \u2014 liczba ro\u015Blin si\u0119 nie zmienia, tylko miejsce, w kt\xF3rym si\u0119 znajduj\u0105. Koszt dok\u0142ada si\u0119 na podstawie Receptury (Zaopatrzenie)."), /* @__PURE__ */ React.createElement("div", { className: "order-form", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana"), /* @__PURE__ */ React.createElement("select", { value: plantId, onChange: (e) => selectPlant(e.target.value) }, plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana)))), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Pojemnik \u017Ar\xF3d\u0142owy \u2014 obecny stan: ", currentStock, " szt."), /* @__PURE__ */ React.createElement("select", { value: sourceContainer, onChange: (e) => selectSourceContainer(e.target.value) }, avail.map((c) => /* @__PURE__ */ React.createElement("option", { key: c, value: c }, containerLabel(c))))), /* @__PURE__ */ React.createElement("label", { className: "checkbox-field" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: trackAsBatch, onChange: (e) => {
    setTrackAsBatch(e.target.checked);
    setSourceSegmentId("");
    setFormError("");
  } }), /* @__PURE__ */ React.createElement("span", null, "\u015Aled\u017A jako parti\u0119 (przesadzenie zostaje w tej samej partii \u2014 wymaga wskazania rzeczywistego segmentu \u017Ar\xF3d\u0142owego)")), trackAsBatch && matchingSegments.length > 0 && /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Segment \u017Ar\xF3d\u0142owy"), /* @__PURE__ */ React.createElement("select", { value: sourceSegmentId, onChange: (e) => {
    setSourceSegmentId(e.target.value);
    setFormError("");
  } }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 wybierz segment \u2014"), matchingSegments.map((s) => /* @__PURE__ */ React.createElement("option", { key: s.id, value: s.id }, s.ilosc, " szt. ", s.location ? `\u2014 ${s.location}` : "\u2014 bez lokalizacji", " (partia ", batchLabel((batches || []).find((b) => b.id === s.batchId)), ", ", money(s.kosztJednostkowy), " z\u0142/szt.)")))), trackAsBatch && matchingSegments.length === 0 && /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Brak \u015Bledzonej partii dla tej odmiany i pojemnika \u2014 odznacz \u201E\u015Aled\u017A jako parti\u0119\u201D (przesadzenie zostanie wykonane tylko na magazynie, bez partii)."), /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "1", value: ilosc, onChange: (e) => setIlosc(clampInt(e.target.value, 1)) }), /* @__PURE__ */ React.createElement("span", { style: { fontSize: 12, color: "var(--ink-muted)" } }, "szt. do przesadzenia")), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Pojemnik docelowy"), /* @__PURE__ */ React.createElement("select", { value: toContainer, onChange: (e) => setToContainer(e.target.value) }, avail.map((c) => /* @__PURE__ */ React.createElement("option", { key: c, value: c }, containerLabel(c))))), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Lokalizacja docelowa (opcjonalnie)"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "np. Kwatera B", value: toLocation, onChange: (e) => setToLocation(e.target.value) })), /* @__PURE__ */ React.createElement("div", { className: "order-item-subtotal" }, "Koszt/szt. \u017Ar\xF3d\u0142a: ~", money(sourceUnitCost), " z\u0142", " ", "+ pojemnik/pod\u0142o\u017Ce: ~", money(extraCostPerUnit), " z\u0142", " ", "= ", /* @__PURE__ */ React.createElement("strong", null, "~", money(newUnitCost), " z\u0142/szt.")), /* @__PURE__ */ React.createElement("div", { className: "section-title small-title" }, "Podsumowanie"), /* @__PURE__ */ React.createElement("div", { className: "order-item-subtotal" }, plants.find((p) => p.id === plantId)?.nazwa_pl || "\u2014", " \xB7 ", clampInt(ilosc, 0), " szt.", /* @__PURE__ */ React.createElement("br", null), containerLabel(sourceContainer), trackAsBatch && selectedSegment?.location ? ` (${selectedSegment.location})` : "", " ", /* @__PURE__ */ React.createElement(ArrowRight, { size: 13, style: { verticalAlign: "middle" } }), " ", containerLabel(toContainer), toLocation.trim() ? ` (${toLocation.trim()})` : ""), formError && /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { color: "var(--danger, #c0392b)" } }, formError), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", onClick: submit }, "Przesad\u017A"), lastResult && /* @__PURE__ */ React.createElement("div", { className: "division-result-banner", style: { marginTop: 12, padding: 10, border: "1px solid var(--line, #ddd)", borderRadius: 8 } }, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 600 } }, "PRZESADZENIE"), /* @__PURE__ */ React.createElement("div", null, lastResult.plantLabel), /* @__PURE__ */ React.createElement("div", null, lastResult.ilosc, " szt."), /* @__PURE__ */ React.createElement("div", null, containerLabel(lastResult.fromContainer), lastResult.fromLocation ? ` (${lastResult.fromLocation})` : "", " \u2192 ", containerLabel(lastResult.toContainer), lastResult.toLocation ? ` (${lastResult.toLocation})` : ""), lastResult.batchId && /* @__PURE__ */ React.createElement("div", null, "Partia ", batchLabel((batches || []).find((b) => b.id === lastResult.batchId)), " \u2014 bez zmian (ta sama partia)"))));
}

// src/components/magazyn/CoMamGdziePanel.jsx
import { useState as useState12, useMemo as useMemo3 } from "react";
import { ChevronLeft as ChevronLeft2, ChevronRight as ChevronRight4 } from "lucide-react";
var BEZ_LOKALIZACJI = "__bez_lokalizacji__";
function buildLocationView(inventory, batchSegments) {
  const groups = {};
  function ensureGroup(locationKey, locationLabel) {
    if (!groups[locationKey]) groups[locationKey] = { location: locationLabel, rows: [] };
    return groups[locationKey];
  }
  batchSegments.filter((s) => s.status === "aktywny" && Number(s.ilosc || 0) > 0).forEach((s) => {
    const key = s.location || BEZ_LOKALIZACJI;
    const g = ensureGroup(key, s.location || null);
    g.rows.push({
      plantId: s.plantId,
      container: s.container,
      ilosc: Number(s.ilosc || 0),
      kosztJednostkowy: Number(s.kosztJednostkowy || 0),
      batchId: s.batchId,
      segmentId: s.id,
      jakosc: s.jakosc || null,
      kind: "segment"
    });
  });
  const segSums = {};
  batchSegments.filter((s) => s.status === "aktywny").forEach((s) => {
    segSums[s.plantId] = segSums[s.plantId] || {};
    segSums[s.plantId][s.container] = (segSums[s.plantId][s.container] || 0) + Number(s.ilosc || 0);
  });
  Object.entries(inventory).forEach(([plantId, row]) => {
    Object.entries(row || {}).forEach(([container, qty]) => {
      const tracked = Number(segSums[plantId]?.[container] || 0);
      const gole = Number(qty || 0) - tracked;
      if (gole > 0) {
        const g = ensureGroup(BEZ_LOKALIZACJI, null);
        g.rows.push({ plantId, container, ilosc: gole, kosztJednostkowy: null, batchId: null, segmentId: null, kind: "gole" });
      }
    });
  });
  const locations = Object.values(groups).map((g) => ({
    ...g,
    totalQty: g.rows.reduce((sum, r) => sum + r.ilosc, 0)
  }));
  locations.sort((a, b) => {
    if (a.location === null) return 1;
    if (b.location === null) return -1;
    return a.location.localeCompare(b.location, "pl");
  });
  return locations;
}
function knownValueOf(rows) {
  return rows.reduce((sum, r) => r.kind === "segment" ? sum + r.ilosc * r.kosztJednostkowy : sum, 0);
}
function CoMamGdziePanel({ plants, inventory, batchSegments, batches }) {
  const [filterPlantId, setFilterPlantId] = useState12("");
  const [selectedLocation, setSelectedLocation] = useState12(void 0);
  const allLocations = useMemo3(() => buildLocationView(inventory, batchSegments), [inventory, batchSegments]);
  const visibleLocations = useMemo3(() => {
    if (!filterPlantId) return allLocations;
    return allLocations.map((g) => ({ ...g, rows: g.rows.filter((r) => r.plantId === filterPlantId) })).map((g) => ({ ...g, totalQty: g.rows.reduce((sum, r) => sum + r.ilosc, 0) })).filter((g) => g.rows.length > 0);
  }, [allLocations, filterPlantId]);
  const totalKnownValue = useMemo3(
    () => allLocations.reduce((sum, g) => sum + knownValueOf(g.rows), 0),
    [allLocations]
  );
  if (selectedLocation !== void 0) {
    const group = visibleLocations.find((g) => g.location === selectedLocation) || { location: selectedLocation, rows: [], totalQty: 0 };
    return /* @__PURE__ */ React.createElement(
      LocationDetail,
      {
        group,
        plants,
        batches,
        onBack: () => setSelectedLocation(void 0)
      }
    );
  }
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 12 } }, "Stan magazynowy pogrupowany wg lokalizacji \u2014 wy\u0142\u0105cznie do odczytu. Kliknij lokalizacj\u0119, \u017Ceby zobaczy\u0107 co dok\u0142adnie tam jest."), /* @__PURE__ */ React.createElement("div", { className: "order-form", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana"), /* @__PURE__ */ React.createElement("select", { value: filterPlantId, onChange: (e) => setFilterPlantId(e.target.value) }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 wszystkie \u2014"), plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana))))), /* @__PURE__ */ React.createElement("div", { className: "totals-row", style: { marginTop: 12 } }, /* @__PURE__ */ React.createElement("div", { className: "totals-chip" }, /* @__PURE__ */ React.createElement("span", { className: "totals-num" }, money(totalKnownValue)), /* @__PURE__ */ React.createElement("span", { className: "totals-label" }, "warto\u015B\u0107 z\u0142 (znany koszt)"))), /* @__PURE__ */ React.createElement("div", { className: "order-list" }, visibleLocations.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak danych do pokazania \u2014 magazyn jest pusty albo \u017Cadna pozycja nie pasuje do filtra."), visibleLocations.map((g) => /* @__PURE__ */ React.createElement("div", { key: g.location ?? BEZ_LOKALIZACJI, className: "order-card" }, /* @__PURE__ */ React.createElement("button", { className: "order-card-head", onClick: () => setSelectedLocation(g.location) }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, g.location || "Bez lokalizacji"), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, g.totalQty, " szt. \u0142\u0105cznie \xB7 ", new Set(g.rows.map((r) => r.plantId)).size, " odmian")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement(ChevronRight4, { size: 16 })))))));
}
function LocationDetail({ group, plants, batches, onBack }) {
  const knownValue = knownValueOf(group.rows);
  const sortedRows = [...group.rows].sort((a, b) => plantName(plants, a.plantId).localeCompare(plantName(plants, b.plantId), "pl"));
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("button", { className: "ghost-btn", style: { marginTop: 12 }, onClick: onBack }, /* @__PURE__ */ React.createElement(ChevronLeft2, { size: 15 }), " Wszystkie lokalizacje"), /* @__PURE__ */ React.createElement("div", { className: "order-card", style: { marginTop: 10 } }, /* @__PURE__ */ React.createElement("div", { className: "order-card-head static" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, group.location || "Bez lokalizacji"), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, group.totalQty, " szt. \u0142\u0105cznie \xB7 warto\u015B\u0107 znana: ", money(knownValue), " z\u0142")))), !group.location && /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 8 } }, 'Tu trafiaj\u0105 dwie r\xF3\u017Cne rzeczy: segmenty partii bez podanej lokalizacji (maj\u0105 numer partii i koszt) oraz sztuki w og\xF3le nie\u015Bledzone jako partia (\u201Ego\u0142e" \u2014 bez partii, bez znanego kosztu jednostkowego). Rozr\xF3\u017Cnione poni\u017Cej.'), /* @__PURE__ */ React.createElement("div", { className: "section-title small-title", style: { marginTop: 16 } }, "Zawarto\u015B\u0107 (", sortedRows.length, ")"), sortedRows.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak pozycji."), sortedRows.map((r, i) => /* @__PURE__ */ React.createElement("div", { key: r.segmentId || `gole-${r.plantId}-${r.container}-${i}`, className: "order-card" }, /* @__PURE__ */ React.createElement("div", { className: "order-card-head static" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, plantName(plants, r.plantId), r.kind === "segment" && r.jakosc ? ` \xB7 ${QUALITY_LABELS[r.jakosc] || r.jakosc}` : ""), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, containerLabel(r.container), " \xB7 ", r.ilosc, " szt.", r.kind === "segment" ? ` \xB7 ${money(r.kosztJednostkowy)} z\u0142/szt. \xB7 partia ${batchLabel((batches || []).find((b) => b.id === r.batchId))}` : " \xB7 bez partii, koszt nieznany")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement("span", { className: "order-sum" }, r.kind === "segment" ? `${money(r.ilosc * r.kosztJednostkowy)} z\u0142` : "\u2014"))))));
}

// src/components/magazyn/PlanProdukcjiPanel.jsx
import { useState as useState13, useMemo as useMemo4 } from "react";
var STATUS_LABELS = { planowane: "Planowane", wykonane: "Wykonane", anulowane: "Anulowane" };
var MONTH_NAMES = ["Stycze\u0144", "Luty", "Marzec", "Kwiecie\u0144", "Maj", "Czerwiec", "Lipiec", "Sierpie\u0144", "Wrzesie\u0144", "Pa\u017Adziernik", "Listopad", "Grudzie\u0144"];
function PlanProdukcjiPanel({ plants, batchSegments, batches, productionPlans, onAddPlan, onSetStatus, onDeletePlan }) {
  const [addOpen, setAddOpen] = useState13(false);
  const [plantId, setPlantId] = useState13(plants[0] ? plants[0].id : "");
  const [sourceSegmentId, setSourceSegmentId] = useState13("");
  const [targetContainer, setTargetContainer] = useState13("");
  const [targetLocation, setTargetLocation] = useState13("");
  const [expectedQty, setExpectedQty] = useState13(0);
  const now = /* @__PURE__ */ new Date();
  const [plannedYear, setPlannedYear] = useState13(now.getFullYear());
  const [plannedMonth, setPlannedMonth] = useState13(now.getMonth() + 1);
  const [note, setNote] = useState13("");
  const [showDone, setShowDone] = useState13(false);
  const matchingSegments = (batchSegments || []).filter((s) => s.plantId === plantId && s.status === "aktywny" && Number(s.ilosc || 0) > 0);
  function submit() {
    onAddPlan({ plantId, sourceSegmentId: sourceSegmentId || null, targetContainer: targetContainer.trim() || null, targetLocation: targetLocation.trim() || null, expectedQty: Number(expectedQty || 0), plannedYear: Number(plannedYear), plannedMonth: Number(plannedMonth), note: note.trim() });
    setSourceSegmentId("");
    setTargetContainer("");
    setTargetLocation("");
    setExpectedQty(0);
    setNote("");
    setAddOpen(false);
  }
  const visible = useMemo4(
    () => productionPlans.filter((p) => showDone ? true : p.status === "planowane").sort((a, b) => a.plannedYear - b.plannedYear || a.plannedMonth - b.plannedMonth),
    [productionPlans, showDone]
  );
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 12 } }, "Notatka na przysz\u0142o\u015B\u0107 \u2014 nie tworzy \u017Cadnej partii ani nie rezerwuje stanu. Wykonanie nadal robisz przez ekran Podzia\u0142; tu tylko planujesz z wyprzedzeniem i odhaczasz po fakcie."), /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "primary-btn", onClick: () => setAddOpen((v) => !v) }, addOpen ? "Anuluj" : "Dodaj plan"), /* @__PURE__ */ React.createElement("label", { className: "checkbox-field", style: { marginLeft: "auto" } }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: showDone, onChange: (e) => setShowDone(e.target.checked) }), /* @__PURE__ */ React.createElement("span", null, "Poka\u017C wykonane/anulowane"))), addOpen && /* @__PURE__ */ React.createElement("div", { className: "order-form" }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana"), /* @__PURE__ */ React.createElement("select", { value: plantId, onChange: (e) => {
    setPlantId(e.target.value);
    setSourceSegmentId("");
  } }, plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana)))), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Segment \u017Ar\xF3d\u0142owy (opcjonalnie)"), /* @__PURE__ */ React.createElement("select", { value: sourceSegmentId, onChange: (e) => setSourceSegmentId(e.target.value) }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 nie wskazuj\u0119 / bez \u015Bledzonej partii \u2014"), matchingSegments.map((s) => /* @__PURE__ */ React.createElement("option", { key: s.id, value: s.id }, containerLabel(s.container), s.location ? ` \u2014 ${s.location}` : "", " \xB7 ", s.ilosc, " szt. \xB7 partia ", batchLabel((batches || []).find((b) => b.id === s.batchId)))))), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Planowany miesi\u0105c"), /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement("select", { value: plannedMonth, onChange: (e) => setPlannedMonth(e.target.value) }, MONTH_NAMES.map((m, i) => /* @__PURE__ */ React.createElement("option", { key: i, value: i + 1 }, m))), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", value: plannedYear, onChange: (e) => setPlannedYear(e.target.value), style: { maxWidth: 90 } }))), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Docelowy pojemnik (opcjonalnie)"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "np. P9", value: targetContainer, onChange: (e) => setTargetContainer(e.target.value) })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Docelowa lokalizacja (opcjonalnie)"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "np. Kwatera B", value: targetLocation, onChange: (e) => setTargetLocation(e.target.value) })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Spodziewana ilo\u015B\u0107 nowych sztuk"), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "0", value: expectedQty, onChange: (e) => setExpectedQty(e.target.value) })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Notatka (opcjonalnie)"), /* @__PURE__ */ React.createElement("input", { type: "text", value: note, onChange: (e) => setNote(e.target.value) })), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", onClick: submit }, "Zapisz plan")), /* @__PURE__ */ React.createElement("div", { className: "order-list" }, visible.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak ", showDone ? "\u017Cadnych" : "aktywnych", " plan\xF3w produkcji."), visible.map((p) => {
    const seg = p.sourceSegmentId ? (batchSegments || []).find((s) => s.id === p.sourceSegmentId) : null;
    return /* @__PURE__ */ React.createElement("div", { key: p.id, className: "order-card" }, /* @__PURE__ */ React.createElement("div", { className: "order-card-head static" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, plantName(plants, p.plantId), " \u2014 ", MONTH_NAMES[p.plannedMonth - 1], " ", p.plannedYear), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, seg ? `\u017Ar\xF3d\u0142o: ${containerLabel(seg.container)}${seg.location ? ` (${seg.location})` : ""} \xB7 ` : "", p.targetContainer ? `cel: ${containerLabel(p.targetContainer)}${p.targetLocation ? ` (${p.targetLocation})` : ""} \xB7 ` : "", p.expectedQty ? `~${p.expectedQty} szt.` : "ilo\u015B\u0107 nieokre\u015Blona", p.note ? ` \xB7 ${p.note}` : "")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement("span", { className: `status-badge ${p.status === "wykonane" ? "ok" : p.status === "anulowane" ? "" : "new"}` }, STATUS_LABELS[p.status]))), p.status === "planowane" && /* @__PURE__ */ React.createElement("div", { className: "order-card-body" }, /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn small", onClick: () => onSetStatus(p.id, "wykonane") }, "Oznacz jako wykonane"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => onSetStatus(p.id, "anulowane") }, "Anuluj plan"), /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => onDeletePlan(p.id) }, "Usu\u0144"))));
  })));
}

// src/components/magazyn/ZaopatrzeniePanel.jsx
import { useState as useState14 } from "react";
import { ChevronDown as ChevronDown3, ChevronRight as ChevronRight5, Plus as Plus4, Trash2 as Trash25 } from "lucide-react";
function emptySupplyForm() {
  return { nazwa: "", ilosc: 0, jednostka: "szt.", prog: "", cena: 0, typ: "inne", rozmiar: "" };
}
function ZaopatrzeniePanel({ supplies, onChangeQty, onAdd, onRemove, potSizes, potRecipes, substrateCostPerL, onSetPotRecipe, onSetSubstrateCostPerL }) {
  const [addOpen, setAddOpen] = useState14(false);
  const [recipeOpen, setRecipeOpen] = useState14(false);
  const [f, setF] = useState14(emptySupplyForm());
  const [confirmingId, setConfirmingId] = useState14(null);
  function submit() {
    if (!f.nazwa.trim()) return;
    if (f.typ === "donica" && !f.rozmiar.trim()) return;
    onAdd({
      nazwa: f.nazwa.trim(),
      ilosc: clampInt(f.ilosc, 0),
      jednostka: f.jednostka.trim() || "szt.",
      prog: f.prog === "" ? null : clampInt(f.prog, 0),
      cena: Math.max(0, Number(f.cena) || 0),
      typ: f.typ,
      rozmiar: f.typ === "donica" ? f.rozmiar.trim() : null
    });
    setF(emptySupplyForm());
    setAddOpen(false);
  }
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "pot-size-manager", style: { marginTop: 12 } }, /* @__PURE__ */ React.createElement("button", { className: "pot-size-toggle", onClick: () => setRecipeOpen(!recipeOpen) }, /* @__PURE__ */ React.createElement("span", null, "Receptura pojemnik\xF3w (koszt donicy + zu\u017Cycie pod\u0142o\u017Ca)"), recipeOpen ? /* @__PURE__ */ React.createElement(ChevronDown3, { size: 15 }) : /* @__PURE__ */ React.createElement(ChevronRight5, { size: 15 })), recipeOpen && /* @__PURE__ */ React.createElement("div", { className: "pot-size-body" }, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { margin: "0 0 8px" } }, "Wiersze poni\u017Cej odpowiadaj\u0105 materia\u0142om typu \u201Edonica\u201D z listy pod spodem \u2014 dodaj tam nowy rozmiar, a pojawi si\u0119 tu automatycznie. Ustaw raz koszt pustej donicy i ile litr\xF3w pod\u0142o\u017Ca zu\u017Cywa ka\u017Cdy rozmiar \u2014 system u\u017Cyje tego przy ka\u017Cdym Podziale."), /* @__PURE__ */ React.createElement("label", { className: "field", style: { marginBottom: 10 } }, /* @__PURE__ */ React.createElement("span", null, "Cena pod\u0142o\u017Ca za litr"), /* @__PURE__ */ React.createElement("div", { className: "price-input-wrap" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", value: substrateCostPerL, onChange: (e) => onSetSubstrateCostPerL(Math.max(0, Number(e.target.value) || 0)) }), /* @__PURE__ */ React.createElement("span", { className: "pln" }, "z\u0142/l"))), potSizes.map((size) => {
    const r = potRecipes[size] || { koszt_donicy: 0, podloze_l: 0 };
    return /* @__PURE__ */ React.createElement("div", { key: size, className: "recipe-row" }, /* @__PURE__ */ React.createElement("span", { className: "recipe-size" }, size), /* @__PURE__ */ React.createElement("div", { className: "recipe-inputs" }, /* @__PURE__ */ React.createElement("label", null, /* @__PURE__ */ React.createElement("span", null, "Donica"), /* @__PURE__ */ React.createElement("div", { className: "price-input-wrap small" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", value: r.koszt_donicy, onChange: (e) => onSetPotRecipe(size, { koszt_donicy: Math.max(0, Number(e.target.value) || 0) }) }), /* @__PURE__ */ React.createElement("span", { className: "pln" }, "z\u0142"))), /* @__PURE__ */ React.createElement("label", null, /* @__PURE__ */ React.createElement("span", null, "Pod\u0142o\u017Ce"), /* @__PURE__ */ React.createElement("div", { className: "price-input-wrap small" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", value: r.podloze_l, onChange: (e) => onSetPotRecipe(size, { podloze_l: Math.max(0, Number(e.target.value) || 0) }) }), /* @__PURE__ */ React.createElement("span", { className: "pln" }, "l"))), /* @__PURE__ */ React.createElement("span", { className: "recipe-total" }, "= ", money(Number(r.koszt_donicy || 0) + Number(r.podloze_l || 0) * Number(substrateCostPerL || 0)), " z\u0142")));
  }))), /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Materia\u0142y \u2014 donice, pod\u0142o\u017Ce i inne zasoby. Materia\u0142 typu \u201Edonica\u201D od razu staje si\u0119 dost\u0119pnym rozmiarem pojemnika w ca\u0142ej aplikacji (Podzia\u0142, Cennik, Zam\xF3wienia)."), /* @__PURE__ */ React.createElement("div", { className: "plant-list" }, supplies.map((s) => {
    const low = s.prog != null && Number(s.ilosc) <= Number(s.prog);
    const linkedCena = s.typ === "donica" ? Number(potRecipes[s.rozmiar]?.koszt_donicy || 0) : s.typ === "podloze" ? Number(substrateCostPerL || 0) : null;
    const cena = linkedCena != null ? linkedCena : Number(s.cena || 0);
    const wartosc = Number(s.ilosc || 0) * cena;
    return /* @__PURE__ */ React.createElement("div", { key: s.id, className: `supply-card ${low ? "low" : ""}` }, /* @__PURE__ */ React.createElement("div", { className: "supply-card-main" }, /* @__PURE__ */ React.createElement("div", { className: "plant-name" }, s.nazwa, " ", low && /* @__PURE__ */ React.createElement("span", { className: "low-badge" }, "niski stan")), /* @__PURE__ */ React.createElement("div", { className: "supply-meta" }, s.prog != null ? `min ${s.prog} ${s.jednostka} \xB7 ` : "", money(cena), " z\u0142/", s.jednostka, " \xB7 warto\u015B\u0107 ", money(wartosc), " z\u0142", linkedCena != null && /* @__PURE__ */ React.createElement("span", { className: "recipe-linked-badge" }, " \xB7 z Receptury")), /* @__PURE__ */ React.createElement("div", { className: "supply-qty-row" }, /* @__PURE__ */ React.createElement("input", { className: "supply-qty-input", type: "number", min: "0", inputMode: "numeric", value: s.ilosc, onChange: (e) => onChangeQty(s.id, e.target.value) }), /* @__PURE__ */ React.createElement("span", { className: "supply-unit" }, s.jednostka), confirmingId !== s.id ? /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => setConfirmingId(s.id) }, /* @__PURE__ */ React.createElement(Trash25, { size: 16 })) : /* @__PURE__ */ React.createElement("div", { className: "confirm-box" }, /* @__PURE__ */ React.createElement("span", null, "Usun\u0105\u0107?"), /* @__PURE__ */ React.createElement("div", { className: "confirm-actions" }, /* @__PURE__ */ React.createElement("button", { className: "danger-btn small", onClick: () => {
      onRemove(s.id);
      setConfirmingId(null);
    } }, "Usu\u0144"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => setConfirmingId(null) }, "Anuluj"))))));
  }), supplies.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak pozycji \u2014 dodaj poni\u017Cej.")), !addOpen ? /* @__PURE__ */ React.createElement("button", { className: "ghost-btn add-plant-btn", onClick: () => setAddOpen(true) }, /* @__PURE__ */ React.createElement(Plus4, { size: 15 }), " Dodaj materia\u0142") : /* @__PURE__ */ React.createElement("div", { className: "order-form" }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Rodzaj"), /* @__PURE__ */ React.createElement("select", { value: f.typ, onChange: (e) => setF({ ...f, typ: e.target.value, rozmiar: "" }) }, /* @__PURE__ */ React.createElement("option", { value: "inne" }, "Inny materia\u0142"), /* @__PURE__ */ React.createElement("option", { value: "donica" }, "Donica (rozmiar pojemnika)"), /* @__PURE__ */ React.createElement("option", { value: "podloze" }, "Pod\u0142o\u017Ce"))), f.typ === "donica" && /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Rozmiar (np. C8, P9)"), /* @__PURE__ */ React.createElement("input", { value: f.rozmiar, onChange: (e) => setF({ ...f, rozmiar: e.target.value }), placeholder: "np. C8" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Nazwa"), /* @__PURE__ */ React.createElement("input", { value: f.nazwa, onChange: (e) => setF({ ...f, nazwa: e.target.value }), placeholder: f.typ === "donica" ? "np. Donice C8 (puste)" : "np. Agrow\u0142\xF3knina 1.6m" })), /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "0", value: f.ilosc, onChange: (e) => setF({ ...f, ilosc: e.target.value }), placeholder: "ilo\u015B\u0107" }), /* @__PURE__ */ React.createElement("input", { value: f.jednostka, onChange: (e) => setF({ ...f, jednostka: e.target.value }), placeholder: "jednostka (szt./l/mb)" })), f.typ === "inne" ? /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Cena jednostkowa (z\u0142)"), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", step: "0.01", value: f.cena, onChange: (e) => setF({ ...f, cena: e.target.value }), placeholder: "np. 1.00" })) : /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: -6 } }, "Cena tego materia\u0142u b\u0119dzie pobierana z Receptury pojemnik\xF3w powy\u017Cej (ustaw j\u0105 tam po zapisaniu)."), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Alarm przy ilo\u015Bci \u2264 (opcjonalnie)"), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "0", value: f.prog, onChange: (e) => setF({ ...f, prog: e.target.value }), placeholder: "np. 20" })), /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: () => {
    setAddOpen(false);
    setF(emptySupplyForm());
  } }, "Anuluj"), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", disabled: !f.nazwa.trim() || f.typ === "donica" && !f.rozmiar.trim(), onClick: submit }, "Zapisz"))));
}

// src/components/magazyn/StratyPanel.jsx
import { useState as useState15 } from "react";
import { Plus as Plus5, Trash2 as Trash26 } from "lucide-react";
function emptyLossForm(plants, containers) {
  return { plantId: plants[0] ? plants[0].id : "", container: containers && containers[0] ? containers[0] : "P9", ilosc: 1, powod: LOSS_REASONS[0], komentarz: "", data: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) };
}
function StratyPanel({ plants, inventory, containers, plantContainerSizes, losses, onAdd, onDelete, costs, batchSegments, batches }) {
  const [addOpen, setAddOpen] = useState15(false);
  const [typ, setTyp] = useState15("strata");
  const [f, setF] = useState15(() => emptyLossForm(plants, containers));
  const [trackAsBatch, setTrackAsBatch] = useState15(false);
  const [segmentId, setSegmentId] = useState15("");
  const [confirmingId, setConfirmingId] = useState15(null);
  const [formError, setFormError] = useState15("");
  const matchingSegments = (batchSegments || []).filter(
    (s) => s.plantId === f.plantId && s.container === f.container && s.status === "aktywny"
  );
  const currentStock = Number(inventory?.[f.plantId]?.[f.container] || 0);
  const selectedSegment = matchingSegments.find((s) => s.id === segmentId) || null;
  const unitCost = selectedSegment ? Number(selectedSegment.kosztJednostkowy || 0) : Number(costs[f.plantId]?.[f.container] || 0);
  const wartosc = unitCost * clampInt(f.ilosc, 0);
  function selectPlant(plantId) {
    const avail = resolveContainers(plantContainerSizes, containers, plantId);
    setF((prev) => ({ ...prev, plantId, container: avail.includes(prev.container) ? prev.container : avail[0] }));
    setSegmentId("");
    setFormError("");
  }
  function selectContainer(container) {
    setF((prev) => ({ ...prev, container }));
    setSegmentId("");
    setFormError("");
  }
  function setTypAndReset(nextTyp) {
    setTyp(nextTyp);
    setF((prev) => ({ ...prev, powod: nextTyp === "strata" ? LOSS_REASONS[0] : "" }));
    setFormError("");
  }
  function submit() {
    setFormError("");
    if (!f.plantId) {
      setFormError("Wybierz odmian\u0119.");
      return;
    }
    if (clampInt(f.ilosc, 0) <= 0) {
      setFormError("Podaj ilo\u015B\u0107 wi\u0119ksz\u0105 od zera.");
      return;
    }
    if (!f.powod || !f.powod.trim()) {
      setFormError("Podaj pow\xF3d.");
      return;
    }
    if (trackAsBatch && !segmentId) {
      setFormError("Zaznaczy\u0142e\u015B \u201E\u015Aled\u017A jako parti\u0119\u201D \u2014 wybierz rzeczywisty segment, albo odznacz \u015Bledzenie.");
      return;
    }
    if (trackAsBatch && selectedSegment && clampInt(f.ilosc, 0) > Number(selectedSegment.ilosc || 0)) {
      setFormError(`Ilo\u015B\u0107 (${clampInt(f.ilosc, 0)}) przekracza stan segmentu (${selectedSegment.ilosc} szt.).`);
      return;
    }
    if (!trackAsBatch && clampInt(f.ilosc, 0) > currentStock) {
      setFormError(`Ilo\u015B\u0107 (${clampInt(f.ilosc, 0)}) przekracza dost\u0119pny stan (${currentStock} szt.).`);
      return;
    }
    onAdd({ ...f, ilosc: clampInt(f.ilosc, 1), typ, trackAsBatch, segmentId: trackAsBatch ? segmentId : null });
    setF(emptyLossForm(plants, containers));
    setTyp("strata");
    setTrackAsBatch(false);
    setSegmentId("");
    setAddOpen(false);
  }
  const now = /* @__PURE__ */ new Date();
  const curKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const monthLosses = losses.filter((l) => (l.typ || "strata") === "strata" && (l.data || "").startsWith(curKey));
  const monthCount = monthLosses.reduce((s, l) => s + Number(l.ilosc || 0), 0);
  const monthValue = monthLosses.reduce((s, l) => {
    const koszt = costs[l.plantId]?.[l.container] || 0;
    return s + koszt * Number(l.ilosc || 0);
  }, 0);
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "totals-row", style: { marginTop: 12 } }, /* @__PURE__ */ React.createElement("div", { className: "totals-chip" }, /* @__PURE__ */ React.createElement("span", { className: "totals-num" }, monthCount), /* @__PURE__ */ React.createElement("span", { className: "totals-label" }, "strat w tym mies.")), /* @__PURE__ */ React.createElement("div", { className: "totals-chip" }, /* @__PURE__ */ React.createElement("span", { className: "totals-num" }, money(monthValue)), /* @__PURE__ */ React.createElement("span", { className: "totals-label" }, "szac. warto\u015B\u0107 (z\u0142)"))), !addOpen ? /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "primary-btn", onClick: () => {
    setTypAndReset("strata");
    setAddOpen(true);
  } }, /* @__PURE__ */ React.createElement(Plus5, { size: 17 }), " Zg\u0142o\u015B strat\u0119"), /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: () => {
    setTypAndReset("usuniecie");
    setAddOpen(true);
  } }, /* @__PURE__ */ React.createElement(Trash26, { size: 17 }), " Zg\u0142o\u015B usuni\u0119cie")) : /* @__PURE__ */ React.createElement("div", { className: "order-form" }, /* @__PURE__ */ React.createElement("div", { className: "segmented" }, /* @__PURE__ */ React.createElement("button", { className: typ === "strata" ? "active" : "", onClick: () => setTypAndReset("strata") }, "Strata"), /* @__PURE__ */ React.createElement("button", { className: typ === "usuniecie" ? "active" : "", onClick: () => setTypAndReset("usuniecie") }, "Usuni\u0119cie")), /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, typ === "strata" ? "Strata \u2014 ro\u015Blina zgin\u0119\u0142a lub zosta\u0142a utracona (choroba, warunki, szkodniki...)." : "Usuni\u0119cie \u2014 \u015Bwiadoma decyzja (np. wycofanie s\u0142abej jako\u015Bci matecznika). To nie jest strata biologiczna."), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana"), /* @__PURE__ */ React.createElement("select", { value: f.plantId, onChange: (e) => selectPlant(e.target.value) }, plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana)))), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Pojemnik \u2014 obecny stan: ", currentStock, " szt."), /* @__PURE__ */ React.createElement("select", { value: f.container, onChange: (e) => selectContainer(e.target.value) }, resolveContainers(plantContainerSizes, containers, f.plantId).map((c) => /* @__PURE__ */ React.createElement("option", { key: c, value: c }, containerLabel(c))))), /* @__PURE__ */ React.createElement("label", { className: "checkbox-field" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: trackAsBatch, onChange: (e) => {
    setTrackAsBatch(e.target.checked);
    setSegmentId("");
    setFormError("");
  } }), /* @__PURE__ */ React.createElement("span", null, "\u015Aled\u017A jako parti\u0119 (wymaga wskazania rzeczywistego segmentu)")), trackAsBatch && matchingSegments.length > 0 && /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Segment"), /* @__PURE__ */ React.createElement("select", { value: segmentId, onChange: (e) => {
    setSegmentId(e.target.value);
    setFormError("");
  } }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 wybierz segment \u2014"), matchingSegments.map((s) => /* @__PURE__ */ React.createElement("option", { key: s.id, value: s.id }, s.ilosc, " szt. ", s.location ? `\u2014 ${s.location}` : "\u2014 bez lokalizacji", " (partia ", batchLabel((batches || []).find((b) => b.id === s.batchId)), ", ", money(s.kosztJednostkowy), " z\u0142/szt.)")))), trackAsBatch && matchingSegments.length === 0 && /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Brak \u015Bledzonej partii dla tej odmiany i pojemnika \u2014 odznacz \u201E\u015Aled\u017A jako parti\u0119\u201D."), /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "1", value: f.ilosc, onChange: (e) => setF({ ...f, ilosc: e.target.value }) }), /* @__PURE__ */ React.createElement("span", { style: { fontSize: 12, color: "var(--ink-muted)" } }, "szt.")), typ === "strata" ? /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Pow\xF3d"), /* @__PURE__ */ React.createElement("select", { value: f.powod, onChange: (e) => setF({ ...f, powod: e.target.value }) }, LOSS_REASONS.map((r) => /* @__PURE__ */ React.createElement("option", { key: r, value: r }, r)))) : /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Pow\xF3d (opisowo)"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "np. wycofanie s\u0142abej jako\u015Bci matecznika", value: f.powod, onChange: (e) => setF({ ...f, powod: e.target.value }) })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Komentarz (opcjonalnie)"), /* @__PURE__ */ React.createElement("input", { type: "text", value: f.komentarz, onChange: (e) => setF({ ...f, komentarz: e.target.value }) })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Data"), /* @__PURE__ */ React.createElement("input", { type: "date", value: f.data, onChange: (e) => setF({ ...f, data: e.target.value }) })), /* @__PURE__ */ React.createElement("div", { className: "order-item-subtotal" }, "Warto\u015B\u0107 ", typ === "strata" ? "straty" : "usuni\u0119cia", ": ~", money(wartosc), " z\u0142 (", clampInt(f.ilosc, 0), " \xD7 ", money(unitCost), " z\u0142/szt.)"), formError && /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { color: "var(--danger, #c0392b)" } }, formError), /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: () => setAddOpen(false) }, "Anuluj"), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", onClick: submit }, typ === "strata" ? "Zapisz strat\u0119" : "Usu\u0144"))), /* @__PURE__ */ React.createElement("div", { className: "order-list" }, losses.length === 0 && !addOpen && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak zarejestrowanych strat i usuni\u0119\u0107."), losses.map((l) => {
    const p = plants.find((pp) => pp.id === l.plantId);
    return /* @__PURE__ */ React.createElement("div", { key: l.id, className: "order-card" }, /* @__PURE__ */ React.createElement("div", { className: "order-card-head static" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, p ? `${p.nazwa_pl} (${p.odmiana})` : l.plantId), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, l.data, " \xB7 ", containerLabel(l.container), " \xB7 ", (l.typ || "strata") === "usuniecie" ? "Usuni\u0119cie" : "Strata", " \xB7 ", l.powod, l.komentarz ? ` \u2014 ${l.komentarz}` : "")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement("span", { className: "order-sum" }, "-", l.ilosc, " szt."), confirmingId !== l.id && /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => setConfirmingId(l.id) }, /* @__PURE__ */ React.createElement(Trash26, { size: 14 })))), confirmingId === l.id && /* @__PURE__ */ React.createElement("div", { className: "order-card-body" }, /* @__PURE__ */ React.createElement("div", { className: "confirm-box" }, /* @__PURE__ */ React.createElement("span", null, "Usun\u0105\u0107 wpis? (nie przywr\xF3ci to stanu magazynowego)"), /* @__PURE__ */ React.createElement("div", { className: "confirm-actions" }, /* @__PURE__ */ React.createElement("button", { className: "danger-btn small", onClick: () => {
      onDelete(l.id);
      setConfirmingId(null);
    } }, "Usu\u0144"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => setConfirmingId(null) }, "Anuluj")))));
  })));
}

// src/components/magazyn/InwentaryzacjaPanel.jsx
import { useState as useState16 } from "react";
function InwentaryzacjaPanel({ plants, inventory, containers, plantContainerSizes, batchSegments, batches, onPerformInventoryCount }) {
  const [plantId, setPlantId] = useState16(plants[0] ? plants[0].id : "");
  const avail = resolveContainers(plantContainerSizes, containers, plantId);
  const [container, setContainer] = useState16(avail[0] || "grunt");
  const [trackAsBatch, setTrackAsBatch] = useState16(false);
  const [segmentId, setSegmentId] = useState16("");
  const [stanFizyczny, setStanFizyczny] = useState16(0);
  const [powod, setPowod] = useState16("");
  const [kosztJednostkowy, setKosztJednostkowy] = useState16(0);
  const [location, setLocation] = useState16("");
  const [formError, setFormError] = useState16("");
  const [lastResult, setLastResult] = useState16(null);
  const matchingSegments = (batchSegments || []).filter(
    (s) => s.plantId === plantId && s.container === container && s.status === "aktywny"
  );
  const selectedSegment = matchingSegments.find((s) => s.id === segmentId) || null;
  const stanSystemowy = trackAsBatch && selectedSegment ? Number(selectedSegment.ilosc || 0) : Number(inventory[plantId]?.[container] || 0);
  const roznica = clampInt(stanFizyczny, 0) - stanSystemowy;
  function selectPlant(id) {
    setPlantId(id);
    const a = resolveContainers(plantContainerSizes, containers, id);
    setContainer(a[0] || "grunt");
    setSegmentId("");
    setFormError("");
    setLastResult(null);
  }
  function selectContainer(c) {
    setContainer(c);
    setSegmentId("");
    setFormError("");
    setLastResult(null);
  }
  function submit() {
    setFormError("");
    if (!plantId) {
      setFormError("Wybierz odmian\u0119.");
      return;
    }
    if (!container) {
      setFormError("Wybierz pojemnik.");
      return;
    }
    if (!powod.trim()) {
      setFormError("Podaj pow\xF3d inwentaryzacji.");
      return;
    }
    if (trackAsBatch && !segmentId) {
      setFormError("Zaznaczy\u0142e\u015B \u201E\u015Aled\u017A jako parti\u0119\u201D \u2014 wybierz rzeczywisty segment, albo odznacz \u015Bledzenie.");
      return;
    }
    if (roznica === 0) {
      setFormError("Brak r\xF3\u017Cnicy mi\u0119dzy stanem systemowym a fizycznym \u2014 nic do zatwierdzenia.");
      return;
    }
    if (roznica > 0 && Math.max(0, Number(kosztJednostkowy || 0)) <= 0) {
      setFormError("Nadwy\u017Cka wymaga podania kosztu jednostkowego.");
      return;
    }
    const result = onPerformInventoryCount({
      plantId,
      container,
      trackAsBatch,
      segmentId: trackAsBatch ? segmentId : null,
      stanFizyczny: clampInt(stanFizyczny, 0),
      powod: powod.trim(),
      kosztJednostkowy: Math.max(0, Number(kosztJednostkowy || 0)),
      location: location.trim() || null
    });
    if (result) setLastResult(result);
    setPowod("");
    setKosztJednostkowy(0);
    setLocation("");
  }
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 12 } }, "Por\xF3wnaj stan systemowy z rzeczywistym stanem fizycznym i zatwierd\u017A r\xF3\u017Cnic\u0119. Ujemna r\xF3\u017Cnica pomniejsza stan (bez zmiany kosztu jednostkowego); dodatnia r\xF3\u017Cnica bez znanego pochodzenia \u2014 je\u015Bli \u015Bledzisz partie \u2014 zak\u0142ada now\u0105 parti\u0119 oznaczon\u0105 jako korekta."), /* @__PURE__ */ React.createElement("div", { className: "order-form", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana"), /* @__PURE__ */ React.createElement("select", { value: plantId, onChange: (e) => selectPlant(e.target.value) }, plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana)))), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Pojemnik"), /* @__PURE__ */ React.createElement("select", { value: container, onChange: (e) => selectContainer(e.target.value) }, avail.map((c) => /* @__PURE__ */ React.createElement("option", { key: c, value: c }, containerLabel(c))))), /* @__PURE__ */ React.createElement("label", { className: "checkbox-field" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: trackAsBatch, onChange: (e) => {
    setTrackAsBatch(e.target.checked);
    setSegmentId("");
    setFormError("");
  } }), /* @__PURE__ */ React.createElement("span", null, "\u015Aled\u017A jako parti\u0119 (por\xF3wnaj konkretny segment zamiast \u0142\u0105cznego stanu magazynu)")), trackAsBatch && matchingSegments.length > 0 && /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Segment"), /* @__PURE__ */ React.createElement("select", { value: segmentId, onChange: (e) => {
    setSegmentId(e.target.value);
    setFormError("");
  } }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 wybierz segment \u2014"), matchingSegments.map((s) => /* @__PURE__ */ React.createElement("option", { key: s.id, value: s.id }, s.ilosc, " szt. ", s.location ? `\u2014 ${s.location}` : "\u2014 bez lokalizacji", " (partia ", batchLabel((batches || []).find((b) => b.id === s.batchId)), ")")))), trackAsBatch && matchingSegments.length === 0 && /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Brak \u015Bledzonej partii dla tej odmiany i pojemnika \u2014 odznacz \u201E\u015Aled\u017A jako parti\u0119\u201D (inwentaryzacja zadzia\u0142a na \u0142\u0105cznym stanie magazynu)."), /* @__PURE__ */ React.createElement("div", { className: "order-item-subtotal" }, "ILO\u015A\u0106 W SYSTEMIE: ", /* @__PURE__ */ React.createElement("strong", null, stanSystemowy)), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Ilo\u015B\u0107 fizyczna (rzeczywi\u015Bcie policzona)"), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "0", value: stanFizyczny, onChange: (e) => setStanFizyczny(clampInt(e.target.value, 0)) })), /* @__PURE__ */ React.createElement("div", { className: "order-item-subtotal", style: { color: roznica < 0 ? "var(--danger, #c0392b)" : roznica > 0 ? "var(--accent, #2e7d32)" : void 0 } }, "R\xD3\u017BNICA: ", /* @__PURE__ */ React.createElement("strong", null, roznica > 0 ? "+" : "", roznica)), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Pow\xF3d"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "np. inwentaryzacja kwartalna, znaleziono wi\u0119cej ni\u017C w systemie...", value: powod, onChange: (e) => setPowod(e.target.value) })), roznica > 0 && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Koszt jednostkowy nadwy\u017Cki (wymagane)"), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", step: "0.01", value: kosztJednostkowy, onChange: (e) => setKosztJednostkowy(e.target.value) })), trackAsBatch && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Nadwy\u017Cka o nieznanym pochodzeniu \u2014 zostanie za\u0142o\u017Cona jako osobna partia \u201Ekorekta\u201D, nie zostanie dopisana anonimowo do istniej\u0105cego segmentu."), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Lokalizacja (opcjonalnie)"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "np. Kwatera A", value: location, onChange: (e) => setLocation(e.target.value) })))), formError && /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { color: "var(--danger, #c0392b)" } }, formError), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", disabled: roznica === 0, onClick: submit }, "Zatwierd\u017A inwentaryzacj\u0119"), lastResult && /* @__PURE__ */ React.createElement("div", { className: "division-result-banner", style: { marginTop: 12, padding: 10, border: "1px solid var(--line, #ddd)", borderRadius: 8 } }, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 600 } }, "INWENTARYZACJA"), /* @__PURE__ */ React.createElement("div", null, "Stan systemowy: ", lastResult.stanSystemowy), /* @__PURE__ */ React.createElement("div", null, "Stan fizyczny: ", lastResult.stanFizyczny), /* @__PURE__ */ React.createElement("div", null, "R\xF3\u017Cnica: ", lastResult.roznica > 0 ? "+" : "", lastResult.roznica), lastResult.newBatch && /* @__PURE__ */ React.createElement("div", { style: { marginTop: 6 } }, "Nowa partia (nieznane pochodzenie): #", lastResult.newBatch.id, " \u2014 ", lastResult.newBatch.ilosc, " szt."))));
}

// src/components/magazyn/HistoriaPanel.jsx
function HistoriaPanel({ log }) {
  if (log.length === 0) {
    return /* @__PURE__ */ React.createElement("div", { className: "empty-state", style: { marginTop: 12 } }, "Brak zarejestrowanych zmian. Historia zacznie si\u0119 wype\u0142nia\u0107, gdy zmienisz stan magazynu, zrealizujesz zam\xF3wienie, zg\u0142osisz strat\u0119 albo dodasz odmian\u0119 czy klienta.");
  }
  return /* @__PURE__ */ React.createElement("div", { className: "log-list", style: { marginTop: 12 } }, log.map((entry) => /* @__PURE__ */ React.createElement("div", { key: entry.id, className: "log-row" }, /* @__PURE__ */ React.createElement("span", { className: "log-time" }, formatLogTime(entry.ts)), /* @__PURE__ */ React.createElement("span", { className: "log-text" }, entry.text))));
}

// src/components/magazyn/KosztyStalePanel.jsx
import { useState as useState17 } from "react";
import { Plus as Plus6, Trash2 as Trash27 } from "lucide-react";
var PERIODS = ["miesi\u0119cznie", "rocznie", "jednorazowo"];
function emptyOverheadForm() {
  return { nazwa: "", kwota: "", okres: "miesi\u0119cznie", data: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) };
}
function annualizedValue(item) {
  const kwota = Number(item.kwota || 0);
  if (item.okres === "miesi\u0119cznie") return kwota * 12;
  if (item.okres === "rocznie") return kwota;
  return 0;
}
function KosztyStalePanel({ costs: overheadCosts, onAdd, onDelete }) {
  const [addOpen, setAddOpen] = useState17(false);
  const [f, setF] = useState17(emptyOverheadForm());
  const [confirmingId, setConfirmingId] = useState17(null);
  const recurringYearly = overheadCosts.reduce((s, it) => s + annualizedValue(it), 0);
  const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
  const oneTimeThisYear = overheadCosts.filter((it) => it.okres === "jednorazowo" && (it.data || "").slice(0, 4) === String(currentYear)).reduce((s, it) => s + Number(it.kwota || 0), 0);
  function submit() {
    if (!f.nazwa.trim() || Number(f.kwota) <= 0) return;
    onAdd({ id: uid2("oh"), nazwa: f.nazwa.trim(), kwota: Math.max(0, Number(f.kwota) || 0), okres: f.okres, data: f.data || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) });
    setF(emptyOverheadForm());
    setAddOpen(false);
  }
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Koszty prowadzenia szk\xF3\u0142ki niezwi\u0105zane z konkretn\u0105 ro\u015Blin\u0105 \u2014 woda, pr\u0105d, nawozy, \u015Brodki ochrony, ubezpieczenie itd. Nie wp\u0142ywaj\u0105 na koszt/szt. w Cenniku."), /* @__PURE__ */ React.createElement("div", { className: "stat-row", style: { marginBottom: 12 } }, /* @__PURE__ */ React.createElement("div", { className: "stat-box" }, /* @__PURE__ */ React.createElement("span", { className: "stat-label" }, "Sta\u0142e (miesi\u0119czne + roczne) w skali roku"), /* @__PURE__ */ React.createElement("span", { className: "stat-value" }, money(recurringYearly), " z\u0142")), /* @__PURE__ */ React.createElement("div", { className: "stat-box" }, /* @__PURE__ */ React.createElement("span", { className: "stat-label" }, "Jednorazowe w ", currentYear), /* @__PURE__ */ React.createElement("span", { className: "stat-value" }, money(oneTimeThisYear), " z\u0142"))), /* @__PURE__ */ React.createElement("div", { className: "plant-list" }, overheadCosts.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak wpisanych koszt\xF3w \u2014 dodaj poni\u017Cej."), overheadCosts.slice().sort((a, b) => (b.data || "").localeCompare(a.data || "")).map((it) => /* @__PURE__ */ React.createElement("div", { key: it.id, className: "supply-card" }, /* @__PURE__ */ React.createElement("div", { className: "supply-card-main" }, /* @__PURE__ */ React.createElement("div", { className: "plant-name" }, it.nazwa), /* @__PURE__ */ React.createElement("div", { className: "supply-meta" }, money(it.kwota), " z\u0142 \xB7 ", it.okres, it.okres === "jednorazowo" ? ` \xB7 ${it.data}` : "")), confirmingId !== it.id ? /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => setConfirmingId(it.id) }, /* @__PURE__ */ React.createElement(Trash27, { size: 16 })) : /* @__PURE__ */ React.createElement("div", { className: "confirm-box" }, /* @__PURE__ */ React.createElement("span", null, "Usun\u0105\u0107?"), /* @__PURE__ */ React.createElement("div", { className: "confirm-actions" }, /* @__PURE__ */ React.createElement("button", { className: "danger-btn small", onClick: () => {
    onDelete(it.id);
    setConfirmingId(null);
  } }, "Usu\u0144"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => setConfirmingId(null) }, "Anuluj")))))), !addOpen ? /* @__PURE__ */ React.createElement("button", { className: "ghost-btn add-plant-btn", onClick: () => setAddOpen(true) }, /* @__PURE__ */ React.createElement(Plus6, { size: 15 }), " Dodaj koszt") : /* @__PURE__ */ React.createElement("div", { className: "order-form" }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Nazwa"), /* @__PURE__ */ React.createElement("input", { value: f.nazwa, onChange: (e) => setF({ ...f, nazwa: e.target.value }), placeholder: "np. Pr\u0105d, Woda, Nawozy wiosenne" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Kwota (z\u0142)"), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", step: "0.01", value: f.kwota, onChange: (e) => setF({ ...f, kwota: e.target.value }), placeholder: "np. 250" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Okres"), /* @__PURE__ */ React.createElement("select", { value: f.okres, onChange: (e) => setF({ ...f, okres: e.target.value }) }, PERIODS.map((p) => /* @__PURE__ */ React.createElement("option", { key: p, value: p }, p)))), f.okres === "jednorazowo" && /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Data"), /* @__PURE__ */ React.createElement("input", { type: "date", value: f.data, onChange: (e) => setF({ ...f, data: e.target.value }) })), /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: () => {
    setAddOpen(false);
    setF(emptyOverheadForm());
  } }, "Anuluj"), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", disabled: !f.nazwa.trim() || !(Number(f.kwota) > 0), onClick: submit }, "Zapisz"))));
}

// src/components/magazyn/MagazynTab.jsx
function MagazynTab(props) {
  const [sub, setSub] = useState18("rosliny");
  const {
    plants,
    inventory,
    onQtyChange,
    totals,
    containers,
    potSizes,
    onAddPotSize,
    plantContainerSizes,
    onTogglePlantContainer,
    photos,
    setPhotos,
    onPhotoError,
    onAddPlant,
    onRemovePlant,
    supplies,
    onSupplyQtyChange,
    onAddSupply,
    onRemoveSupply,
    losses,
    onAddLoss,
    onDeleteLoss,
    cennik,
    log,
    costs,
    potRecipes,
    substrateCostPerL,
    onSetPotRecipe,
    onSetSubstrateCostPerL,
    onPerformDivision,
    onSettleDivision,
    onPerformPurchase,
    onPerformTransplant,
    onPerformInventoryCount,
    batchSegments,
    batches,
    onSetSegmentQuality,
    productionPlans,
    onAddPlan,
    onSetPlanStatus,
    onDeletePlan,
    batchPhotos,
    onAddBatchPhoto,
    onDeleteBatchPhoto,
    jumpToBatchId,
    jumpToken,
    overheadCosts,
    onAddOverheadCost,
    onDeleteOverheadCost
  } = props;
  useEffect5(() => {
    if (jumpToken) setSub("partie");
  }, [jumpToken]);
  return /* @__PURE__ */ React.createElement("div", { className: "tab-pad" }, /* @__PURE__ */ React.createElement("div", { className: "segmented scrollable" }, /* @__PURE__ */ React.createElement("button", { className: sub === "rosliny" ? "active" : "", onClick: () => setSub("rosliny") }, "Ro\u015Bliny"), /* @__PURE__ */ React.createElement("button", { className: sub === "zakup" ? "active" : "", onClick: () => setSub("zakup") }, "Zakup"), /* @__PURE__ */ React.createElement("button", { className: sub === "podzial" ? "active" : "", onClick: () => setSub("podzial") }, "Podzia\u0142"), /* @__PURE__ */ React.createElement("button", { className: sub === "przesadzenie" ? "active" : "", onClick: () => setSub("przesadzenie") }, "Przesadzenie"), /* @__PURE__ */ React.createElement("button", { className: sub === "partie" ? "active" : "", onClick: () => setSub("partie") }, "Partie"), /* @__PURE__ */ React.createElement("button", { className: sub === "gdzie" ? "active" : "", onClick: () => setSub("gdzie") }, "Co mam gdzie"), /* @__PURE__ */ React.createElement("button", { className: sub === "zaleglosci" ? "active" : "", onClick: () => setSub("zaleglosci") }, "Zaleg\u0142o\u015Bci"), /* @__PURE__ */ React.createElement("button", { className: sub === "plan" ? "active" : "", onClick: () => setSub("plan") }, "Plan produkcji"), /* @__PURE__ */ React.createElement("button", { className: sub === "zaopatrzenie" ? "active" : "", onClick: () => setSub("zaopatrzenie") }, "Zaopatrzenie"), /* @__PURE__ */ React.createElement("button", { className: sub === "koszty" ? "active" : "", onClick: () => setSub("koszty") }, "Koszty sta\u0142e"), /* @__PURE__ */ React.createElement("button", { className: sub === "straty" ? "active" : "", onClick: () => setSub("straty") }, "Straty", losses.length ? ` (${losses.length})` : ""), /* @__PURE__ */ React.createElement("button", { className: sub === "inwentaryzacja" ? "active" : "", onClick: () => setSub("inwentaryzacja") }, "Inwentaryzacja"), /* @__PURE__ */ React.createElement("button", { className: sub === "historia" ? "active" : "", onClick: () => setSub("historia") }, "Historia")), sub === "rosliny" && /* @__PURE__ */ React.createElement(
    RoslinyPanel,
    {
      plants,
      inventory,
      onQtyChange,
      totals,
      containers,
      potSizes,
      onAddPotSize,
      plantContainerSizes,
      onTogglePlantContainer,
      photos,
      setPhotos,
      onPhotoError,
      onAddPlant,
      onRemovePlant,
      onSettleDivision
    }
  ), sub === "zakup" && /* @__PURE__ */ React.createElement(
    ZakupPanel,
    {
      plants,
      containers,
      plantContainerSizes,
      onPerformPurchase
    }
  ), sub === "podzial" && /* @__PURE__ */ React.createElement(
    PodzialPanel,
    {
      plants,
      inventory,
      containers,
      plantContainerSizes,
      costs,
      potRecipes,
      substrateCostPerL,
      onPerformDivision,
      batchSegments,
      batches
    }
  ), sub === "przesadzenie" && /* @__PURE__ */ React.createElement(
    PrzesadzeniePanel,
    {
      plants,
      inventory,
      containers,
      plantContainerSizes,
      costs,
      potRecipes,
      substrateCostPerL,
      batchSegments,
      onPerformTransplant,
      batches
    }
  ), sub === "partie" && /* @__PURE__ */ React.createElement(
    PartiePanel,
    {
      plants,
      batches,
      batchSegments,
      onSetSegmentQuality,
      batchPhotos,
      onAddBatchPhoto,
      onDeleteBatchPhoto,
      photos,
      onPhotoError,
      jumpToBatchId,
      jumpToken
    }
  ), sub === "gdzie" && /* @__PURE__ */ React.createElement(CoMamGdziePanel, { plants, inventory, batchSegments, batches }), sub === "zaleglosci" && /* @__PURE__ */ React.createElement(ZaleglosciPanel, { plants, batches, batchSegments }), sub === "plan" && /* @__PURE__ */ React.createElement(
    PlanProdukcjiPanel,
    {
      plants,
      batchSegments,
      batches,
      productionPlans,
      onAddPlan,
      onSetStatus: onSetPlanStatus,
      onDeletePlan
    }
  ), sub === "zaopatrzenie" && /* @__PURE__ */ React.createElement(
    ZaopatrzeniePanel,
    {
      supplies,
      onChangeQty: onSupplyQtyChange,
      onAdd: onAddSupply,
      onRemove: onRemoveSupply,
      potSizes,
      potRecipes,
      substrateCostPerL,
      onSetPotRecipe,
      onSetSubstrateCostPerL
    }
  ), sub === "koszty" && /* @__PURE__ */ React.createElement(KosztyStalePanel, { costs: overheadCosts, onAdd: onAddOverheadCost, onDelete: onDeleteOverheadCost }), sub === "straty" && /* @__PURE__ */ React.createElement(
    StratyPanel,
    {
      plants,
      inventory,
      containers,
      plantContainerSizes,
      losses,
      onAdd: onAddLoss,
      onDelete: onDeleteLoss,
      costs,
      batchSegments,
      batches
    }
  ), sub === "inwentaryzacja" && /* @__PURE__ */ React.createElement(
    InwentaryzacjaPanel,
    {
      plants,
      inventory,
      containers,
      plantContainerSizes,
      batchSegments,
      onPerformInventoryCount,
      batches
    }
  ), sub === "historia" && /* @__PURE__ */ React.createElement(HistoriaPanel, { log }));
}

// src/components/harmonogram/HarmonogramTab.jsx
import { useState as useState20 } from "react";
import { Calendar as Calendar4, ChevronDown as ChevronDown4, ChevronRight as ChevronRight6, ClipboardCheck } from "lucide-react";

// src/components/harmonogram/TaskList.jsx
import { Check } from "lucide-react";
function TaskList({ tasks, month, year, done, onToggle, emptyText, compact }) {
  if (tasks.length === 0) return /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, emptyText);
  return /* @__PURE__ */ React.createElement("div", { className: `task-list ${compact ? "compact" : ""}` }, tasks.map((t, idx) => {
    const key = taskKey(year, month, t.plant.id, t.type);
    const isDone = !!done[key];
    const meta = TASK_META[t.type];
    const hasSegments = t.type === "podzial" && t.segments && t.segments.length > 0;
    return /* @__PURE__ */ React.createElement("div", { key: idx }, /* @__PURE__ */ React.createElement("button", { className: `task-row ${isDone ? "done" : ""}`, onClick: () => onToggle(key) }, /* @__PURE__ */ React.createElement("span", { className: `task-check ${isDone ? "checked" : ""}` }, isDone && /* @__PURE__ */ React.createElement(Check, { size: 13, strokeWidth: 3 })), /* @__PURE__ */ React.createElement("span", { className: "task-text" }, /* @__PURE__ */ React.createElement("span", { className: "task-plant" }, t.plant.nazwa_pl), /* @__PURE__ */ React.createElement("span", { className: "task-variety" }, t.plant.odmiana)), /* @__PURE__ */ React.createElement("span", { className: `task-tag ${meta.cls}` }, meta.label)), hasSegments && /* @__PURE__ */ React.createElement("div", { className: "hint-text", style: { marginLeft: 30, marginTop: -4, marginBottom: 4 } }, "Masz w tym oknie: ", t.segments.map((s) => `${s.ilosc} szt. ${containerLabel(s.container)}${s.location ? ` (${s.location})` : ""} \u2014 partia ${s.resolvedBatchLabel}`).join("; ")));
  }));
}

// src/components/harmonogram/CustomTaskBlock.jsx
import { useState as useState19 } from "react";
import { Check as Check2, ListPlus as ListPlus2, Trash2 as Trash28 } from "lucide-react";
function CustomTaskBlock({ year, month, tasks, onAdd, onToggle, onRemove, compact }) {
  const [text, setText] = useState19("");
  const [adding, setAdding] = useState19(false);
  function submit() {
    if (!text.trim()) return;
    onAdd(year, month, text);
    setText("");
    setAdding(false);
  }
  return /* @__PURE__ */ React.createElement("div", { className: `custom-task-block ${compact ? "compact" : ""}` }, tasks.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "task-list" }, tasks.map((t) => /* @__PURE__ */ React.createElement("div", { key: t.id, className: `task-row custom-row ${t.done ? "done" : ""}` }, /* @__PURE__ */ React.createElement("button", { className: "task-check-btn", onClick: () => onToggle(year, month, t.id) }, /* @__PURE__ */ React.createElement("span", { className: `task-check ${t.done ? "checked" : ""}` }, t.done && /* @__PURE__ */ React.createElement(Check2, { size: 13, strokeWidth: 3 }))), /* @__PURE__ */ React.createElement("button", { className: "task-text-btn", onClick: () => onToggle(year, month, t.id) }, /* @__PURE__ */ React.createElement("span", { className: "task-plant" }, t.text)), /* @__PURE__ */ React.createElement("span", { className: "task-tag tag-wlasne" }, "W\u0142asne"), /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => onRemove(year, month, t.id) }, /* @__PURE__ */ React.createElement(Trash28, { size: 14 }))))), !adding ? /* @__PURE__ */ React.createElement("button", { className: "ghost-btn add-task-btn", onClick: () => setAdding(true) }, /* @__PURE__ */ React.createElement(ListPlus2, { size: 15 }), " Dodaj zadanie na ", MONTHS[month].toLowerCase()) : /* @__PURE__ */ React.createElement("div", { className: "add-task-form" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      autoFocus: true,
      placeholder: "np. Podlanie donic w tunelu",
      value: text,
      onChange: (e) => setText(e.target.value),
      onKeyDown: (e) => {
        if (e.key === "Enter") submit();
        if (e.key === "Escape") {
          setAdding(false);
          setText("");
        }
      }
    }
  ), /* @__PURE__ */ React.createElement("button", { className: "primary-btn small", onClick: submit, disabled: !text.trim() }, "Dodaj"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => {
    setAdding(false);
    setText("");
  } }, "Anuluj")));
}

// src/components/harmonogram/GeneralTasksForMonth.jsx
import { Calendar as Calendar3 } from "lucide-react";
function GeneralTasksForMonth({ tasks, onCycleTask }) {
  if (tasks.length === 0) return null;
  return /* @__PURE__ */ React.createElement("div", { className: "task-list", style: { marginTop: 8 } }, tasks.map((t) => {
    const meta = TASK_STATUS_META[t.status];
    return /* @__PURE__ */ React.createElement("div", { key: t.id, className: "task-row custom-row" }, /* @__PURE__ */ React.createElement("span", { className: "task-date-badge" }, /* @__PURE__ */ React.createElement(Calendar3, { size: 11 }), " ", formatShortDate(t.date)), /* @__PURE__ */ React.createElement("button", { className: "task-text-btn", onClick: () => onCycleTask(t.id) }, /* @__PURE__ */ React.createElement("span", { className: "task-plant" }, t.text)), /* @__PURE__ */ React.createElement("button", { className: `task-tag status-tag ${meta.cls}`, onClick: () => onCycleTask(t.id) }, meta.label));
  }));
}

// src/components/harmonogram/HarmonogramTab.jsx
function HarmonogramTab({ plants, done, setDone, customTasks, setCustomTasks, tasks, onCycleTask, batchSegments, batches }) {
  const now = /* @__PURE__ */ new Date();
  const curMonth = now.getMonth() + 1;
  const curYear = now.getFullYear();
  const [expandedMonth, setExpandedMonth] = useState20(curMonth);
  function toggleDone(key) {
    setDone((prev) => ({ ...prev, [key]: !prev[key] }));
  }
  function addCustomTask(year, month, text) {
    const trimmed = text.trim();
    if (!trimmed) return;
    const key = monthKey(year, month);
    const task = { id: uid("t"), text: trimmed, done: false };
    setCustomTasks((prev) => ({ ...prev, [key]: [...prev[key] || [], task] }));
  }
  function toggleCustomTask(year, month, id) {
    const key = monthKey(year, month);
    setCustomTasks((prev) => ({ ...prev, [key]: (prev[key] || []).map((t) => t.id === id ? { ...t, done: !t.done } : t) }));
  }
  function removeCustomTask(year, month, id) {
    const key = monthKey(year, month);
    setCustomTasks((prev) => ({ ...prev, [key]: (prev[key] || []).filter((t) => t.id !== id) }));
  }
  return /* @__PURE__ */ React.createElement("div", { className: "tab-pad" }, /* @__PURE__ */ React.createElement("div", { className: "section-title" }, /* @__PURE__ */ React.createElement(ClipboardCheck, { size: 17 }), /* @__PURE__ */ React.createElement("span", null, "Ten miesi\u0105c: ", MONTHS[curMonth])), /* @__PURE__ */ React.createElement(
    TaskList,
    {
      tasks: buildMonthTasks(plants, curMonth, batchSegments, batches),
      month: curMonth,
      year: curYear,
      done,
      onToggle: toggleDone,
      emptyText: "Brak zaplanowanych prac cyklicznych w tym miesi\u0105cu."
    }
  ), /* @__PURE__ */ React.createElement(GeneralTasksForMonth, { tasks: tasksForMonth(tasks, curYear, curMonth), onCycleTask }), /* @__PURE__ */ React.createElement(
    CustomTaskBlock,
    {
      year: curYear,
      month: curMonth,
      tasks: customTasks[monthKey(curYear, curMonth)] || [],
      onAdd: addCustomTask,
      onToggle: toggleCustomTask,
      onRemove: removeCustomTask
    }
  ), /* @__PURE__ */ React.createElement("div", { className: "section-title", style: { marginTop: 22 } }, /* @__PURE__ */ React.createElement(Calendar4, { size: 17 }), /* @__PURE__ */ React.createElement("span", null, "Ca\u0142y rok")), /* @__PURE__ */ React.createElement("div", { className: "month-accordion" }, Array.from({ length: 12 }, (_, i) => i + 1).map((m) => {
    const monthTasks = buildMonthTasks(plants, m, batchSegments, batches);
    const custom = customTasks[monthKey(curYear, m)] || [];
    const generalForMonth = tasksForMonth(tasks, curYear, m);
    const totalCount = monthTasks.length + custom.length + generalForMonth.length;
    const isOpen = expandedMonth === m;
    return /* @__PURE__ */ React.createElement("div", { key: m, className: `month-block ${m === curMonth ? "is-current" : ""}` }, /* @__PURE__ */ React.createElement("button", { className: "month-head", onClick: () => setExpandedMonth(isOpen ? null : m) }, /* @__PURE__ */ React.createElement("span", null, MONTHS[m]), /* @__PURE__ */ React.createElement("span", { className: "month-count" }, totalCount ? `${totalCount} zad.` : "\u2014"), isOpen ? /* @__PURE__ */ React.createElement(ChevronDown4, { size: 16 }) : /* @__PURE__ */ React.createElement(ChevronRight6, { size: 16 })), isOpen && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(
      TaskList,
      {
        tasks: monthTasks,
        month: m,
        year: curYear,
        done,
        onToggle: toggleDone,
        emptyText: "Brak prac cyklicznych w tym miesi\u0105cu.",
        compact: true
      }
    ), /* @__PURE__ */ React.createElement(GeneralTasksForMonth, { tasks: generalForMonth, onCycleTask }), /* @__PURE__ */ React.createElement(CustomTaskBlock, { year: curYear, month: m, tasks: custom, onAdd: addCustomTask, onToggle: toggleCustomTask, onRemove: removeCustomTask, compact: true })));
  })));
}

// src/components/sprzedaz/SprzedazTab.jsx
import { useState as useState26 } from "react";

// src/components/sprzedaz/CennikPanel.jsx
import { useState as useState21 } from "react";
import { ChevronDown as ChevronDown5, ChevronRight as ChevronRight7, Search as Search3, X as X3, Download as Download2 } from "lucide-react";
function csvCell(value) {
  const s = String(value ?? "");
  if (s.includes(";") || s.includes('"') || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}
function buildCennikCsv(plants, potSizes, plantContainerSizes, cennik) {
  const header = ["Odmiana (PL)", "Nazwa \u0142aci\u0144ska", ...potSizes];
  const rows = [header];
  plants.forEach((p) => {
    const allowed = resolvePotContainers(plantContainerSizes, potSizes, p.id);
    const row = cennik[p.id] || {};
    const cells = potSizes.map((c) => {
      if (!allowed.includes(c)) return "";
      const cena = Number(row[c] || 0);
      return cena > 0 ? cena.toFixed(2).replace(".", ",") : "";
    });
    rows.push([p.nazwa_pl, p.odmiana, ...cells]);
  });
  return rows.map((r) => r.map(csvCell).join(";")).join("\r\n");
}
function CennikPanel({ plants, potSizes, plantContainerSizes, cennik, setCennik, costs, onSetCost }) {
  const [query, setQuery] = useState21("");
  const [openId, setOpenId] = useState21(null);
  const filtered = plants.filter((p) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return p.nazwa_pl.toLowerCase().includes(q) || p.odmiana.toLowerCase().includes(q);
  });
  function setPrice(plantId, container, val) {
    const n = Math.max(0, Number(val) || 0);
    setCennik((prev) => ({ ...prev, [plantId]: { ...prev[plantId] || {}, [container]: n } }));
  }
  function exportCsv() {
    try {
      const csv = buildCennikCsv(plants, potSizes, plantContainerSizes, cennik);
      const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `cennik-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
    }
  }
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "form-actions", style: { marginTop: 12 } }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: exportCsv }, /* @__PURE__ */ React.createElement(Download2, { size: 15 }), " Pobierz cennik (CSV)")), /* @__PURE__ */ React.createElement("div", { className: "search-bar", style: { marginTop: 8 } }, /* @__PURE__ */ React.createElement(Search3, { size: 17 }), /* @__PURE__ */ React.createElement("input", { placeholder: "Szukaj odmiany\u2026", value: query, onChange: (e) => setQuery(e.target.value) }), query && /* @__PURE__ */ React.createElement("button", { className: "icon-btn", onClick: () => setQuery("") }, /* @__PURE__ */ React.createElement(X3, { size: 16 }))), /* @__PURE__ */ React.createElement("div", { className: "price-list" }, filtered.map((p) => {
    const row = cennik[p.id] || {};
    const costRow = costs[p.id] || {};
    const isOpen = openId === p.id;
    return /* @__PURE__ */ React.createElement("div", { key: p.id, className: "price-card" }, /* @__PURE__ */ React.createElement("button", { className: "price-card-head", onClick: () => setOpenId(isOpen ? null : p.id) }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "plant-name" }, p.nazwa_pl), /* @__PURE__ */ React.createElement("div", { className: "plant-variety" }, p.odmiana)), isOpen ? /* @__PURE__ */ React.createElement(ChevronDown5, { size: 16 }) : /* @__PURE__ */ React.createElement(ChevronRight7, { size: 16 })), /* @__PURE__ */ React.createElement("div", { className: "price-inputs" }, resolvePotContainers(plantContainerSizes, potSizes, p.id).map((c) => /* @__PURE__ */ React.createElement("label", { key: c, className: "price-field" }, /* @__PURE__ */ React.createElement("span", null, c), /* @__PURE__ */ React.createElement("div", { className: "price-input-wrap" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", placeholder: "0", value: row[c] ?? "", onChange: (e) => setPrice(p.id, c, e.target.value) }), /* @__PURE__ */ React.createElement("span", { className: "pln" }, "z\u0142"))))), isOpen && /* @__PURE__ */ React.createElement("div", { className: "cost-margin-body" }, resolvePotContainers(plantContainerSizes, potSizes, p.id).map((c) => {
      const cena = Number(row[c] || 0);
      const koszt = Number(costRow[c] || 0);
      const marza = cena - koszt;
      const marzaPct = cena > 0 ? marza / cena * 100 : 0;
      return /* @__PURE__ */ React.createElement("div", { key: c, className: "cost-margin-row" }, /* @__PURE__ */ React.createElement("span", { className: "cost-margin-label" }, c), /* @__PURE__ */ React.createElement("label", { className: "price-field" }, /* @__PURE__ */ React.createElement("span", null, "Koszt/szt."), /* @__PURE__ */ React.createElement("div", { className: "price-input-wrap small" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", step: "0.01", placeholder: "0", value: costRow[c] != null ? Math.round(Number(costRow[c]) * 100) / 100 : "", onChange: (e) => onSetCost(p.id, c, e.target.value) }), /* @__PURE__ */ React.createElement("span", { className: "pln" }, "z\u0142"))), /* @__PURE__ */ React.createElement("span", { className: `margin-badge ${marza < 0 ? "neg" : ""}` }, "Mar\u017Ca: ", money(marza), " z\u0142 (", marzaPct.toFixed(0), "%)"));
    }), /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { margin: "6px 0 0" } }, "Koszt startowy (np. dla kupionych P9) wpisz r\u0119cznie. Koszt sztuk powsta\u0142ych przez Podzia\u0142 liczy si\u0119 sam.")));
  })));
}

// src/components/sprzedaz/ZestawyPanel.jsx
import { useState as useState22 } from "react";
import { Boxes, Plus as Plus7, Trash2 as Trash29, Calculator as CalcIcon } from "lucide-react";
function emptyZestawItem(plants, potSizes) {
  return { plantId: plants[0] ? plants[0].id : "", container: potSizes && potSizes[0] ? potSizes[0] : "P9", ilosc: 1, etykieta: "" };
}
function ZestawyPanel({ plants, potSizes, plantContainerSizes, zestawy, setZestawy, cennik }) {
  const [formOpen, setFormOpen] = useState22(false);
  const [nazwa, setNazwa] = useState22("");
  const [cena, setCena] = useState22("");
  const [modulMb, setModulMb] = useState22("");
  const [items, setItems] = useState22([emptyZestawItem(plants, potSizes)]);
  const [confirmingId, setConfirmingId] = useState22(null);
  const [expandedId, setExpandedId] = useState22(null);
  const [calcOpenIdx, setCalcOpenIdx] = useState22(null);
  function resetForm() {
    setNazwa("");
    setCena("");
    setModulMb("");
    setItems([emptyZestawItem(plants, potSizes)]);
    setFormOpen(false);
    setCalcOpenIdx(null);
  }
  function updateItem(idx, patch) {
    setItems((prev) => prev.map((it, i) => {
      if (i !== idx) return it;
      const next = { ...it, ...patch };
      if (patch.plantId !== void 0) {
        const avail = resolvePotContainers(plantContainerSizes, potSizes, next.plantId);
        if (!avail.includes(next.container)) next.container = avail[0] || potSizes[0];
      }
      return next;
    }));
  }
  function addItem() {
    setItems((prev) => [...prev, emptyZestawItem(plants, potSizes)]);
  }
  function removeItem(idx) {
    setItems((prev) => prev.filter((_, i) => i !== idx));
    if (calcOpenIdx === idx) setCalcOpenIdx(null);
  }
  const referenceValue = items.reduce((s, it) => {
    const cn = cennik[it.plantId]?.[it.container] || 0;
    return s + cn * Number(it.ilosc || 0);
  }, 0);
  const modulMbNum = Number(modulMb) > 0 ? Number(modulMb) : null;
  function saveZestaw() {
    if (!nazwa.trim() || items.length === 0) return;
    const z = {
      id: uid2("z"),
      nazwa: nazwa.trim(),
      cena: Math.max(0, Number(cena) || 0),
      dlugosc_mb: modulMbNum,
      pozycje: items.map((it) => ({ ...it, ilosc: clampInt(it.ilosc, 1) }))
    };
    setZestawy((prev) => [z, ...prev]);
    resetForm();
  }
  function deleteZestaw(id) {
    setZestawy((prev) => prev.filter((z) => z.id !== id));
    setConfirmingId(null);
  }
  return /* @__PURE__ */ React.createElement("div", null, !formOpen ? /* @__PURE__ */ React.createElement("button", { className: "primary-btn", style: { marginTop: 12 }, onClick: () => setFormOpen(true) }, /* @__PURE__ */ React.createElement(Boxes, { size: 17 }), " Nowy zestaw") : /* @__PURE__ */ React.createElement("div", { className: "order-form" }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Nazwa zestawu"), /* @__PURE__ */ React.createElement("input", { value: nazwa, onChange: (e) => setNazwa(e.target.value), placeholder: "np. \u017Bywop\u0142ot 2mb (modu\u0142) lub Rabata naro\u017Cna" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "D\u0142ugo\u015B\u0107 modu\u0142u (mb) \u2014 opcjonalnie"), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", step: "0.1", value: modulMb, onChange: (e) => setModulMb(e.target.value), placeholder: "np. 2" })), /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { margin: "0 0 4px" } }, modulMbNum ? `Wszystkie rz\u0119dy poni\u017Cej liczone s\u0105 dla ${modulMbNum} mb \u2014 kalkulator sam podpowie ilo\u015B\u0107 dla ka\u017Cdej odmiany. Przy zam\xF3wieniu wpiszesz mno\u017Cnik (np. 4,5 \xD7 ${modulMbNum} mb = ${(modulMbNum * 4.5).toFixed(1)} mb).` : "Podaj d\u0142ugo\u015B\u0107 modu\u0142u, \u017Ceby kalkulator w ka\u017Cdym rz\u0119dzie liczy\u0142 automatycznie t\u0119 sam\u0105 d\u0142ugo\u015B\u0107 (bez wpisywania jej za ka\u017Cdym razem). Zostaw puste, je\u015Bli zestaw nie jest modu\u0142owy (np. gotowy zestaw doniczkowy)."), items.map((it, idx) => {
    const plant = plants.find((p) => p.id === it.plantId);
    const calcOpen = calcOpenIdx === idx;
    return /* @__PURE__ */ React.createElement("div", { key: idx, className: "order-item-row zestaw-row" }, /* @__PURE__ */ React.createElement("div", { className: "zestaw-row-head" }, /* @__PURE__ */ React.createElement("input", { className: "row-label-input", value: it.etykieta, onChange: (e) => updateItem(idx, { etykieta: e.target.value }), placeholder: `Rz\u0105d ${idx + 1} (np. Ty\u0142, \u015Arodek, Prz\xF3d)` }), items.length > 1 && /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => removeItem(idx) }, /* @__PURE__ */ React.createElement(Trash29, { size: 15 }))), /* @__PURE__ */ React.createElement("select", { value: it.plantId, onChange: (e) => updateItem(idx, { plantId: e.target.value }) }, plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana))), /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement("select", { value: it.container, onChange: (e) => updateItem(idx, { container: e.target.value }) }, resolvePotContainers(plantContainerSizes, potSizes, it.plantId).map((c) => /* @__PURE__ */ React.createElement("option", { key: c, value: c }, c))), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "1", value: it.ilosc, onChange: (e) => updateItem(idx, { ilosc: clampInt(e.target.value, 1) }) }), /* @__PURE__ */ React.createElement("button", { type: "button", className: `icon-btn ${calcOpen ? "calc-active" : ""}`, onClick: () => setCalcOpenIdx(calcOpen ? null : idx), title: "Kalkulator nasadze\u0144" }, /* @__PURE__ */ React.createElement(CalcIcon, { size: 16 }))), calcOpen && /* @__PURE__ */ React.createElement(PlantingCalculator, { plant, compact: true, lockedMb: modulMbNum, onApply: (qty) => {
      updateItem(idx, { ilosc: qty });
      setCalcOpenIdx(null);
    } }));
  }), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn", onClick: addItem }, /* @__PURE__ */ React.createElement(Plus7, { size: 15 }), " Dodaj rz\u0105d / odmian\u0119"), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Cena zestawu (warto\u015B\u0107 wg cennika: ", money(referenceValue), " z\u0142)"), /* @__PURE__ */ React.createElement("div", { className: "price-input-wrap" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", placeholder: "0", value: cena, onChange: (e) => setCena(e.target.value) }), /* @__PURE__ */ React.createElement("span", { className: "pln" }, "z\u0142"))), /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: resetForm }, "Anuluj"), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", disabled: !nazwa.trim(), onClick: saveZestaw }, "Zapisz zestaw"))), /* @__PURE__ */ React.createElement("div", { className: "order-list" }, zestawy.length === 0 && !formOpen && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak zestaw\xF3w. Dodaj pierwszy powy\u017Cej \u2014 np. gotowy \u201EZestaw na taras\u201D z 3-4 odmian w jednej cenie."), zestawy.map((z) => {
    const isOpen = expandedId === z.id;
    return /* @__PURE__ */ React.createElement("div", { key: z.id, className: "order-card" }, /* @__PURE__ */ React.createElement("button", { className: "order-card-head", onClick: () => setExpandedId(isOpen ? null : z.id) }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, z.nazwa, z.dlugosc_mb ? ` \xB7 modu\u0142 ${z.dlugosc_mb} mb` : ""), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, z.pozycje.length, " ", z.pozycje.length === 1 ? "pozycja" : "pozycji", " w zestawie")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement("span", { className: "order-sum" }, money(z.cena), " z\u0142"))), isOpen && /* @__PURE__ */ React.createElement("div", { className: "order-card-body" }, z.pozycje.map((it, i) => {
      const plant = plants.find((p) => p.id === it.plantId);
      return /* @__PURE__ */ React.createElement("div", { key: i, className: "order-line" }, /* @__PURE__ */ React.createElement("span", null, it.etykieta ? `${it.etykieta}: ` : "", plant ? `${plant.nazwa_pl} (${plant.odmiana})` : it.plantId, " \xB7 ", it.container, " \xD7 ", it.ilosc));
    }), /* @__PURE__ */ React.createElement("div", { className: "order-card-actions" }, confirmingId !== z.id ? /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => setConfirmingId(z.id) }, /* @__PURE__ */ React.createElement(Trash29, { size: 15 })) : /* @__PURE__ */ React.createElement("div", { className: "confirm-box" }, /* @__PURE__ */ React.createElement("span", null, "Usun\u0105\u0107 zestaw?"), /* @__PURE__ */ React.createElement("div", { className: "confirm-actions" }, /* @__PURE__ */ React.createElement("button", { className: "danger-btn small", onClick: () => deleteZestaw(z.id) }, "Usu\u0144"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => setConfirmingId(null) }, "Anuluj"))))));
  })));
}

// src/components/sprzedaz/ZamowieniaPanel.jsx
import { useState as useState23 } from "react";
import { AlertCircle, Boxes as Boxes2, Plus as Plus8, Trash2 as Trash210 } from "lucide-react";
function clampModuleQty(v) {
  const n = Number(String(v).replace(",", "."));
  if (!Number.isFinite(n) || n <= 0) return 0.1;
  return Math.round(n * 10) / 10;
}
function buildPickingList(order, zestawy, batchSegments) {
  const needed = {};
  function addNeed(plantId, container, qty) {
    needed[plantId] = needed[plantId] || {};
    needed[plantId][container] = (needed[plantId][container] || 0) + qty;
  }
  (order.pozycje || []).forEach((it) => {
    if (it.kind === "plant") {
      addNeed(it.plantId, it.container, Number(it.ilosc || 0));
    } else if (it.kind === "zestaw") {
      const z = zestawy.find((zz) => zz.id === it.zestawId);
      if (z) (z.pozycje || []).forEach((comp) => addNeed(comp.plantId, comp.container, Number(comp.ilosc || 0) * Number(it.ilosc || 0)));
    }
  });
  const items = [];
  Object.entries(needed).forEach(([plantId, row]) => {
    Object.entries(row).forEach(([container, qty]) => {
      let remaining = qty;
      const candidates = (batchSegments || []).filter((s) => s.plantId === plantId && s.container === container && s.status === "aktywny" && Number(s.ilosc || 0) > 0).sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
      for (const seg of candidates) {
        if (remaining <= 0) break;
        const take = Math.min(remaining, Number(seg.ilosc || 0));
        if (take <= 0) continue;
        items.push({ plantId, container, location: seg.location, ilosc: take, batchId: seg.batchId, segmentId: seg.id });
        remaining -= take;
      }
      if (remaining > 0) {
        items.push({ plantId, container, location: null, ilosc: remaining, batchId: null, segmentId: null });
      }
    });
  });
  return items;
}
function ZamowieniaPanel({ plants, potSizes, plantContainerSizes, cennik, orders, onCreateOrder, onDeleteOrder, onFulfillOrder, zestawy, clients, batches, batchSegments }) {
  const [formOpen, setFormOpen] = useState23(false);
  const [klient, setKlient] = useState23("");
  const [items, setItems] = useState23(null);
  const [confirmingId, setConfirmingId] = useState23(null);
  const [fulfillingId, setFulfillingId] = useState23(null);
  const [expandedId, setExpandedId] = useState23(null);
  function makePlantItemLocal() {
    const plant = plants[0];
    const avail = resolvePotContainers(plantContainerSizes, potSizes, plant ? plant.id : "");
    const container = avail[0] || potSizes[0] || "P9";
    const cena = plant ? cennik[plant.id]?.[container] ?? 0 : 0;
    return { kind: "plant", plantId: plant ? plant.id : "", container, ilosc: 1, cena };
  }
  function makeZestawItemLocal() {
    const z = zestawy[0];
    if (!z) return null;
    return { kind: "zestaw", zestawId: z.id, ilosc: 1, cena: z.cena || 0 };
  }
  function openForm() {
    setItems([makePlantItemLocal()]);
    setFormOpen(true);
  }
  function resetForm() {
    setKlient("");
    setItems(null);
    setFormOpen(false);
  }
  function updateItem(idx, patch) {
    setItems((prev) => prev.map((it, i) => {
      if (i !== idx) return it;
      const next = { ...it, ...patch };
      if (next.kind === "plant" && patch.plantId !== void 0) {
        const avail = resolvePotContainers(plantContainerSizes, potSizes, next.plantId);
        if (!avail.includes(next.container)) next.container = avail[0] || potSizes[0];
      }
      if (next.kind === "plant" && (patch.plantId !== void 0 || patch.container !== void 0)) {
        const cn = cennik[next.plantId]?.[next.container];
        next.cena = cn !== void 0 ? cn : 0;
      }
      if (next.kind === "zestaw" && patch.zestawId !== void 0) {
        const z = zestawy.find((zz) => zz.id === next.zestawId);
        next.cena = z ? z.cena : 0;
      }
      return next;
    }));
  }
  function addPlantItem() {
    setItems((prev) => [...prev, makePlantItemLocal()]);
  }
  function addZestawItem() {
    const zi = makeZestawItemLocal();
    if (!zi) return;
    setItems((prev) => [...prev, zi]);
  }
  function removeItem(idx) {
    setItems((prev) => prev.filter((_, i) => i !== idx));
  }
  const orderSum = (items || []).reduce((s, it) => s + Number(it.ilosc || 0) * Number(it.cena || 0), 0);
  const hasUnpricedPlant = (items || []).some((it) => it.kind === "plant" && !cennik[it.plantId]?.[it.container] && it.cena === 0);
  function labelFor(it) {
    if (it.kind === "plant") {
      const p = plants.find((pp) => pp.id === it.plantId);
      return p ? `${p.nazwa_pl} (${p.odmiana}) \xB7 ${it.container}` : "Ro\u015Blina";
    }
    const z = zestawy.find((zz) => zz.id === it.zestawId);
    return z ? `Zestaw: ${z.nazwa}` : "Zestaw";
  }
  function saveOrder() {
    if (!klient.trim() || !items || items.length === 0) return;
    const matched = clients.find((c) => c.nazwa.trim().toLowerCase() === klient.trim().toLowerCase());
    const pozycje = items.map((it) => ({ ...it, nazwa: labelFor(it) }));
    const order = {
      id: uid2("o"),
      klient: klient.trim(),
      klientId: matched ? matched.id : null,
      data: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
      status: "nowe",
      pozycje,
      suma: orderSum
    };
    onCreateOrder(order);
    resetForm();
  }
  function handleFulfill(order, deduct) {
    onFulfillOrder(order, deduct);
    setFulfillingId(null);
  }
  function handleDelete(id) {
    onDeleteOrder(id);
    setConfirmingId(null);
  }
  return /* @__PURE__ */ React.createElement("div", null, !formOpen ? /* @__PURE__ */ React.createElement("button", { className: "primary-btn", style: { marginTop: 12 }, onClick: openForm }, /* @__PURE__ */ React.createElement(Plus8, { size: 17 }), " Nowe zam\xF3wienie") : /* @__PURE__ */ React.createElement("div", { className: "order-form" }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Klient"), /* @__PURE__ */ React.createElement("input", { list: "clients-dl", value: klient, onChange: (e) => setKlient(e.target.value), placeholder: "Imi\u0119, nazwa firmy\u2026" }), /* @__PURE__ */ React.createElement("datalist", { id: "clients-dl" }, clients.map((c) => /* @__PURE__ */ React.createElement("option", { key: c.id, value: c.nazwa })))), /* @__PURE__ */ React.createElement("div", { className: "section-title small-title" }, "Podgl\u0105d zam\xF3wienia"), items.map((it, idx) => /* @__PURE__ */ React.createElement("div", { key: idx, className: "order-item-row" }, it.kind === "plant" ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("select", { value: it.plantId, onChange: (e) => updateItem(idx, { plantId: e.target.value }) }, plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana))), /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement("select", { value: it.container, onChange: (e) => updateItem(idx, { container: e.target.value }) }, potSizes.map((c) => /* @__PURE__ */ React.createElement("option", { key: c, value: c }, c))), /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "numeric", min: "1", value: it.ilosc, onChange: (e) => updateItem(idx, { ilosc: clampInt(e.target.value, 1) }) }), /* @__PURE__ */ React.createElement("div", { className: "price-input-wrap small" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", value: it.cena, onChange: (e) => updateItem(idx, { cena: Math.max(0, Number(e.target.value) || 0) }) }), /* @__PURE__ */ React.createElement("span", { className: "pln" }, "z\u0142")), items.length > 1 && /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => removeItem(idx) }, /* @__PURE__ */ React.createElement(Trash210, { size: 15 }))), !cennik[it.plantId]?.[it.container] && /* @__PURE__ */ React.createElement("div", { className: "price-warning" }, /* @__PURE__ */ React.createElement(AlertCircle, { size: 12 }), " Brak ceny w cenniku \u2014 wpisz r\u0119cznie")) : /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("select", { value: it.zestawId, onChange: (e) => updateItem(idx, { zestawId: e.target.value }) }, zestawy.map((z) => /* @__PURE__ */ React.createElement("option", { key: z.id, value: z.id }, "Zestaw: ", z.nazwa))), /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0.1", step: "0.1", value: it.ilosc, onChange: (e) => updateItem(idx, { ilosc: clampModuleQty(e.target.value) }) }), /* @__PURE__ */ React.createElement("div", { className: "price-input-wrap small" }, /* @__PURE__ */ React.createElement("input", { type: "number", inputMode: "decimal", min: "0", value: it.cena, onChange: (e) => updateItem(idx, { cena: Math.max(0, Number(e.target.value) || 0) }) }), /* @__PURE__ */ React.createElement("span", { className: "pln" }, "z\u0142")), items.length > 1 && /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => removeItem(idx) }, /* @__PURE__ */ React.createElement(Trash210, { size: 15 }))), (() => {
    const z = zestawy.find((zz) => zz.id === it.zestawId);
    return z?.dlugosc_mb ? /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { margin: "2px 0 0" } }, "= ", (Number(it.ilosc || 0) * z.dlugosc_mb).toFixed(1), " mb") : null;
  })()), /* @__PURE__ */ React.createElement("div", { className: "order-item-subtotal" }, "= ", money(Number(it.ilosc || 0) * Number(it.cena || 0)), " z\u0142"))), /* @__PURE__ */ React.createElement("div", { className: "form-actions", style: { marginTop: 0 } }, /* @__PURE__ */ React.createElement("button", { className: "ghost-btn", onClick: addPlantItem }, /* @__PURE__ */ React.createElement(Plus8, { size: 15 }), " Ro\u015Blina"), zestawy.length > 0 && /* @__PURE__ */ React.createElement("button", { className: "ghost-btn", onClick: addZestawItem }, /* @__PURE__ */ React.createElement(Boxes2, { size: 15 }), " Zestaw")), hasUnpricedPlant && /* @__PURE__ */ React.createElement("div", { className: "price-warning" }, /* @__PURE__ */ React.createElement(AlertCircle, { size: 12 }), " Niekt\xF3re pozycje maj\u0105 cen\u0119 0 z\u0142 \u2014 sprawd\u017A przed zapisem."), /* @__PURE__ */ React.createElement("div", { className: "order-total" }, "Razem: ", /* @__PURE__ */ React.createElement("strong", null, money(orderSum), " z\u0142")), /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: resetForm }, "Anuluj"), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", disabled: !klient.trim(), onClick: saveOrder }, "Zapisz zam\xF3wienie"))), /* @__PURE__ */ React.createElement("div", { className: "order-list" }, orders.length === 0 && !formOpen && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak zam\xF3wie\u0144. Dodaj pierwsze powy\u017Cej."), orders.map((o) => {
    const isOpen = expandedId === o.id;
    return /* @__PURE__ */ React.createElement("div", { key: o.id, className: "order-card" }, /* @__PURE__ */ React.createElement("button", { className: "order-card-head", onClick: () => setExpandedId(isOpen ? null : o.id) }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, o.klient), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, o.data, " \xB7 ", o.pozycje.length, " poz.")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement("span", { className: "order-sum" }, money(o.suma), " z\u0142"), /* @__PURE__ */ React.createElement("span", { className: `status-badge ${o.status === "zrealizowane" ? "ok" : "new"}` }, o.status === "zrealizowane" ? "Zrealizowane" : "Nowe"))), isOpen && /* @__PURE__ */ React.createElement("div", { className: "order-card-body" }, o.pozycje.map((it, i) => {
      const z = it.kind === "zestaw" ? zestawy.find((zz) => zz.id === it.zestawId) : null;
      return /* @__PURE__ */ React.createElement("div", { key: i, className: "order-line" }, /* @__PURE__ */ React.createElement("span", null, it.nazwa || labelFor(it), " \xD7 ", it.ilosc, z?.dlugosc_mb ? ` (${(Number(it.ilosc || 0) * z.dlugosc_mb).toFixed(1)} mb)` : ""), /* @__PURE__ */ React.createElement("span", null, money(it.ilosc * it.cena), " z\u0142"));
    }), /* @__PURE__ */ React.createElement("div", { className: "order-card-actions" }, o.status !== "zrealizowane" && (() => {
      const pickItems = buildPickingList(o, zestawy, batchSegments);
      return pickItems.length > 0 && /* @__PURE__ */ React.createElement("div", { style: { width: "100%" } }, /* @__PURE__ */ React.createElement("div", { className: "section-title small-title", style: { marginTop: 0 } }, "Lista do zbi\xF3rki"), pickItems.map((p, i) => /* @__PURE__ */ React.createElement("div", { key: i, className: "hint-text", style: { marginBottom: 2 } }, p.location ? `${p.ilosc} szt. ${plantName(plants, p.plantId)}, ${containerLabel(p.container)} \u2014 ${p.location} (partia ${batchLabel((batches || []).find((b) => b.id === p.batchId))})` : `${p.ilosc} szt. ${plantName(plants, p.plantId)}, ${containerLabel(p.container)} \u2014 lokalizacja nieznana (towar bez \u015Bledzonej partii)`)));
    })(), o.status !== "zrealizowane" && fulfillingId !== o.id && /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: () => setFulfillingId(o.id) }, "Oznacz jako zrealizowane"), fulfillingId === o.id && /* @__PURE__ */ React.createElement("div", { className: "confirm-box" }, /* @__PURE__ */ React.createElement("span", null, "Odj\u0105\u0107 te ilo\u015Bci z magazynu?"), /* @__PURE__ */ React.createElement("div", { className: "confirm-actions" }, /* @__PURE__ */ React.createElement("button", { className: "primary-btn small", onClick: () => handleFulfill(o, true) }, "Tak, odejmij"), /* @__PURE__ */ React.createElement("button", { className: "secondary-btn small", onClick: () => handleFulfill(o, false) }, "Nie, tylko oznacz"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => setFulfillingId(null) }, "Anuluj"))), confirmingId !== o.id ? /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => setConfirmingId(o.id) }, /* @__PURE__ */ React.createElement(Trash210, { size: 15 })) : /* @__PURE__ */ React.createElement("div", { className: "confirm-box" }, /* @__PURE__ */ React.createElement("span", null, "Usun\u0105\u0107 zam\xF3wienie?"), /* @__PURE__ */ React.createElement("div", { className: "confirm-actions" }, /* @__PURE__ */ React.createElement("button", { className: "danger-btn small", onClick: () => handleDelete(o.id) }, "Usu\u0144"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => setConfirmingId(null) }, "Anuluj"))))));
  })));
}

// src/components/sprzedaz/KlienciPanel.jsx
import { useState as useState24 } from "react";
import { Plus as Plus9, Trash2 as Trash211 } from "lucide-react";
function emptyClientForm() {
  return { nazwa: "", telefon: "", notatki: "" };
}
function KlienciPanel({ clients, orders, onAdd, onDelete }) {
  const [formOpen, setFormOpen] = useState24(false);
  const [form, setForm] = useState24(emptyClientForm());
  const [expandedId, setExpandedId] = useState24(null);
  const [confirmingId, setConfirmingId] = useState24(null);
  function submit() {
    if (!form.nazwa.trim()) return;
    onAdd(form);
    setForm(emptyClientForm());
    setFormOpen(false);
  }
  function ordersFor(client) {
    return orders.filter((o) => o.klientId === client.id || (o.klient || "").trim().toLowerCase() === client.nazwa.trim().toLowerCase());
  }
  return /* @__PURE__ */ React.createElement("div", null, !formOpen ? /* @__PURE__ */ React.createElement("button", { className: "primary-btn", style: { marginTop: 12 }, onClick: () => setFormOpen(true) }, /* @__PURE__ */ React.createElement(Plus9, { size: 17 }), " Nowy klient") : /* @__PURE__ */ React.createElement("div", { className: "order-form" }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Imi\u0119 / nazwa"), /* @__PURE__ */ React.createElement("input", { value: form.nazwa, onChange: (e) => setForm((f) => ({ ...f, nazwa: e.target.value })), placeholder: "Jan Kowalski" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Telefon (opcjonalnie)"), /* @__PURE__ */ React.createElement("input", { value: form.telefon, onChange: (e) => setForm((f) => ({ ...f, telefon: e.target.value })), placeholder: "600 000 000" })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Notatki (opcjonalnie)"), /* @__PURE__ */ React.createElement("input", { value: form.notatki, onChange: (e) => setForm((f) => ({ ...f, notatki: e.target.value })), placeholder: "np. sta\u0142y klient, hurt" })), /* @__PURE__ */ React.createElement("div", { className: "form-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: () => {
    setFormOpen(false);
    setForm(emptyClientForm());
  } }, "Anuluj"), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", disabled: !form.nazwa.trim(), onClick: submit }, "Zapisz"))), /* @__PURE__ */ React.createElement("div", { className: "order-list" }, clients.length === 0 && !formOpen && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak klient\xF3w. Dodaj pierwszego powy\u017Cej."), clients.map((c) => {
    const co = ordersFor(c);
    const total = co.reduce((s, o) => s + Number(o.suma || 0), 0);
    const isOpen = expandedId === c.id;
    return /* @__PURE__ */ React.createElement("div", { key: c.id, className: "order-card" }, /* @__PURE__ */ React.createElement("button", { className: "order-card-head", onClick: () => setExpandedId(isOpen ? null : c.id) }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, c.nazwa), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, c.telefon || "brak telefonu", " \xB7 ", co.length, " zam\xF3wie\u0144")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement("span", { className: "order-sum" }, money(total), " z\u0142"))), isOpen && /* @__PURE__ */ React.createElement("div", { className: "order-card-body" }, c.notatki && /* @__PURE__ */ React.createElement("div", { className: "order-line" }, /* @__PURE__ */ React.createElement("span", null, c.notatki)), co.length === 0 ? /* @__PURE__ */ React.createElement("div", { className: "empty-state", style: { padding: "8px 0" } }, "Brak zam\xF3wie\u0144 tego klienta.") : co.map((o) => /* @__PURE__ */ React.createElement("div", { key: o.id, className: "order-line" }, /* @__PURE__ */ React.createElement("span", null, o.data), /* @__PURE__ */ React.createElement("span", null, money(o.suma), " z\u0142"))), /* @__PURE__ */ React.createElement("div", { className: "order-card-actions" }, confirmingId !== c.id ? /* @__PURE__ */ React.createElement("button", { className: "icon-btn danger", onClick: () => setConfirmingId(c.id) }, /* @__PURE__ */ React.createElement(Trash211, { size: 15 })) : /* @__PURE__ */ React.createElement("div", { className: "confirm-box" }, /* @__PURE__ */ React.createElement("span", null, "Usun\u0105\u0107 klienta?"), /* @__PURE__ */ React.createElement("div", { className: "confirm-actions" }, /* @__PURE__ */ React.createElement("button", { className: "danger-btn small", onClick: () => {
      onDelete(c.id);
      setConfirmingId(null);
    } }, "Usu\u0144"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn small", onClick: () => setConfirmingId(null) }, "Anuluj"))))));
  })));
}

// src/components/sprzedaz/RaportyPanel.jsx
import { useState as useState25, useMemo as useMemo5 } from "react";
import { ChevronDown as ChevronDown6, ChevronRight as ChevronRight8, ChevronLeft as ChevronLeft3, TrendingUp, TrendingDown } from "lucide-react";
function RaportyPanel({ orders, zestawy, costs, overheadCosts, plants, batchSegments }) {
  const yearsInData = useMemo5(() => {
    const ys = /* @__PURE__ */ new Set([(/* @__PURE__ */ new Date()).getFullYear()]);
    orders.forEach((o) => {
      const y = Number((o.data || "").split("-")[0]);
      if (y) ys.add(y);
    });
    return Array.from(ys).sort((a, b) => b - a);
  }, [orders]);
  const [year, setYear] = useState25(yearsInData[0]);
  const [expandedMonth, setExpandedMonth] = useState25(null);
  const { monthly, totals } = useMemo5(
    () => computeYearlyProfitReport(orders, zestawy, costs, overheadCosts, year, batchSegments),
    [orders, zestawy, costs, overheadCosts, year, batchSegments]
  );
  const topVarieties = useMemo5(() => computeTopVarietiesByProfit(orders, zestawy, costs, year, 5, batchSegments), [orders, zestawy, costs, year, batchSegments]);
  const pending = useMemo5(
    () => orders.filter((o) => o.status !== "zrealizowane"),
    [orders]
  );
  const pendingSum = pending.reduce((s, o) => s + Number(o.suma || 0), 0);
  function plantLabel(plantId, container) {
    const p = plants.find((pp) => pp.id === plantId);
    return p ? `${p.nazwa_pl} (${p.odmiana}) \xB7 ${container}` : `${plantId} \xB7 ${container}`;
  }
  const yearIdx = yearsInData.indexOf(year);
  const canPrev = yearIdx < yearsInData.length - 1;
  const canNext = yearIdx > 0;
  return /* @__PURE__ */ React.createElement("div", { style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("div", { className: "year-switcher" }, /* @__PURE__ */ React.createElement("button", { className: "icon-btn", disabled: !canPrev, onClick: () => setYear(yearsInData[yearIdx + 1]) }, /* @__PURE__ */ React.createElement(ChevronLeft3, { size: 18 })), /* @__PURE__ */ React.createElement("span", { className: "year-label" }, year), /* @__PURE__ */ React.createElement("button", { className: "icon-btn", disabled: !canNext, onClick: () => setYear(yearsInData[yearIdx - 1]) }, /* @__PURE__ */ React.createElement(ChevronRight8, { size: 18 }))), /* @__PURE__ */ React.createElement("div", { className: "stat-row", style: { marginBottom: 8 } }, /* @__PURE__ */ React.createElement("div", { className: "stat-box" }, /* @__PURE__ */ React.createElement("span", { className: "stat-label" }, "Przych\xF3d (rok)"), /* @__PURE__ */ React.createElement("span", { className: "stat-value" }, money(totals.revenue), " z\u0142")), /* @__PURE__ */ React.createElement("div", { className: "stat-box" }, /* @__PURE__ */ React.createElement("span", { className: "stat-label" }, "Koszt sprzedanych"), /* @__PURE__ */ React.createElement("span", { className: "stat-value" }, money(totals.cogs), " z\u0142"))), /* @__PURE__ */ React.createElement("div", { className: "stat-row", style: { marginBottom: 8 } }, /* @__PURE__ */ React.createElement("div", { className: "stat-box" }, /* @__PURE__ */ React.createElement("span", { className: "stat-label" }, "Koszty sta\u0142e (rok)"), /* @__PURE__ */ React.createElement("span", { className: "stat-value" }, money(totals.overhead), " z\u0142")), /* @__PURE__ */ React.createElement("div", { className: `stat-box ${totals.netProfit < 0 ? "stat-neg" : "stat-pos"}` }, /* @__PURE__ */ React.createElement("span", { className: "stat-label" }, "Zysk netto (rok)"), /* @__PURE__ */ React.createElement("span", { className: "stat-value" }, totals.netProfit < 0 ? /* @__PURE__ */ React.createElement(TrendingDown, { size: 15 }) : /* @__PURE__ */ React.createElement(TrendingUp, { size: 15 }), " ", money(totals.netProfit), " z\u0142"))), pending.length > 0 && /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "W realizacji: ", pending.length, " ", pending.length === 1 ? "zam\xF3wienie" : "zam\xF3wie\u0144", " na ", money(pendingSum), " z\u0142 \u2014 nieuj\u0119te jeszcze w zysku, dop\xF3ki nie oznaczysz ich jako zrealizowane."), /* @__PURE__ */ React.createElement("div", { className: "section-title", style: { marginTop: 14 } }, "Miesi\u0105c po miesi\u0105cu"), /* @__PURE__ */ React.createElement("div", { className: "order-list" }, monthly.map((row) => {
    const isOpen = expandedMonth === row.month;
    const hasActivity = row.revenue > 0 || row.cogs > 0 || row.overhead > 0;
    return /* @__PURE__ */ React.createElement("div", { key: row.month, className: "order-card" }, /* @__PURE__ */ React.createElement("button", { className: "order-card-head", onClick: () => setExpandedMonth(isOpen ? null : row.month) }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "order-client" }, MONTHS[row.month]), /* @__PURE__ */ React.createElement("div", { className: "order-date" }, row.ordersCount, " ", row.ordersCount === 1 ? "zam\xF3wienie" : "zam\xF3wie\u0144", !hasActivity ? " \xB7 brak ruchu" : "")), /* @__PURE__ */ React.createElement("div", { className: "order-card-right" }, /* @__PURE__ */ React.createElement("span", { className: `order-sum ${row.netProfit < 0 ? "neg" : ""}` }, money(row.netProfit), " z\u0142"), isOpen ? /* @__PURE__ */ React.createElement(ChevronDown6, { size: 16 }) : /* @__PURE__ */ React.createElement(ChevronRight8, { size: 16 }))), isOpen && /* @__PURE__ */ React.createElement("div", { className: "order-card-body" }, /* @__PURE__ */ React.createElement("div", { className: "order-line" }, /* @__PURE__ */ React.createElement("span", null, "Przych\xF3d"), /* @__PURE__ */ React.createElement("span", null, money(row.revenue), " z\u0142")), /* @__PURE__ */ React.createElement("div", { className: "order-line" }, /* @__PURE__ */ React.createElement("span", null, "Koszt sprzedanych"), /* @__PURE__ */ React.createElement("span", null, "\u2212", money(row.cogs), " z\u0142")), /* @__PURE__ */ React.createElement("div", { className: "order-line" }, /* @__PURE__ */ React.createElement("span", null, "Zysk brutto"), /* @__PURE__ */ React.createElement("span", null, money(row.grossProfit), " z\u0142")), /* @__PURE__ */ React.createElement("div", { className: "order-line" }, /* @__PURE__ */ React.createElement("span", null, "Koszty sta\u0142e"), /* @__PURE__ */ React.createElement("span", null, "\u2212", money(row.overhead), " z\u0142")), /* @__PURE__ */ React.createElement("div", { className: "order-line report-total" }, /* @__PURE__ */ React.createElement("span", null, "Zysk netto"), /* @__PURE__ */ React.createElement("span", null, money(row.netProfit), " z\u0142"))));
  })), topVarieties.length > 0 && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "section-title", style: { marginTop: 14 } }, "Najbardziej zyskowne odmiany w ", year), /* @__PURE__ */ React.createElement("div", { className: "plant-list" }, topVarieties.map((v, i) => /* @__PURE__ */ React.createElement("div", { key: `${v.plantId}-${v.container}-${i}`, className: "supply-card" }, /* @__PURE__ */ React.createElement("div", { className: "supply-card-main" }, /* @__PURE__ */ React.createElement("div", { className: "plant-name" }, i + 1, ". ", plantLabel(v.plantId, v.container)), /* @__PURE__ */ React.createElement("div", { className: "supply-meta" }, v.ilosc, " szt. sprzedanych \xB7 zysk ", money(v.profit), " z\u0142", v.fromZestaw ? " (cz\u0119\u015Bciowo z zestaw\xF3w)" : "")))))), /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 10 } }, "Koszt sprzedanych liczony jest wg aktualnego koszt/szt. z Cennika w momencie generowania raportu \u2014 je\u015Bli zmieniasz koszty wstecz, przesz\u0142e miesi\u0105ce te\u017C si\u0119 przelicz\u0105."));
}

// src/components/sprzedaz/SprzedazTab.jsx
function SprzedazTab({ plants, potSizes, plantContainerSizes, cennik, setCennik, costs, onSetCost, orders, onCreateOrder, onDeleteOrder, onFulfillOrder, zestawy, setZestawy, clients, onAddClient, onDeleteClient, overheadCosts, batchSegments, batches }) {
  const [sub, setSub] = useState26("cennik");
  return /* @__PURE__ */ React.createElement("div", { className: "tab-pad" }, /* @__PURE__ */ React.createElement("div", { className: "segmented scrollable" }, /* @__PURE__ */ React.createElement("button", { className: sub === "cennik" ? "active" : "", onClick: () => setSub("cennik") }, "Cennik"), /* @__PURE__ */ React.createElement("button", { className: sub === "zestawy" ? "active" : "", onClick: () => setSub("zestawy") }, "Zestawy", zestawy.length ? ` (${zestawy.length})` : ""), /* @__PURE__ */ React.createElement("button", { className: sub === "zamowienia" ? "active" : "", onClick: () => setSub("zamowienia") }, "Zam\xF3wienia", orders.length ? ` (${orders.length})` : ""), /* @__PURE__ */ React.createElement("button", { className: sub === "klienci" ? "active" : "", onClick: () => setSub("klienci") }, "Klienci", clients.length ? ` (${clients.length})` : ""), /* @__PURE__ */ React.createElement("button", { className: sub === "raporty" ? "active" : "", onClick: () => setSub("raporty") }, "Raporty")), sub === "cennik" && /* @__PURE__ */ React.createElement(CennikPanel, { plants, potSizes, plantContainerSizes, cennik, setCennik, costs, onSetCost }), sub === "zestawy" && /* @__PURE__ */ React.createElement(ZestawyPanel, { plants, potSizes, plantContainerSizes, zestawy, setZestawy, cennik }), sub === "zamowienia" && /* @__PURE__ */ React.createElement(
    ZamowieniaPanel,
    {
      plants,
      potSizes,
      plantContainerSizes,
      cennik,
      orders,
      onCreateOrder,
      onDeleteOrder,
      onFulfillOrder,
      zestawy,
      clients,
      batches,
      batchSegments
    }
  ), sub === "klienci" && /* @__PURE__ */ React.createElement(KlienciPanel, { clients, orders, onAdd: onAddClient, onDelete: onDeleteClient }), sub === "raporty" && /* @__PURE__ */ React.createElement(RaportyPanel, { orders, zestawy, costs, overheadCosts, plants, batchSegments }));
}

// src/components/etykiety/EtykietyTab.jsx
import { useState as useState27 } from "react";
import { Minus as Minus2, Plus as Plus10, Printer } from "lucide-react";
function filterActiveSegments(batchSegments, filterPlantId) {
  return (batchSegments || []).filter((s) => s.status === "aktywny" && Number(s.ilosc || 0) > 0).filter((s) => !filterPlantId || s.plantId === filterPlantId);
}
function buildLabelList(plants, counts) {
  const labelPlants = [];
  plants.forEach((p) => {
    const n = counts[p.id] || 0;
    for (let i = 0; i < n; i++) labelPlants.push(p);
  });
  return labelPlants;
}
function buildSegmentLabelList(activeSegments, segmentCounts) {
  const labelSegments = [];
  activeSegments.forEach((s) => {
    const n = segmentCounts[s.id] || 0;
    for (let i = 0; i < n; i++) labelSegments.push(s);
  });
  return labelSegments;
}
function buildPassportFields(plant, batch, piorinNumber, originCountry) {
  return {
    A: plant ? plant.odmiana : "",
    B: piorinNumber || "",
    C: batch ? batch.numer ? `#${batch.numer}` : batch.id : "",
    D: originCountry || ""
  };
}
function EtykietyTab({ plants, inventory, potSizes, batchSegments, batches, piorinNumber, setPiorinNumber, originCountry, setOriginCountry, thermalLabelSize, setThermalLabelSize }) {
  const [mode, setMode] = useState27("odmiana");
  const [printMode, setPrintMode] = useState27("a4");
  const [passportMode, setPassportMode] = useState27(false);
  const [counts, setCounts] = useState27({});
  function setCount(plantId, val) {
    setCounts((prev) => ({ ...prev, [plantId]: clampInt(val, 0) }));
  }
  function bump(plantId, delta) {
    setCount(plantId, (counts[plantId] || 0) + delta);
  }
  function fillFromStock() {
    const next = {};
    plants.forEach((p) => {
      const row = inventory[p.id] || {};
      next[p.id] = potSizes.reduce((s, c) => s + Number(row[c] || 0), 0);
    });
    setCounts(next);
  }
  function clearAll() {
    setCounts({});
  }
  const labelPlants = buildLabelList(plants, counts);
  const [filterPlantId, setFilterPlantId] = useState27("");
  const [segmentCounts, setSegmentCounts] = useState27({});
  const activeSegments = filterActiveSegments(batchSegments, filterPlantId);
  function setSegmentCount(segmentId, val, max) {
    setSegmentCounts((prev) => ({ ...prev, [segmentId]: Math.max(0, Math.min(clampInt(val, 0), max)) }));
  }
  function bumpSegment(segmentId, delta, max) {
    setSegmentCount(segmentId, (segmentCounts[segmentId] || 0) + delta, max);
  }
  function fillSegmentsFromStock() {
    const next = {};
    activeSegments.forEach((s) => {
      next[s.id] = Number(s.ilosc || 0);
    });
    setSegmentCounts(next);
  }
  function clearSegments() {
    setSegmentCounts({});
  }
  const labelSegments = buildSegmentLabelList(activeSegments, segmentCounts);
  const totalLabels = mode === "odmiana" ? labelPlants.length : labelSegments.length;
  function handlePrint() {
    window.print();
  }
  const previewPlant = plants[0];
  const w = Number(thermalLabelSize?.width || 40);
  const h = Number(thermalLabelSize?.height || 30);
  return /* @__PURE__ */ React.createElement("div", { className: "tab-pad" }, /* @__PURE__ */ React.createElement("div", { className: "segmented" }, /* @__PURE__ */ React.createElement("button", { className: mode === "odmiana" ? "active" : "", onClick: () => setMode("odmiana") }, "Wg odmiany"), /* @__PURE__ */ React.createElement("button", { className: mode === "partia" ? "active" : "", onClick: () => setMode("partia") }, "Wg partii")), /* @__PURE__ */ React.createElement("div", { className: "segmented", style: { marginTop: 8 } }, /* @__PURE__ */ React.createElement("button", { className: printMode === "a4" ? "active" : "", onClick: () => setPrintMode("a4") }, "Arkusz A4"), /* @__PURE__ */ React.createElement("button", { className: printMode === "thermal" ? "active" : "", onClick: () => setPrintMode("thermal") }, "Drukarka termiczna")), printMode === "thermal" && /* @__PURE__ */ React.createElement("div", { className: "order-form", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Rozmiar etykiety (mm)"), /* @__PURE__ */ React.createElement("div", { className: "order-item-sub" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      inputMode: "numeric",
      min: "10",
      value: thermalLabelSize?.width || 40,
      onChange: (e) => setThermalLabelSize({ ...thermalLabelSize, width: clampInt(e.target.value, 10) }),
      style: { maxWidth: 80 }
    }
  ), /* @__PURE__ */ React.createElement("span", { style: { fontSize: 12 } }, "\xD7"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      inputMode: "numeric",
      min: "10",
      value: thermalLabelSize?.height || 30,
      onChange: (e) => setThermalLabelSize({ ...thermalLabelSize, height: clampInt(e.target.value, 10) }),
      style: { maxWidth: 80 }
    }
  ), /* @__PURE__ */ React.createElement("span", { style: { fontSize: 12, color: "var(--ink-muted)" } }, "mm \u2014 dopasuj do rolki w Twojej drukarce"))), /* @__PURE__ */ React.createElement("p", { className: "hint-text" }, "Sprawd\u017A pierwszy wydruk na pr\xF3bnej etykiece \u2014 kalibracja zale\u017Cy od konkretnej drukarki/sterownika.")), mode === "partia" && /* @__PURE__ */ React.createElement("div", { className: "order-form", style: { marginTop: 8 } }, /* @__PURE__ */ React.createElement("label", { className: "checkbox-field" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: passportMode, onChange: (e) => setPassportMode(e.target.checked) }), /* @__PURE__ */ React.createElement("span", null, "Do\u0142\u0105cz jako Paszport ro\u015Blin (UE) \u2014 pola A/B/C/D wg Rozporz\u0105dzenia 2016/2031")), passportMode && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Numer rejestracyjny PIORiN (pole B)"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "np. PL-12/345/6789", value: piorinNumber, onChange: (e) => setPiorinNumber(e.target.value) })), /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Kraj pochodzenia (pole D)"), /* @__PURE__ */ React.createElement("input", { type: "text", placeholder: "PL", value: originCountry, onChange: (e) => setOriginCountry(e.target.value.toUpperCase()), style: { maxWidth: 100 } })), !piorinNumber && /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { color: "var(--danger, #c0392b)" } }, "Podaj numer PIORiN \u2014 bez niego pole B na paszporcie zostanie puste."))), mode === "odmiana" && previewPlant && /* @__PURE__ */ React.createElement("div", { className: "label-preview-section" }, /* @__PURE__ */ React.createElement("div", { className: "section-title small-title", style: { marginBottom: 6 } }, "Wz\xF3r etykiety (podgl\u0105d)"), /* @__PURE__ */ React.createElement("div", { className: "label-preview-card" }, /* @__PURE__ */ React.createElement("div", { className: "lp-name" }, previewPlant.nazwa_pl), /* @__PURE__ */ React.createElement("div", { className: "lp-variety" }, previewPlant.odmiana), /* @__PURE__ */ React.createElement("div", { className: "lp-row" }, /* @__PURE__ */ React.createElement("strong", null, "Wys./Szer.:"), " ", previewPlant.wys_szer, " cm"), /* @__PURE__ */ React.createElement("div", { className: "lp-row" }, /* @__PURE__ */ React.createElement("strong", null, "Stanowisko:"), " ", previewPlant.stanowisko), /* @__PURE__ */ React.createElement("div", { className: "lp-row" }, /* @__PURE__ */ React.createElement("strong", null, "Kwitnienie:"), " ", previewPlant.kwitnienie), /* @__PURE__ */ React.createElement("div", { className: "lp-row" }, /* @__PURE__ */ React.createElement("strong", null, "Zimozielona:"), " ", previewPlant.zimozielona)), /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 6 } }, "Tak wygl\u0105da jedna etykieta \u2014 ka\u017Cda odmiana dostanie swoj\u0105 z takimi danymi. Ustaw poni\u017Cej ile sztuk ka\u017Cdej potrzebujesz i drukuj.")), mode === "odmiana" && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "etykiety-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: fillFromStock }, "Uzupe\u0142nij z magazynu"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn", onClick: clearAll }, "Wyczy\u015B\u0107")), /* @__PURE__ */ React.createElement("div", { className: "plant-list" }, plants.map((p) => /* @__PURE__ */ React.createElement("div", { key: p.id, className: "label-count-card" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "plant-name" }, p.nazwa_pl), /* @__PURE__ */ React.createElement("div", { className: "plant-variety" }, p.odmiana)), /* @__PURE__ */ React.createElement("div", { className: "stepper" }, /* @__PURE__ */ React.createElement("button", { className: "stepper-btn", onClick: () => bump(p.id, -1) }, /* @__PURE__ */ React.createElement(Minus2, { size: 15 })), /* @__PURE__ */ React.createElement("input", { className: "stepper-input", type: "number", min: "0", inputMode: "numeric", value: counts[p.id] || 0, onChange: (e) => setCount(p.id, e.target.value) }), /* @__PURE__ */ React.createElement("button", { className: "stepper-btn", onClick: () => bump(p.id, 1) }, /* @__PURE__ */ React.createElement(Plus10, { size: 15 }))))))), mode === "partia" && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("p", { className: "hint-text", style: { marginTop: 10 } }, "Etykieta dla konkretnego segmentu partii \u2014 dodatkowo poka\u017Ce pojemnik, lokalizacj\u0119 i numer partii, \u017Ceby da\u0142o si\u0119 p\xF3\u017Aniej jednoznacznie powi\u0105za\u0107 ro\u015Blin\u0119 z Partiami."), /* @__PURE__ */ React.createElement("div", { className: "order-form", style: { marginTop: 4 } }, /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, "Odmiana"), /* @__PURE__ */ React.createElement("select", { value: filterPlantId, onChange: (e) => setFilterPlantId(e.target.value) }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 wszystkie \u2014"), plants.map((p) => /* @__PURE__ */ React.createElement("option", { key: p.id, value: p.id }, p.nazwa_pl, " \u2014 ", p.odmiana))))), /* @__PURE__ */ React.createElement("div", { className: "etykiety-actions" }, /* @__PURE__ */ React.createElement("button", { className: "secondary-btn", onClick: fillSegmentsFromStock }, "Uzupe\u0142nij ilo\u015Bci\u0105 segmentu"), /* @__PURE__ */ React.createElement("button", { className: "ghost-btn", onClick: clearSegments }, "Wyczy\u015B\u0107")), /* @__PURE__ */ React.createElement("div", { className: "plant-list" }, activeSegments.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "empty-state" }, "Brak aktywnych segment\xF3w partii", filterPlantId ? " dla wybranej odmiany" : "", '. Etykiety wg partii wymagaj\u0105 \u015Bledzenia partii (Zakup/Podzia\u0142/Przesadzenie z opcj\u0105 \u201E\u015Aled\u017A jako parti\u0119").'), activeSegments.map((s) => /* @__PURE__ */ React.createElement("div", { key: s.id, className: "label-count-card" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "plant-name" }, plantName(plants, s.plantId)), /* @__PURE__ */ React.createElement("div", { className: "plant-variety" }, containerLabel(s.container), s.location ? ` \u2014 ${s.location}` : "", " \xB7 Partia ", batchLabel((batches || []).find((b) => b.id === s.batchId)), " \xB7 dost\u0119pne: ", s.ilosc)), /* @__PURE__ */ React.createElement("div", { className: "stepper" }, /* @__PURE__ */ React.createElement("button", { className: "stepper-btn", onClick: () => bumpSegment(s.id, -1, s.ilosc) }, /* @__PURE__ */ React.createElement(Minus2, { size: 15 })), /* @__PURE__ */ React.createElement("input", { className: "stepper-input", type: "number", min: "0", max: s.ilosc, inputMode: "numeric", value: segmentCounts[s.id] || 0, onChange: (e) => setSegmentCount(s.id, e.target.value, s.ilosc) }), /* @__PURE__ */ React.createElement("button", { className: "stepper-btn", onClick: () => bumpSegment(s.id, 1, s.ilosc) }, /* @__PURE__ */ React.createElement(Plus10, { size: 15 }))))))), /* @__PURE__ */ React.createElement("div", { className: "print-bar" }, /* @__PURE__ */ React.createElement("span", null, totalLabels, " etykiet do wydruku"), /* @__PURE__ */ React.createElement("button", { className: "primary-btn", disabled: totalLabels === 0, onClick: handlePrint }, /* @__PURE__ */ React.createElement(Printer, { size: 17 }), " Drukuj")), printMode === "thermal" && /* @__PURE__ */ React.createElement("style", null, `@page thermal { size: ${w}mm ${h}mm; margin: 0; }`), /* @__PURE__ */ React.createElement("div", { className: `print-area ${printMode === "thermal" ? "thermal" : ""}` }, /* @__PURE__ */ React.createElement("div", { className: "print-grid" }, mode === "odmiana" && labelPlants.map((p, i) => /* @__PURE__ */ React.createElement("div", { className: "print-label", key: i, style: printMode === "thermal" ? { width: `${w}mm`, height: `${h}mm` } : void 0 }, /* @__PURE__ */ React.createElement("div", { className: "pl-name" }, p.nazwa_pl), /* @__PURE__ */ React.createElement("div", { className: "pl-variety" }, p.odmiana), /* @__PURE__ */ React.createElement("div", { className: "pl-row" }, /* @__PURE__ */ React.createElement("strong", null, "Wys./Szer.:"), " ", p.wys_szer, " cm"), /* @__PURE__ */ React.createElement("div", { className: "pl-row" }, /* @__PURE__ */ React.createElement("strong", null, "Stanowisko:"), " ", p.stanowisko), /* @__PURE__ */ React.createElement("div", { className: "pl-row" }, /* @__PURE__ */ React.createElement("strong", null, "Kwitnienie:"), " ", p.kwitnienie), /* @__PURE__ */ React.createElement("div", { className: "pl-row" }, /* @__PURE__ */ React.createElement("strong", null, "Zimozielona:"), " ", p.zimozielona))), mode === "partia" && labelSegments.map((s, i) => {
    const p = plants.find((pp) => pp.id === s.plantId);
    const batch = (batches || []).find((b) => b.id === s.batchId);
    const style = printMode === "thermal" ? { width: `${w}mm`, height: `${h}mm` } : void 0;
    if (passportMode) {
      const f = buildPassportFields(p, batch, piorinNumber, originCountry);
      return /* @__PURE__ */ React.createElement("div", { className: "print-label", key: i, style }, /* @__PURE__ */ React.createElement("div", { className: "passport-header" }, /* @__PURE__ */ React.createElement("span", { className: "passport-flag" }, "UE"), /* @__PURE__ */ React.createElement("span", { className: "passport-title" }, "Paszport ro\u015Blin / Plant passport")), /* @__PURE__ */ React.createElement("div", { className: "passport-row" }, /* @__PURE__ */ React.createElement("span", { className: "passport-letter" }, "A"), f.A), /* @__PURE__ */ React.createElement("div", { className: "passport-row" }, /* @__PURE__ */ React.createElement("span", { className: "passport-letter" }, "B"), f.B), /* @__PURE__ */ React.createElement("div", { className: "passport-row" }, /* @__PURE__ */ React.createElement("span", { className: "passport-letter" }, "C"), f.C), /* @__PURE__ */ React.createElement("div", { className: "passport-row" }, /* @__PURE__ */ React.createElement("span", { className: "passport-letter" }, "D"), f.D));
    }
    return /* @__PURE__ */ React.createElement("div", { className: "print-label", key: i, style }, /* @__PURE__ */ React.createElement("div", { className: "pl-name" }, p ? p.nazwa_pl : s.plantId), /* @__PURE__ */ React.createElement("div", { className: "pl-variety" }, p ? p.odmiana : ""), p && /* @__PURE__ */ React.createElement("div", { className: "pl-row" }, /* @__PURE__ */ React.createElement("strong", null, "Wys./Szer.:"), " ", p.wys_szer, " cm"), p && /* @__PURE__ */ React.createElement("div", { className: "pl-row" }, /* @__PURE__ */ React.createElement("strong", null, "Stanowisko:"), " ", p.stanowisko), /* @__PURE__ */ React.createElement("div", { className: "pl-row" }, /* @__PURE__ */ React.createElement("strong", null, "Pojemnik:"), " ", containerLabel(s.container), s.location ? ` \u2014 ${s.location}` : ""), /* @__PURE__ */ React.createElement("div", { className: "pl-row" }, /* @__PURE__ */ React.createElement("strong", null, "Partia:"), " ", batchLabel(batch)));
  }))));
}

// src/styles/GlobalStyle.jsx
function GlobalStyle() {
  return /* @__PURE__ */ React.createElement("style", null, `
      @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap');

      :root {
        --bg: #D7DBDF; --surface: #FFFFFF; --surface-2: #F2F4F6;
        --ink: #23281D; --ink-muted: #6E7260; --line: #C7CDD3;
        --brand: #2C5282; --brand-dark: #1A365D;
        --gold: #B98A28; --gold-soft: #E4E9EF;
        --rust: #B5502B; --rust-soft: #F6DCCF;
        --green-soft: #D7E3F0;
      }
      * { box-sizing: border-box; }
      .app-shell { font-family: 'Inter', system-ui, sans-serif; background: var(--bg); color: var(--ink); min-height: 100vh; max-width: 480px; margin: 0 auto; display: flex; flex-direction: column; position: relative; }
      .app-header { position: sticky; top: 0; z-index: 10; background: var(--bg); padding: 14px 16px 0 16px; }
      .app-header-row { display: flex; align-items: center; justify-content: space-between; }
      .brand { display: flex; align-items: center; gap: 10px; }
      .brand-title { font-family: 'Fraunces', serif; font-weight: 700; font-size: 19px; line-height: 1.1; color: var(--brand-dark); }
      .brand-sub { font-size: 12px; color: var(--ink-muted); margin-top: 1px; }
      .header-totals { text-align: right; font-family: 'JetBrains Mono', monospace; }
      .header-totals span { display: block; font-size: 18px; font-weight: 600; color: var(--brand); }
      .header-totals small { font-size: 10px; color: var(--ink-muted); letter-spacing: 0.02em; }
      .grass-mark .blade { transform-origin: 15px 28px; animation: sway 3.4s ease-in-out infinite; }
      .grass-mark .b1 { animation-delay: 0s; } .grass-mark .b2 { animation-delay: 0.3s; } .grass-mark .b3 { animation-delay: 0.6s; }
      @keyframes sway { 0%, 100% { transform: rotate(-3deg); } 50% { transform: rotate(3deg); } }
      .grass-divider { display: flex; align-items: flex-end; height: 12px; margin-top: 10px; gap: 3px; overflow: hidden; }
      .gd-blade { width: 2px; border-radius: 2px 2px 0 0; background: var(--line); display: inline-block; transform-origin: bottom center; animation: sway-sm 2.6s ease-in-out infinite; }
      .gd-0 { height: 7px; background: var(--brand); opacity: 0.55; } .gd-1 { height: 11px; background: var(--gold); opacity: 0.5; } .gd-2 { height: 5px; background: var(--brand); opacity: 0.35; }
      @keyframes sway-sm { 0%, 100% { transform: rotate(-6deg); } 50% { transform: rotate(6deg); } }
      .app-content { flex: 1; padding-bottom: 84px; }
      .tab-pad { padding: 14px 16px 20px; }
      .loading { padding: 40px 16px; text-align: center; color: var(--ink-muted); }
      .totals-row { display: flex; gap: 8px; margin-bottom: 12px; }
      .totals-chip { flex: 1; background: var(--surface); border: 1px solid var(--line); border-radius: 12px; padding: 8px 6px; text-align: center; }
      .totals-num { display: block; font-family: 'JetBrains Mono', monospace; font-size: 17px; font-weight: 600; color: var(--brand); }
      .totals-label { font-size: 10px; color: var(--ink-muted); text-transform: uppercase; letter-spacing: 0.04em; }
      .search-bar { display: flex; align-items: center; gap: 8px; background: var(--surface); border: 1px solid var(--line); border-radius: 12px; padding: 9px 12px; margin-bottom: 12px; color: var(--ink-muted); }
      .search-bar input { border: none; outline: none; background: transparent; flex: 1; font-size: 14px; color: var(--ink); font-family: 'Inter', sans-serif; }
      .plant-list { display: flex; flex-direction: column; gap: 8px; }
      .plant-card { background: var(--surface); border: 1px solid var(--line); border-radius: 14px; overflow: hidden; }
      .plant-card-head { width: 100%; display: flex; align-items: center; gap: 10px; padding: 10px 13px; }
      .plant-card-head-btn { flex: 1; min-width: 0; display: flex; align-items: center; justify-content: space-between; gap: 8px; background: none; border: none; text-align: left; cursor: pointer; color: var(--ink); padding: 0; }
      .plant-card-info { min-width: 0; flex: 1; }
      .photo-thumb { position: relative; flex-shrink: 0; border-radius: 10px; border: 1px dashed var(--line); background: var(--surface-2); color: var(--ink-muted); display: flex; align-items: center; justify-content: center; overflow: hidden; padding: 0; cursor: pointer; }
      .photo-thumb img { width: 100%; height: 100%; object-fit: cover; }
      .visually-hidden-input { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0; opacity: 0; }
      .plant-name { font-weight: 600; font-size: 14.5px; }
      .plant-variety { font-size: 12.5px; color: var(--ink-muted); font-style: italic; margin-top: 1px; }
      .plant-opis-preview { font-size: 11.5px; color: var(--ink-muted); margin-top: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 220px; }
      .plant-opis-full { font-size: 12.5px; color: var(--ink-muted); margin-bottom: 10px; line-height: 1.4; }
      .plant-info-grid-wrap { margin-bottom: 10px; }
      .plant-info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 14px; margin-bottom: 8px; }
      .info-item { display: flex; flex-direction: column; gap: 1px; }
      .info-label { font-size: 10.5px; color: var(--ink-muted); text-transform: uppercase; letter-spacing: 0.02em; }
      .info-value { font-size: 13px; color: var(--ink); font-weight: 500; }
      .info-block { font-size: 12.5px; color: var(--ink-muted); line-height: 1.45; margin-top: 6px; }
      .info-block b { color: var(--ink); }
      .plant-card-right { display: flex; align-items: center; gap: 8px; color: var(--ink-muted); flex-shrink: 0; }
      .plant-total-badge { font-family: 'JetBrains Mono', monospace; font-size: 12px; background: var(--green-soft); color: var(--brand-dark); padding: 3px 8px; border-radius: 999px; font-weight: 600; white-space: nowrap; }
      .plant-card-body { padding: 4px 13px 12px; display: flex; flex-direction: column; gap: 8px; border-top: 1px solid var(--line); padding-top: 10px; }
      .qty-row { display: flex; align-items: center; justify-content: space-between; }
      .qty-label { font-size: 13px; color: var(--ink-muted); font-weight: 500; width: 50px; }
      .stepper { display: flex; align-items: center; gap: 6px; }
      .stepper-btn { width: 30px; height: 30px; border-radius: 9px; border: 1px solid var(--line); background: var(--surface-2); color: var(--brand); display: flex; align-items: center; justify-content: center; cursor: pointer; }
      .stepper-btn:active { background: var(--green-soft); }
      .stepper-input { width: 48px; text-align: center; border: 1px solid var(--line); border-radius: 8px; padding: 5px 2px; font-family: 'JetBrains Mono', monospace; font-size: 14px; font-weight: 600; color: var(--ink); }
      .empty-state { padding: 24px 8px; text-align: center; color: var(--ink-muted); font-size: 13.5px; }
      .section-title { display: flex; align-items: center; gap: 7px; font-family: 'Fraunces', serif; font-weight: 600; font-size: 15.5px; color: var(--brand-dark); margin-bottom: 10px; }
      .section-title.small-title { font-size: 13px; margin: 4px 0 2px; }
      .task-list { display: flex; flex-direction: column; gap: 7px; margin-bottom: 4px; }
      .task-row { display: flex; align-items: center; gap: 10px; background: var(--surface); border: 1px solid var(--line); border-radius: 12px; padding: 10px 12px; cursor: pointer; text-align: left; width: 100%; }
      .task-row.custom-row { padding: 6px 8px 6px 12px; }
      .task-row.done { opacity: 0.5; } .task-row.done .task-plant { text-decoration: line-through; }
      .task-check { width: 20px; height: 20px; border-radius: 6px; border: 1.6px solid var(--line); display: flex; align-items: center; justify-content: center; flex-shrink: 0; color: white; }
      .task-check.checked { background: var(--brand); border-color: var(--brand); }
      .task-check-btn { background: none; border: none; padding: 0; cursor: pointer; }
      .task-text { flex: 1; display: flex; flex-direction: column; }
      .task-text-btn { flex: 1; background: none; border: none; text-align: left; padding: 0; cursor: pointer; min-width: 0; }
      .task-plant { font-size: 13.5px; font-weight: 600; }
      .task-variety { font-size: 11.5px; color: var(--ink-muted); font-style: italic; }
      .task-tag { font-size: 10.5px; padding: 3px 8px; border-radius: 999px; font-weight: 600; white-space: nowrap; }
      .tag-ciecie { background: var(--gold-soft); color: #7A5A16; }
      .tag-podzial { background: var(--green-soft); color: var(--brand-dark); }
      .tag-pielegnacja { background: var(--rust-soft); color: var(--rust); }
      .tag-wlasne { background: #E3DEF3; color: #4B3E82; }
      .custom-task-block { margin-top: 8px; display: flex; flex-direction: column; gap: 8px; }
      .add-task-btn { width: 100%; justify-content: center; }
      .add-task-form { display: flex; gap: 6px; align-items: center; }
      .add-task-form input { flex: 1; border: 1px solid var(--line); border-radius: 9px; padding: 9px 10px; font-size: 13px; font-family: 'Inter', sans-serif; background: var(--surface-2); color: var(--ink); }
      .month-accordion { display: flex; flex-direction: column; gap: 6px; }
      .month-block { background: var(--surface); border: 1px solid var(--line); border-radius: 12px; overflow: hidden; }
      .month-block.is-current { border-color: var(--brand); }
      .month-head { width: 100%; display: flex; align-items: center; justify-content: space-between; padding: 11px 13px; background: none; border: none; cursor: pointer; font-size: 13.5px; font-weight: 600; color: var(--ink); }
      .month-count { font-size: 11.5px; color: var(--ink-muted); font-family: 'JetBrains Mono', monospace; margin-left: auto; margin-right: 8px; }
      .month-block .task-list { padding: 0 10px 10px; }
      .month-block .custom-task-block { padding: 0 10px 10px; margin-top: 0; }
      .task-list.compact .task-row { padding: 8px 10px; }
      .segmented { display: flex; background: var(--surface-2); border: 1px solid var(--line); border-radius: 12px; padding: 3px; margin-top: 10px; margin-bottom: 4px; }
      .segmented button { flex: 1; border: none; background: none; padding: 8px 0; font-size: 12.5px; font-weight: 600; color: var(--ink-muted); border-radius: 9px; cursor: pointer; }
      .segmented button.active { background: var(--brand); color: #FFFFFF; box-shadow: 0 1px 3px rgba(0,0,0,0.18); }
      .segmented.scrollable { overflow-x: auto; -webkit-overflow-scrolling: touch; }
      .segmented.scrollable button { flex: 0 0 auto; padding: 8px 14px; white-space: nowrap; }
      .price-list { display: flex; flex-direction: column; gap: 8px; }
      .price-card { background: var(--surface); border: 1px solid var(--line); border-radius: 14px; padding: 11px 13px; }
      .price-card-head { width: 100%; display: flex; align-items: center; justify-content: space-between; background: none; border: none; padding: 0; margin-bottom: 4px; cursor: pointer; text-align: left; color: var(--ink); }
      .cost-margin-body { border-top: 1px solid var(--line); margin-top: 8px; padding-top: 8px; display: flex; flex-direction: column; gap: 6px; }
      .cost-margin-row { display: flex; align-items: center; gap: 8px; }
      .cost-margin-label { font-weight: 700; font-size: 12px; width: 32px; flex-shrink: 0; }
      .margin-badge { font-size: 11px; font-weight: 600; color: var(--brand); margin-left: auto; white-space: nowrap; }
      .margin-badge.neg { color: var(--rust); }
      .division-banner { display: flex; flex-direction: column; gap: 8px; background: var(--gold-soft); border: 1px solid #DEC57F; border-radius: 10px; padding: 10px 12px; font-size: 12px; color: #6B4F12; }
      .status-tag { border: none; cursor: pointer; }
      .status-todo { background: var(--surface-2); color: var(--ink-muted); border: 1px solid var(--line); }
      .status-progress { background: var(--gold-soft); color: #7A5A16; }
      .status-done { background: var(--green-soft); color: var(--brand-dark); }
      .calendar-toggle { border: 1px solid var(--line); border-radius: 9px; background: var(--surface-2); }
      .calendar-toggle.active { background: var(--green-soft); color: var(--brand-dark); border-color: var(--brand); }
      .task-date-badge { display: inline-flex; align-items: center; gap: 3px; font-size: 10.5px; font-weight: 700; color: var(--brand-dark); background: var(--green-soft); padding: 3px 7px; border-radius: 999px; white-space: nowrap; flex-shrink: 0; }
      .price-inputs { display: flex; gap: 8px; margin-top: 8px; flex-wrap: wrap; }
      .price-field { flex: 1 1 70px; display: flex; flex-direction: column; gap: 3px; }
      .price-field span { font-size: 10.5px; color: var(--ink-muted); font-weight: 600; }
      .price-input-wrap { display: flex; align-items: center; border: 1px solid var(--line); border-radius: 8px; padding: 5px 8px; background: var(--surface-2); }
      .price-input-wrap.small { flex: 1; }
      .price-input-wrap input { border: none; outline: none; background: none; width: 100%; font-family: 'JetBrains Mono', monospace; font-size: 13px; color: var(--ink); }
      .price-input-wrap .pln { font-size: 11px; color: var(--ink-muted); }
      .price-warning { display: flex; align-items: center; gap: 5px; font-size: 11px; color: var(--rust); margin-top: 2px; }
      .primary-btn { display: inline-flex; align-items: center; justify-content: center; gap: 6px; background: var(--brand); color: white; border: none; border-radius: 12px; padding: 11px 16px; font-size: 14px; font-weight: 600; cursor: pointer; width: 100%; }
      .primary-btn:disabled { opacity: 0.45; }
      .primary-btn.small { width: auto; padding: 7px 12px; font-size: 12.5px; }
      .secondary-btn { background: var(--surface-2); color: var(--brand-dark); border: 1px solid var(--line); border-radius: 12px; padding: 10px 14px; font-size: 13.5px; font-weight: 600; cursor: pointer; }
      .secondary-btn.small { padding: 7px 12px; font-size: 12.5px; }
      .ghost-btn { background: none; border: 1px dashed var(--line); color: var(--ink-muted); border-radius: 12px; padding: 9px 14px; font-size: 13px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; flex: 1; }
      .ghost-btn.small { padding: 6px 10px; font-size: 12px; flex: none; }
      .add-plant-btn { width: 100%; justify-content: center; margin: 10px 0 4px; }
      .danger-btn { background: var(--rust); color: white; border: none; border-radius: 10px; padding: 7px 12px; font-size: 12.5px; font-weight: 600; cursor: pointer; }
      .icon-btn { background: none; border: none; color: var(--ink-muted); cursor: pointer; padding: 6px; }
      .modal-overlay { position: fixed; inset: 0; background: rgba(20, 24, 15, 0.45); display: flex; align-items: flex-end; justify-content: center; z-index: 60; padding: 0; }
      .modal-box { background: var(--surface); width: 100%; max-width: 480px; max-height: 88vh; overflow-y: auto; border-radius: 18px 18px 0 0; padding: 16px; box-shadow: 0 -8px 30px rgba(0,0,0,0.2); }
      .modal-header { display: flex; align-items: center; justify-content: space-between; font-weight: 700; font-family: 'Fraunces', serif; font-size: 16px; color: var(--brand-dark); margin-bottom: 8px; }
      .backup-textarea { width: 100%; min-height: 160px; border: 1px solid var(--line); border-radius: 10px; padding: 10px; font-size: 11.5px; font-family: 'JetBrains Mono', monospace; color: var(--ink); background: var(--surface-2); resize: vertical; }
      .chip-btn { border: 1px solid var(--line); background: var(--surface-2); color: var(--ink-muted); border-radius: 999px; padding: 7px 14px; font-size: 13px; font-weight: 600; cursor: pointer; }
      .chip-btn.chip-active { background: var(--brand); color: white; border-color: var(--brand); }
      .icon-btn.danger { color: var(--rust); }
      .etykiety-actions { display: flex; gap: 8px; margin-bottom: 12px; }
      .label-count-card { display: flex; align-items: center; justify-content: space-between; background: var(--surface); border: 1px solid var(--line); border-radius: 12px; padding: 10px 12px; }
      .print-bar { position: sticky; bottom: 76px; display: flex; align-items: center; justify-content: space-between; background: var(--surface); border: 1px solid var(--line); border-radius: 12px; padding: 10px 12px; margin-top: 14px; font-size: 12.5px; color: var(--ink-muted); }
      .print-bar .primary-btn { width: auto; }
      .order-form { background: var(--surface); border: 1px solid var(--line); border-radius: 14px; padding: 14px; margin-top: 10px; display: flex; flex-direction: column; gap: 10px; }
      .field { display: flex; flex-direction: column; gap: 4px; }
      .field span { font-size: 11.5px; font-weight: 600; color: var(--ink-muted); }
      .field input, .field select, .order-item-row select { border: 1px solid var(--line); border-radius: 9px; padding: 9px 10px; font-size: 13.5px; font-family: 'Inter', sans-serif; background: var(--surface-2); color: var(--ink); }
      .checkbox-field { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--ink); }
      .checkbox-field input { width: 18px; height: 18px; }
      .month-chips { display: flex; flex-wrap: wrap; gap: 6px; }
      .month-chip { border: 1px solid var(--line); background: var(--surface-2); color: var(--ink-muted); border-radius: 8px; padding: 6px 9px; font-size: 11.5px; font-weight: 600; cursor: pointer; }
      .month-chip.active { background: var(--brand); color: #fff; border-color: var(--brand); }
      .pot-size-manager { background: var(--surface); border: 1px solid var(--line); border-radius: 12px; margin-bottom: 10px; overflow: hidden; }
      .pot-size-toggle { width: 100%; display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 9px 12px; background: none; border: none; cursor: pointer; font-size: 12px; color: var(--ink-muted); text-align: left; }
      .pot-size-body { padding: 0 12px 12px; border-top: 1px solid var(--line); padding-top: 10px; }
      .pot-size-chip { display: inline-flex; align-items: center; gap: 5px; border: 1px solid var(--line); background: var(--surface-2); color: var(--ink); border-radius: 8px; padding: 5px 6px 5px 10px; font-size: 12px; font-weight: 600; }
      .pot-size-remove { background: none; border: none; color: var(--ink-muted); cursor: pointer; padding: 2px; display: flex; }
      .recipe-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 8px 0; border-top: 1px dashed var(--line); }
      .recipe-row:first-of-type { border-top: none; }
      .recipe-size { font-weight: 700; font-size: 13px; width: 48px; flex-shrink: 0; }
      .recipe-inputs { display: flex; align-items: center; gap: 8px; flex: 1; flex-wrap: wrap; }
      .recipe-inputs label { display: flex; flex-direction: column; gap: 2px; }
      .recipe-inputs label span { font-size: 9.5px; color: var(--ink-muted); font-weight: 600; }
      .recipe-total { font-family: 'JetBrains Mono', monospace; font-size: 12px; font-weight: 600; color: var(--brand); margin-left: auto; }
      .custom-badge { font-size: 9.5px; background: #E3DEF3; color: #4B3E82; padding: 2px 6px; border-radius: 999px; font-weight: 700; margin-left: 6px; vertical-align: middle; }
      .remove-plant-btn { display: flex; align-items: center; gap: 5px; font-size: 12px; margin-top: 4px; background: none; border: none; padding: 4px 0; cursor: pointer; color: var(--rust); }
      .supply-card { display: flex; align-items: center; justify-content: space-between; gap: 10px; background: var(--surface); border: 1px solid var(--line); border-radius: 18px; padding: 16px 18px; margin-bottom: 10px; }
      .supply-card.low { border-color: var(--rust); background: var(--rust-soft); }
      .supply-card-main { width: 100%; }
      .supply-meta { font-size: 12.5px; color: var(--ink-muted); margin-top: 3px; line-height: 1.4; }
      .supply-qty-row { display: flex; align-items: center; gap: 10px; margin-top: 12px; }
      .supply-qty-input { border: 1px solid var(--line); border-radius: 12px; padding: 10px 14px; font-size: 15px; width: 110px; background: var(--surface); color: var(--ink); }
      .supply-unit { font-size: 13px; color: var(--ink-muted); }
      .supply-qty-row .icon-btn { margin-left: auto; }
      .low-badge { font-size: 9.5px; background: var(--rust); color: white; padding: 2px 6px; border-radius: 999px; font-weight: 700; margin-left: 6px; }
      .recipe-linked-badge { color: var(--brand); font-weight: 600; }
      .stat-row { display: flex; gap: 10px; }
      .stat-box { flex: 1; background: var(--surface-2); border: 1px solid var(--line); border-radius: 14px; padding: 12px 14px; display: flex; flex-direction: column; gap: 4px; }
      .stat-label { font-size: 10.5px; color: var(--ink-muted); text-transform: uppercase; letter-spacing: 0.02em; }
      .stat-value { font-size: 17px; font-weight: 700; color: var(--brand-dark); font-family: 'Fraunces', serif; }
      .dash-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 14px; }
      .dash-card-wide { grid-column: 1 / -1; }
      .dash-card-split { flex-direction: row; justify-content: space-between; gap: 6px; }
      .dash-split-item { display: flex; flex-direction: column; gap: 2px; flex: 1; min-width: 0; }
      .dash-num-sm { font-family: 'JetBrains Mono', monospace; font-size: 14px; font-weight: 700; color: var(--brand); white-space: nowrap; }
      .dash-card { background: var(--surface); border: 1px solid var(--line); border-radius: 14px; padding: 12px; text-align: left; cursor: pointer; display: flex; flex-direction: column; gap: 4px; }
      .dash-num { font-family: 'JetBrains Mono', monospace; font-size: 20px; font-weight: 700; color: var(--brand); }
      .dash-label { font-size: 11px; color: var(--ink-muted); line-height: 1.25; }
      .alert-box { display: flex; align-items: center; gap: 8px; background: var(--rust-soft); color: var(--rust); border-radius: 12px; padding: 10px 12px; font-size: 12.5px; margin-bottom: 14px; }
      .log-list { display: flex; flex-direction: column; gap: 2px; }
      .log-row { display: flex; gap: 10px; padding: 8px 4px; border-bottom: 1px solid var(--line); font-size: 12.5px; }
      .log-time { color: var(--ink-muted); font-family: 'JetBrains Mono', monospace; font-size: 11px; white-space: nowrap; flex-shrink: 0; }
      .log-text { color: var(--ink); }
      .hint-text { font-size: 11.5px; color: var(--ink-muted); margin: 4px 0 10px; line-height: 1.4; }
      .file-label { display: inline-flex; align-items: center; justify-content: center; gap: 6px; cursor: pointer; flex: 1; }
      .order-item-row { display: flex; flex-direction: column; gap: 6px; border-top: 1px dashed var(--line); padding-top: 10px; }
      .order-item-sub { display: flex; gap: 6px; align-items: center; }
      .order-item-sub select { width: 64px; flex-shrink: 0; }
      .order-item-sub input[type=number] { width: 48px; flex-shrink: 0; border: 1px solid var(--line); border-radius: 8px; padding: 8px 4px; text-align: center; font-family: 'JetBrains Mono', monospace; }
      .zestaw-row-head { display: flex; align-items: center; gap: 6px; }
      .row-label-input { flex: 1; border: 1px solid var(--line); border-radius: 8px; padding: 7px 9px; font-size: 12.5px; background: var(--surface); color: var(--ink-muted); font-style: italic; }
      .icon-btn.calc-active { color: var(--brand); background: var(--green-soft); border-radius: 8px; }
      .planting-calc { background: var(--surface-2); border: 1px dashed var(--line); border-radius: 12px; padding: 10px 12px; margin-top: 4px; }
      .planting-calc.compact { padding: 8px 10px; }
      .planting-calc-head { font-size: 12px; font-weight: 700; color: var(--brand-dark); display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
      .planting-calc-row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 4px; }
      .planting-calc-row input { width: 90px; border: 1px solid var(--line); border-radius: 8px; padding: 7px 9px; font-family: 'JetBrains Mono', monospace; background: var(--surface); }
      .chip-btn-group { display: flex; gap: 6px; flex-wrap: wrap; }
      .planting-calc-result { display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap; font-size: 12.5px; font-weight: 600; color: var(--ink); margin-top: 4px; }
      .planting-calc-apply { display: flex; gap: 6px; }
      .planting-calc-pick { display: flex; align-items: center; gap: 6px; }
      .chip-btn.tiny { padding: 4px 9px; font-size: 11px; }
      .qty-pick-input { width: 54px; border: 1px solid var(--line); border-radius: 8px; padding: 6px 4px; text-align: center; font-family: 'JetBrains Mono', monospace; background: var(--surface); }
      .calc-note { margin: 4px 0 0; }
      .order-item-subtotal { text-align: right; font-size: 11.5px; color: var(--ink-muted); font-family: 'JetBrains Mono', monospace; }
      .order-total { text-align: right; font-size: 14px; padding-top: 4px; }
      .form-actions { display: flex; gap: 8px; margin-top: 6px; }
      .form-actions .secondary-btn, .form-actions .primary-btn { flex: 1; }
      .order-list { display: flex; flex-direction: column; gap: 8px; margin-top: 14px; }
      .order-card { background: var(--surface); border: 1px solid var(--line); border-radius: 14px; overflow: hidden; }
      .order-card-head { width: 100%; display: flex; justify-content: space-between; align-items: center; padding: 11px 13px; background: none; border: none; cursor: pointer; text-align: left; }
      .order-card-head.static { cursor: default; }
      .order-client { font-weight: 600; font-size: 14px; }
      .order-date { font-size: 11.5px; color: var(--ink-muted); }
      .order-card-right { text-align: right; display: flex; flex-direction: column; align-items: flex-end; gap: 3px; }
      .order-sum { display: block; font-family: 'JetBrains Mono', monospace; font-size: 13px; font-weight: 600; }
      .order-sum.neg { color: var(--rust); }
      .year-switcher { display: flex; align-items: center; justify-content: center; gap: 14px; margin-bottom: 12px; }
      .year-label { font-family: 'Fraunces', serif; font-weight: 700; font-size: 18px; color: var(--brand-dark); min-width: 52px; text-align: center; }
      .stat-box.stat-pos { background: var(--green-soft); border-color: var(--brand); }
      .stat-box.stat-pos .stat-value { color: var(--brand-dark); display: flex; align-items: center; gap: 4px; }
      .stat-box.stat-neg { background: var(--rust-soft); border-color: var(--rust); }
      .stat-box.stat-neg .stat-value { color: var(--rust); display: flex; align-items: center; gap: 4px; }
      .status-badge { font-size: 10px; padding: 2px 8px; border-radius: 999px; font-weight: 600; display: inline-block; }
      .status-badge.new { background: var(--gold-soft); color: #7A5A16; }
      .status-badge.ok { background: var(--green-soft); color: var(--brand-dark); }
      .order-card-body { border-top: 1px solid var(--line); padding: 10px 13px 13px; display: flex; flex-direction: column; gap: 6px; }
      .order-line { display: flex; justify-content: space-between; font-size: 12.5px; color: var(--ink-muted); gap: 8px; }
      .report-total { font-weight: 700; color: var(--ink); border-top: 1px dashed var(--line); padding-top: 6px; margin-top: 2px; }
      .order-card-actions { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-top: 6px; }
      .confirm-box { display: flex; flex-direction: column; gap: 6px; background: var(--surface-2); border: 1px solid var(--line); border-radius: 10px; padding: 8px 10px; font-size: 12.5px; width: 100%; }
      .confirm-actions { display: flex; gap: 6px; flex-wrap: wrap; }
      .bottom-nav { position: fixed; bottom: 0; left: 50%; transform: translateX(-50%); width: 100%; max-width: 480px; display: flex; background: var(--surface); border-top: 1px solid var(--line); padding: 6px 2px calc(6px + env(safe-area-inset-bottom, 0px)); z-index: 20; }
      .nav-btn { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 3px; background: none; border: none; padding: 6px 0; color: var(--ink-muted); cursor: pointer; }
      .nav-btn span { font-size: 9.5px; font-weight: 500; }
      .nav-btn.active { color: var(--brand-dark); background: var(--green-soft); border-radius: 12px; }
      .nav-btn.active span { font-weight: 700; }
      .toast { position: fixed; bottom: 92px; left: 50%; transform: translateX(-50%); background: var(--rust); color: white; padding: 9px 14px; border-radius: 10px; font-size: 12.5px; display: flex; align-items: center; gap: 6px; max-width: 90%; z-index: 30; box-shadow: 0 4px 14px rgba(0,0,0,0.18); }
      .toast.success { background: var(--brand); }
      .print-area { display: none; }
      .label-preview-card {
        border: 1px dashed #999; border-radius: 8px; padding: 12px 14px; background: var(--surface);
        max-width: 220px; font-family: 'Inter', sans-serif;
      }
      .lp-name { font-family: 'Fraunces', serif; font-weight: 700; font-size: 15px; color: #1F331C; }
      .lp-variety { font-style: italic; font-size: 12px; color: #333; margin-bottom: 6px; }
      .lp-row { font-size: 10.5px; margin-top: 3px; color: #222; }
      @media print { .label-preview-section { display: none !important; } }
      @media print {
        .app-header, .bottom-nav, .toast, .tab-pad > *:not(.print-area) { display: none !important; }
        .app-content { padding-bottom: 0; }
        .print-area { display: block; }
        .print-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
        .print-label { border: 1px dashed #999; padding: 10px 12px; min-height: 3.4cm; break-inside: avoid; font-family: 'Inter', sans-serif; }
        .pl-name { font-family: 'Fraunces', serif; font-weight: 700; font-size: 13px; color: #1F331C; }
        .pl-variety { font-style: italic; font-size: 10.5px; color: #333; margin-bottom: 4px; }
        .pl-row { font-size: 8.5px; margin-top: 2px; color: #222; }

        /* Drukarka termiczna (etykiety pojedyncze, rozmiar z ustawie\u0144) \u2014 patrz FUNKCJA DODATKOWA w EtykietyTab.jsx */
        .print-area.thermal .print-grid { grid-template-columns: 1fr; }
        .print-area.thermal .print-label { border: none; min-height: 0; padding: 2mm; page: thermal; break-after: page; }
        .print-area.thermal .pl-name { font-size: 9px; }
        .print-area.thermal .pl-variety { font-size: 7.5px; margin-bottom: 2px; }
        .print-area.thermal .pl-row { font-size: 6.5px; margin-top: 1px; }

        /* Paszport ro\u015Blin UE (Rozporz\u0105dzenie 2016/2031 / 2017/2313) \u2014 pola A/B/C/D */
        .passport-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 3px; }
        .passport-flag { background: #003399; color: #FFCC00; font-weight: 700; font-size: 7px; padding: 1px 4px; border-radius: 2px; letter-spacing: 0.5px; }
        .passport-title { font-size: 7px; font-weight: 700; text-align: right; }
        .passport-row { font-size: 8px; margin-top: 1.5px; }
        .passport-letter { font-weight: 700; margin-right: 3px; }
      }
    `);
}

// src/App.jsx
var KNOWN_IMPORT_KEYS = [
  "inventory",
  "cennik",
  "zamowienia",
  "schedule-done",
  "custom-tasks",
  "zestawy",
  "photos",
  "custom-plants",
  "clients",
  "losses",
  "log",
  "supplies",
  "pot-sizes",
  "plant-container-sizes",
  "pot-recipes",
  "substrate-cost-per-l",
  "koszty",
  "tasks-general",
  "overhead-costs",
  "batches",
  "batch-segments",
  "production-plans",
  "batch-photos",
  "piorin-number",
  "origin-country",
  "thermal-label-size"
];
function App() {
  const [ready, setReady] = useState28(false);
  const [tab, setTab] = useState28("pulpit");
  const [inventory, setInventory] = useState28({});
  const [cennik, setCennik] = useState28({});
  const [orders, setOrders] = useState28([]);
  const [done, setDone] = useState28({});
  const [customTasks, setCustomTasks] = useState28({});
  const [zestawy, setZestawy] = useState28([]);
  const [photos, setPhotos] = useState28({});
  const [customPlants, setCustomPlants] = useState28([]);
  const [clients, setClients] = useState28([]);
  const [losses, setLosses] = useState28([]);
  const [log, setLog] = useState28([]);
  const [supplies, setSupplies] = useState28(DEFAULT_SUPPLIES);
  const potSizes = useMemo6(() => {
    const derived = deriveContainerSizes(supplies);
    return derived.length ? derived : DEFAULT_POT_SIZES;
  }, [supplies]);
  const [plantContainerSizes, setPlantContainerSizes] = useState28({});
  const [potRecipes, setPotRecipes] = useState28({});
  const [substrateCostPerL, setSubstrateCostPerL] = useState28(0);
  const [piorinNumber, setPiorinNumber] = useState28("");
  const [originCountry, setOriginCountry] = useState28("PL");
  const [thermalLabelSize, setThermalLabelSize] = useState28({ width: 40, height: 30 });
  const [costs, setCosts] = useState28({});
  const [toast, setToast] = useState28(null);
  const [tasks, setTasks] = useState28([]);
  const [overheadCosts, setOverheadCosts] = useState28([]);
  const [productionPlans, setProductionPlans] = useState28([]);
  const [batchPhotos, setBatchPhotos] = useState28({});
  const [batches, setBatches] = useState28([]);
  const [batchSegments, setBatchSegments] = useState28([]);
  function notify(msg, type) {
    setToast({ msg, type: type || "error" });
    setTimeout(() => setToast(null), 3500);
  }
  useEffect6(() => {
    (async () => {
      const [core, config, activity, photoKeys, batchesLoaded] = await Promise.all([
        loadKey("core-data", {}),
        loadKey("config-data", {}),
        loadKey("activity-data", {}),
        listPhotoKeys(),
        loadKey(tenantKey("batches-data", DEFAULT_TENANT_ID), { batches: [], segments: [] })
      ]);
      setInventory(core.inventory || {});
      setCennik(core.cennik || {});
      setOrders(core.orders || []);
      setZestawy(core.zestawy || []);
      setCosts(core.costs || {});
      setPlantContainerSizes(config.plantContainerSizes || {});
      setPotRecipes(config.potRecipes || {});
      setSubstrateCostPerL(config.substrateCostPerL || 0);
      const { supplies: migratedSupplies } = migrateSupplies(config.supplies || DEFAULT_SUPPLIES, config.potSizes || DEFAULT_POT_SIZES);
      setSupplies(migratedSupplies);
      setCustomPlants(config.customPlants || []);
      setClients(config.clients || []);
      setPiorinNumber(config.piorinNumber || "");
      setOriginCountry(config.originCountry || "PL");
      setThermalLabelSize(config.thermalLabelSize || { width: 40, height: 30 });
      setDone(activity.done || {});
      setCustomTasks(activity.customTasks || {});
      setLosses(activity.losses || []);
      setLog(activity.log || []);
      setTasks(activity.tasks || []);
      setOverheadCosts(activity.overheadCosts || []);
      setProductionPlans(activity.productionPlans || []);
      setBatchPhotos(activity.batchPhotos || {});
      setBatches(batchesLoaded.batches || []);
      setBatchSegments(batchesLoaded.segments || []);
      const photoEntries = await Promise.all(
        photoKeys.map(async (key) => {
          const val = await loadKey(key, null);
          return [key.replace("photo:", ""), val];
        })
      );
      const ph = {};
      photoEntries.forEach(([id, val]) => {
        if (val) ph[id] = val;
      });
      setPhotos(ph);
      photosLoadedRef.current = ph;
      setReady(true);
    })();
  }, []);
  const coreData = useMemo6(() => ({ inventory, cennik, orders, zestawy, costs }), [inventory, cennik, orders, zestawy, costs]);
  const configData = useMemo6(
    () => ({ potSizes, plantContainerSizes, potRecipes, substrateCostPerL, supplies, customPlants, clients, piorinNumber, originCountry, thermalLabelSize }),
    [potSizes, plantContainerSizes, potRecipes, substrateCostPerL, supplies, customPlants, clients, piorinNumber, originCountry, thermalLabelSize]
  );
  const activityData = useMemo6(() => ({ done, customTasks, losses, log, tasks, overheadCosts, productionPlans, batchPhotos }), [done, customTasks, losses, log, tasks, overheadCosts, productionPlans, batchPhotos]);
  useDebouncedSave("core-data", coreData, ready, notify);
  useDebouncedSave("config-data", configData, ready, notify);
  useDebouncedSave("activity-data", activityData, ready, notify);
  const batchesData = useMemo6(() => ({ batches, segments: batchSegments }), [batches, batchSegments]);
  useDebouncedSave(tenantKey("batches-data", DEFAULT_TENANT_ID), batchesData, ready, notify);
  const photosLoadedRef = useRef2({});
  useEffect6(() => {
    if (!ready) return;
    const prev = photosLoadedRef.current;
    Object.entries(photos).forEach(([id, dataUrl]) => {
      if (prev[id] !== dataUrl) {
        saveKey(`photo:${id}`, dataUrl).then((ok) => {
          if (!ok) notify("Nie uda\u0142o si\u0119 zapisa\u0107 zdj\u0119cia \u2014 spr\xF3buj mniejsze/inne zdj\u0119cie.");
        });
      }
    });
    photosLoadedRef.current = photos;
  }, [photos, ready]);
  const allPlants = useMemo6(() => [...PLANTS, ...customPlants], [customPlants]);
  const containers = useMemo6(() => [...potSizes, "grunt"], [potSizes]);
  const totals = useMemo6(() => {
    const t = {};
    containers.forEach((c) => {
      t[c] = 0;
    });
    Object.values(inventory).forEach((row) => {
      containers.forEach((c) => {
        t[c] += Number(row?.[c] || 0);
      });
    });
    return t;
  }, [inventory, containers]);
  const potsTotal = useMemo6(() => potSizes.reduce((s, c) => s + Number(totals[c] || 0), 0), [totals, potSizes]);
  const magazynValue = useMemo6(() => {
    let v = 0;
    Object.entries(inventory).forEach(([plantId, row]) => {
      Object.entries(row || {}).forEach(([container, qty]) => {
        v += Number(qty || 0) * Number(costs[plantId]?.[container] || 0);
      });
    });
    return v;
  }, [inventory, costs]);
  const salesValue = useMemo6(() => {
    let v = 0;
    Object.entries(inventory).forEach(([plantId, row]) => {
      Object.entries(row || {}).forEach(([container, qty]) => {
        v += Number(qty || 0) * Number(cennik[plantId]?.[container] || 0);
      });
    });
    return v;
  }, [inventory, cennik]);
  function addPotSize(name) {
    const trimmed = (name || "").trim();
    if (!trimmed || trimmed.toLowerCase() === "grunt") return;
    if (potSizes.some((p) => p.toLowerCase() === trimmed.toLowerCase())) {
      notify(`Rozmiar \u201E${trimmed}\u201D ju\u017C istnieje.`);
      return;
    }
    setSupplies((prev) => [...prev, { id: uid2("sup"), nazwa: `Donice ${trimmed} (puste)`, ilosc: 0, jednostka: "szt.", prog: null, cena: 0, typ: "donica", rozmiar: trimmed }]);
    pushLog(`Dodano rozmiar pojemnika (jako materia\u0142 w Zaopatrzeniu): ${trimmed}`);
  }
  function togglePlantContainer(plantId, container) {
    const current = plantContainerSizes[plantId] && plantContainerSizes[plantId].length ? plantContainerSizes[plantId] : containers;
    const isActive = current.includes(container);
    if (isActive) {
      if (current.length <= 1) {
        notify("Ta odmiana musi mie\u0107 przynajmniej jeden dost\u0119pny rozmiar pojemnika.");
        return;
      }
      const stock = Number(inventory[plantId]?.[container] || 0);
      if (stock > 0) {
        notify(`Nie mo\u017Cna wy\u0142\u0105czy\u0107 \u201E${containerLabel(container)}\u201D \u2014 jest tam ${stock} szt. na stanie.`);
        return;
      }
      const next = current.filter((c) => c !== container);
      setPlantContainerSizes((prev) => ({ ...prev, [plantId]: next }));
    } else {
      const next = [...current, container];
      setPlantContainerSizes((prev) => ({ ...prev, [plantId]: next }));
    }
  }
  function setPotRecipe(size, patch) {
    setPotRecipes((prev) => ({ ...prev, [size]: { ...prev[size] || { koszt_donicy: 0, podloze_l: 0 }, ...patch } }));
  }
  const TASK_STATUS_ORDER = ["todo", "progress", "done"];
  function addTask(text, date) {
    const trimmed = (text || "").trim();
    if (!trimmed) return;
    setTasks((prev) => [{ id: uid2("tk"), text: trimmed, status: "todo", date: date || null, createdAt: Date.now() }, ...prev]);
  }
  function cycleTaskStatus(id) {
    setTasks((prev) => prev.map((t) => {
      if (t.id !== id) return t;
      const idx = TASK_STATUS_ORDER.indexOf(t.status);
      const next = TASK_STATUS_ORDER[(idx + 1) % TASK_STATUS_ORDER.length];
      return { ...t, status: next };
    }));
  }
  function deleteTask(id) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }
  function setCost(plantId, container, val) {
    const n = Math.max(0, Number(val) || 0);
    setCosts((prev) => ({ ...prev, [plantId]: { ...prev[plantId] || {}, [container]: n } }));
  }
  function performDivision({ plantId, sourceContainer, sourceQty, deductSource, targets, trackAsBatch, sourceSegmentId }) {
    const validTargets = targets.filter((t) => t.container && clampInt(t.ilosc, 0) > 0);
    if (!plantId || validTargets.length === 0) {
      notify("Podaj przynajmniej jedn\u0105 pozycj\u0119 docelow\u0105 z ilo\u015Bci\u0105 wi\u0119ksz\u0105 od zera.");
      return;
    }
    const totalNewUnits = validTargets.reduce((s, t) => s + clampInt(t.ilosc, 0), 0);
    if (trackAsBatch && !sourceSegmentId) {
      notify("Zaznaczy\u0142e\u015B \u015Bledzenie partii \u2014 wybierz rzeczywisty segment \u017Ar\xF3d\u0142owy, albo odznacz \u015Bledzenie.");
      return;
    }
    let sourceSegment = null;
    if (trackAsBatch && sourceSegmentId) {
      sourceSegment = batchSegments.find((s) => s.id === sourceSegmentId);
      if (!sourceSegment) {
        notify("Nie znaleziono wybranego segmentu \u017Ar\xF3d\u0142owego partii.");
        return;
      }
    }
    let actualSourceQty = clampInt(sourceQty, 0);
    if (deductSource) {
      const have = Number(inventory[plantId]?.[sourceContainer] || 0);
      if (actualSourceQty > have) {
        notify(`W \u017Ar\xF3dle (${containerLabel(sourceContainer)}) by\u0142o tylko ${have} szt. \u2014 ograniczono do tej ilo\u015Bci.`);
        return;
      }
      if (actualSourceQty <= 0) {
        notify("Brak sztuk w \u017Ar\xF3dle do wykorzystania.");
        return;
      }
      if (sourceSegment && actualSourceQty > Number(sourceSegment.ilosc || 0)) {
        notify(`Ubytek \u017Ar\xF3d\u0142a (${actualSourceQty}) przekracza dost\u0119pn\u0105 ilo\u015B\u0107 w segmencie partii (${sourceSegment.ilosc} szt.).`);
        return;
      }
    }
    const srcCostPerSzt = trackAsBatch && sourceSegment ? Number(sourceSegment.kosztJednostkowy || 0) : Number(costs[plantId]?.[sourceContainer] || 0);
    const totalSrcCost = deductSource ? actualSourceQty * srcCostPerSzt : 0;
    const srcCostPerNewUnit = totalNewUnits > 0 ? totalSrcCost / totalNewUnits : 0;
    if (deductSource) {
      const have = Number(inventory[plantId]?.[sourceContainer] || 0);
      const nextSrc = Math.max(0, have - actualSourceQty);
      setInventory((prev) => ({ ...prev, [plantId]: { ...prev[plantId] || {}, [sourceContainer]: nextSrc } }));
    }
    setInventory((prev) => {
      const next = { ...prev, [plantId]: { ...prev[plantId] || {} } };
      validTargets.forEach((t) => {
        const cur = Number(next[plantId][t.container] || 0);
        next[plantId][t.container] = cur + clampInt(t.ilosc, 0);
      });
      return next;
    });
    setCosts((prev) => {
      const plantCosts = { ...prev[plantId] || {} };
      validTargets.forEach((t) => {
        const containerCost = costOfContainer(potRecipes, substrateCostPerL, t.container);
        const unitCost = srcCostPerNewUnit + containerCost;
        const priorQty = Number(inventory[plantId]?.[t.container] || 0);
        const priorCost = Number(plantCosts[t.container] || 0);
        const addedQty = clampInt(t.ilosc, 0);
        const newQty = priorQty + addedQty;
        plantCosts[t.container] = Math.round((newQty > 0 ? (priorQty * priorCost + addedQty * unitCost) / newQty : unitCost) * 100) / 100;
      });
      return { ...prev, [plantId]: plantCosts };
    });
    setSupplies((prev) => prev.map((s) => {
      let delta = 0;
      validTargets.forEach((t) => {
        const potSupply = findSupplyByContainer([s], t.container);
        if (potSupply) delta -= clampInt(t.ilosc, 0);
      });
      const substrateSupply = findSubstrateSupply([s]);
      if (substrateSupply) {
        validTargets.forEach((t) => {
          const recipe = potRecipes[t.container];
          if (recipe) delta -= Number(recipe.podloze_l || 0) * clampInt(t.ilosc, 0);
        });
      }
      return delta !== 0 ? { ...s, ilosc: Math.max(0, Number(s.ilosc || 0) + delta) } : s;
    }));
    const targetsText = validTargets.map((t) => `${clampInt(t.ilosc, 0)}\xD7 ${containerLabel(t.container)}${t.location ? ` (${t.location})` : ""}`).join(" + ");
    pushLog(`Podzia\u0142 ${plantLabel(plantId)}: ${deductSource ? `${actualSourceQty} szt. z ${containerLabel(sourceContainer)} \u2192 ` : ""}${targetsText}`);
    const resultInfo = {
      production: validTargets.map((t) => ({ container: t.container, ilosc: clampInt(t.ilosc, 0), location: t.location || null })),
      source: null,
      newBatch: null
    };
    if (trackAsBatch && sourceSegment) {
      const nowePozycje = validTargets.map((t) => {
        const containerCost = costOfContainer(potRecipes, substrateCostPerL, t.container);
        const unitCost = srcCostPerNewUnit + containerCost;
        return { container: t.container, location: t.location || null, ilosc: clampInt(t.ilosc, 0), kosztJednostkowy: unitCost };
      });
      const zrodloUbytek = deductSource ? actualSourceQty : 0;
      const result = divideSegment({
        batches,
        segments: batchSegments,
        sourceSegmentId,
        zrodloUbytek,
        nowePozycje,
        tenantId: DEFAULT_TENANT_ID,
        opis: `Podzia\u0142 ${plantLabel(plantId)}: ${targetsText}.`
      });
      if (result.ok) {
        setBatches(result.batches);
        setBatchSegments(result.segments);
        const before = Number(sourceSegment.ilosc || 0);
        resultInfo.source = {
          label: plantLabel(plantId),
          location: sourceSegment.location || null,
          before,
          after: Math.max(0, before - zrodloUbytek)
        };
        resultInfo.newBatch = {
          id: result.newBatchId,
          originLabel: `${plantLabel(plantId)} / partia ${sourceSegment.batchId}`
        };
      } else {
        notify(`Nie uda\u0142o si\u0119 powi\u0105za\u0107 podzia\u0142u z segmentem partii: ${result.error} (inventory i koszty zaktualizowane normalnie).`);
      }
    }
    return resultInfo;
  }
  function performPurchase({ plantId, container, ilosc, kosztJednostkowy, location, trackAsBatch, customLabel }) {
    const qty = clampInt(ilosc, 0);
    if (!plantId || !container || qty <= 0) {
      notify("Podaj odmian\u0119, pojemnik i ilo\u015B\u0107 wi\u0119ksz\u0105 od zera.");
      return;
    }
    const unitCost = Math.max(0, Number(kosztJednostkowy) || 0);
    setInventory((prev) => {
      const plantRow = { ...prev[plantId] || {} };
      plantRow[container] = Number(plantRow[container] || 0) + qty;
      return { ...prev, [plantId]: plantRow };
    });
    setCosts((prev) => {
      const plantCosts = { ...prev[plantId] || {} };
      const priorQty = Number(inventory[plantId]?.[container] || 0);
      const priorCost = Number(plantCosts[container] || 0);
      const newQty = priorQty + qty;
      plantCosts[container] = Math.round((newQty > 0 ? (priorQty * priorCost + qty * unitCost) / newQty : unitCost) * 100) / 100;
      return { ...prev, [plantId]: plantCosts };
    });
    pushLog(`Zakup ${plantLabel(plantId)}: +${qty} szt. ${containerLabel(container)}${location ? ` (${location})` : ""} po ${money(unitCost)} z\u0142/szt.`);
    if (trackAsBatch) {
      const newBatch = createBatch({
        tenantId: DEFAULT_TENANT_ID,
        plantId,
        source: { type: "zakup", parentBatchId: null, parentSegmentId: null },
        initialQty: qty,
        opis: `Zakup: ${qty} szt. ${containerLabel(container)}${location ? ` \u2014 ${location}` : ""}.`,
        existingBatches: batches,
        customLabel
      });
      const newSegment = createSegment({
        tenantId: DEFAULT_TENANT_ID,
        batchId: newBatch.id,
        plantId,
        container,
        location: location || null,
        ilosc: qty,
        kosztJednostkowy: unitCost,
        originEventOpis: `Zakup: ${qty} szt.${location ? ` do ${location}` : ""}.`
      });
      setBatches((prev) => [...prev, newBatch]);
      setBatchSegments((prev) => [...prev, newSegment]);
    }
  }
  function performTransplant({ plantId, sourceContainer, ilosc, toContainer, toLocation, trackAsBatch, sourceSegmentId }) {
    const qty = clampInt(ilosc, 0);
    if (!plantId) {
      notify("Wybierz odmian\u0119.");
      return;
    }
    if (qty <= 0) {
      notify("Podaj ilo\u015B\u0107 wi\u0119ksz\u0105 od zera.");
      return;
    }
    if (!toContainer) {
      notify("Wybierz pojemnik docelowy.");
      return;
    }
    let sourceSegment = null;
    if (trackAsBatch) {
      if (!sourceSegmentId) {
        notify("Zaznaczy\u0142e\u015B \u015Bledzenie partii \u2014 wybierz rzeczywisty segment \u017Ar\xF3d\u0142owy, albo odznacz \u015Bledzenie.");
        return;
      }
      sourceSegment = batchSegments.find((s) => s.id === sourceSegmentId);
      if (!sourceSegment) {
        notify("Nie znaleziono wybranego segmentu \u017Ar\xF3d\u0142owego.");
        return;
      }
      if (qty > Number(sourceSegment.ilosc || 0)) {
        notify(`Ilo\u015B\u0107 do przesadzenia (${qty}) przekracza stan segmentu \u017Ar\xF3d\u0142owego (${sourceSegment.ilosc} szt.).`);
        return;
      }
      if (toContainer === sourceSegment.container && (toLocation || null) === (sourceSegment.location || null)) {
        notify("Pojemnik i lokalizacja docelowa s\u0105 takie same jak \u017Ar\xF3d\u0142owe \u2014 to nie by\u0142oby przesadzenie.");
        return;
      }
    } else {
      const have = Number(inventory[plantId]?.[sourceContainer] || 0);
      if (qty > have) {
        notify(`Ilo\u015B\u0107 do przesadzenia (${qty}) przekracza stan \u017Ar\xF3d\u0142a (${have} szt.).`);
        return;
      }
      if (toContainer === sourceContainer) {
        notify("Pojemnik docelowy jest taki sam jak \u017Ar\xF3d\u0142owy \u2014 to nie by\u0142oby przesadzenie.");
        return;
      }
    }
    const recipeMissing = toContainer !== "grunt" && !potRecipes[toContainer];
    if (recipeMissing) {
      notify(`Brak receptury dla pojemnika ${containerLabel(toContainer)} \u2014 uzupe\u0142nij j\u0105 w Zaopatrzeniu przed przesadzeniem.`);
      return;
    }
    const extraCostPerUnit = costOfContainer(potRecipes, substrateCostPerL, toContainer);
    setInventory((prev) => {
      const row = { ...prev[plantId] || {} };
      row[sourceContainer] = Math.max(0, Number(row[sourceContainer] || 0) - qty);
      row[toContainer] = Number(row[toContainer] || 0) + qty;
      return { ...prev, [plantId]: row };
    });
    const sourceUnitCostAggregate = trackAsBatch && sourceSegment ? Number(sourceSegment.kosztJednostkowy || 0) : Number(costs[plantId]?.[sourceContainer] || 0);
    setCosts((prev) => {
      const plantCosts = { ...prev[plantId] || {} };
      const newUnitCostAggregate = sourceUnitCostAggregate + extraCostPerUnit;
      const priorQty = Number(inventory[plantId]?.[toContainer] || 0);
      const priorCost = Number(plantCosts[toContainer] || 0);
      const newQty = priorQty + qty;
      plantCosts[toContainer] = Math.round((newQty > 0 ? (priorQty * priorCost + qty * newUnitCostAggregate) / newQty : newUnitCostAggregate) * 100) / 100;
      return { ...prev, [plantId]: plantCosts };
    });
    const fromLocationText = trackAsBatch && sourceSegment && sourceSegment.location ? ` (${sourceSegment.location})` : "";
    const toLocationText = toLocation ? ` (${toLocation})` : "";
    const batchText = trackAsBatch && sourceSegment ? ` \u2014 Batch ${sourceSegment.batchId}` : "";
    pushLog(`Przesadzenie ${plantLabel(plantId)}: ${qty} szt. ${containerLabel(sourceContainer)}${fromLocationText} \u2192 ${containerLabel(toContainer)}${toLocationText}${batchText}.`);
    setSupplies((prev) => prev.map((s) => {
      let delta = 0;
      const potSupply = findSupplyByContainer([s], toContainer);
      if (potSupply) delta -= qty;
      const substrateSupply = findSubstrateSupply([s]);
      if (substrateSupply) {
        const recipe = potRecipes[toContainer];
        if (recipe) delta -= Number(recipe.podloze_l || 0) * qty;
      }
      return delta !== 0 ? { ...s, ilosc: Math.max(0, Number(s.ilosc || 0) + delta) } : s;
    }));
    const resultInfo = {
      plantLabel: plantLabel(plantId),
      ilosc: qty,
      fromContainer: sourceContainer,
      fromLocation: trackAsBatch && sourceSegment ? sourceSegment.location || null : null,
      toContainer,
      toLocation: toLocation || null,
      batchId: null
    };
    if (trackAsBatch && sourceSegment) {
      const result = transplantSegment({
        segments: batchSegments,
        sourceSegmentId,
        ilosc: qty,
        toContainer,
        toLocation: toLocation || null,
        extraCostPerUnit
      });
      if (result.ok) {
        setBatchSegments(result.segments);
        resultInfo.batchId = sourceSegment.batchId;
      } else {
        notify(`Nie uda\u0142o si\u0119 zaktualizowa\u0107 segmentu partii: ${result.error} (inventory i koszty zaktualizowane normalnie).`);
      }
    }
    return resultInfo;
  }
  function settleAsDivision(plantId, deltas) {
    const negEntries = Object.entries(deltas).filter(([, d]) => d < 0);
    const posEntries = Object.entries(deltas).filter(([, d]) => d > 0);
    if (negEntries.length === 0 || posEntries.length === 0) return;
    const totalSrcCost = negEntries.reduce((s, [c, d]) => s + Math.abs(d) * Number(costs[plantId]?.[c] || 0), 0);
    const totalNewUnits = posEntries.reduce((s, [, d]) => s + d, 0);
    const srcCostPerNewUnit = totalNewUnits > 0 ? totalSrcCost / totalNewUnits : 0;
    setCosts((prev) => {
      const plantCosts = { ...prev[plantId] || {} };
      posEntries.forEach(([c, d]) => {
        const containerCost = costOfContainer(potRecipes, substrateCostPerL, c);
        const unitCost = srcCostPerNewUnit + containerCost;
        const currentQty = Number(inventory[plantId]?.[c] || 0);
        const priorQty = Math.max(0, currentQty - d);
        const priorCost = Number(plantCosts[c] || 0);
        plantCosts[c] = Math.round((currentQty > 0 ? (priorQty * priorCost + d * unitCost) / currentQty : unitCost) * 100) / 100;
      });
      return { ...prev, [plantId]: plantCosts };
    });
    setSupplies((prev) => prev.map((s) => {
      let delta = 0;
      posEntries.forEach(([c, d]) => {
        const potSupply = findSupplyByContainer([s], c);
        if (potSupply) delta -= d;
      });
      const substrateSupply = findSubstrateSupply([s]);
      if (substrateSupply) {
        posEntries.forEach(([c, d]) => {
          const recipe = potRecipes[c];
          if (recipe) delta -= Number(recipe.podloze_l || 0) * d;
        });
      }
      return delta !== 0 ? { ...s, ilosc: Math.max(0, Number(s.ilosc || 0) + delta) } : s;
    }));
    const fromText = negEntries.map(([c, d]) => `${Math.abs(d)}\xD7 ${containerLabel(c)}`).join(" + ");
    const toText = posEntries.map(([c, d]) => `${d}\xD7 ${containerLabel(c)}`).join(" + ");
    pushLog(`Podzia\u0142 (przez korekt\u0119 ilo\u015Bci) ${plantLabel(plantId)}: ${fromText} \u2192 ${toText}`);
  }
  function plantLabel(plantId) {
    const p = allPlants.find((pp) => pp.id === plantId);
    return p ? `${p.nazwa_pl} (${p.odmiana})` : plantId;
  }
  function pushLog(text) {
    setLog((prev) => [{ id: uid2("l"), ts: Date.now(), text }, ...prev].slice(0, 200));
  }
  function setSegmentQualityH(segmentId, jakosc) {
    const result = setSegmentQuality({ segments: batchSegments, segmentId, jakosc });
    if (result.ok) {
      setBatchSegments(result.segments);
    } else {
      notify(`Nie uda\u0142o si\u0119 zapisa\u0107 jako\u015Bci: ${result.error}`);
    }
  }
  function addProductionPlan(data) {
    if (!data.plantId) {
      notify("Wybierz odmian\u0119.");
      return;
    }
    if (!data.plannedYear || !data.plannedMonth) {
      notify("Podaj planowany miesi\u0105c.");
      return;
    }
    const plan = createProductionPlan(data);
    setProductionPlans((prev) => [plan, ...prev]);
    pushLog(`Plan produkcji: ${plantLabel(data.plantId)} \u2014 ${data.plannedMonth}/${data.plannedYear}${data.expectedQty ? `, spodziewane ${data.expectedQty} szt.` : ""}.`);
  }
  function setPlanStatusH(planId, status) {
    const result = setPlanStatus(productionPlans, planId, status);
    if (result.ok) {
      setProductionPlans(result.plans);
    } else {
      notify(`Nie uda\u0142o si\u0119 zaktualizowa\u0107 planu: ${result.error}`);
    }
  }
  function deleteProductionPlan(planId) {
    setProductionPlans((prev) => prev.filter((p) => p.id !== planId));
  }
  function addBatchPhoto(batchId, dataUrl, note) {
    const photoId = uid2("photo");
    setBatchPhotos((prev) => ({ ...prev, [batchId]: [...prev[batchId] || [], { id: photoId, ts: (/* @__PURE__ */ new Date()).toISOString(), note: note || "" }] }));
    setPhotos((prev) => ({ ...prev, [photoId]: dataUrl }));
  }
  function deleteBatchPhoto(batchId, photoId) {
    setBatchPhotos((prev) => ({ ...prev, [batchId]: (prev[batchId] || []).filter((p) => p.id !== photoId) }));
    setPhotos((prev) => {
      const next = { ...prev };
      delete next[photoId];
      return next;
    });
    deleteKey(`photo:${photoId}`);
  }
  const [jumpToBatchId, setJumpToBatchId] = useState28(null);
  const [jumpToken, setJumpToken] = useState28(0);
  function jumpToBatch(batchId) {
    setTab("magazyn");
    setJumpToBatchId(batchId);
    setJumpToken((t) => t + 1);
  }
  function changeInventoryQty(plantId, container, nextVal) {
    const cur = Number(inventory[plantId]?.[container] || 0);
    const n = clampInt(nextVal, 0);
    if (n === cur) return;
    setInventory((prev) => ({ ...prev, [plantId]: { ...prev[plantId] || {}, [container]: n } }));
    pushLog(`${plantLabel(plantId)} \xB7 ${containerLabel(container)}: ${cur} \u2192 ${n} (${n - cur > 0 ? "+" : ""}${n - cur})`);
    const delta = n - cur;
    if (delta < 0) {
      let remaining = Math.abs(delta);
      let curBatches = batches, curSegments = batchSegments;
      const candidates = curSegments.filter((s) => s.plantId === plantId && s.container === container && s.status === "aktywny").sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
      for (const seg of candidates) {
        if (remaining <= 0) break;
        const take = Math.min(remaining, Number(seg.ilosc || 0));
        if (take <= 0) continue;
        const result = recordSegmentInventoryCorrection({
          batches: curBatches,
          segments: curSegments,
          segmentId: seg.id,
          stanSystemowy: seg.ilosc,
          stanFizyczny: Number(seg.ilosc || 0) - take,
          powod: "R\u0119czna korekta ilo\u015Bci (Ro\u015Bliny)"
        });
        if (result.ok) {
          curBatches = result.batches;
          curSegments = result.segments;
          remaining -= take;
        }
      }
      if (curBatches !== batches) setBatches(curBatches);
      if (curSegments !== batchSegments) setBatchSegments(curSegments);
    }
  }
  function recordLoss(data) {
    const typ = data.typ === "usuniecie" ? "usuniecie" : "strata";
    const n = clampInt(data.ilosc, 0);
    if (!data.plantId) {
      notify("Wybierz odmian\u0119.");
      return;
    }
    if (n <= 0) {
      notify("Podaj ilo\u015B\u0107 wi\u0119ksz\u0105 od zera.");
      return;
    }
    if (!data.powod || !String(data.powod).trim()) {
      notify("Podaj pow\xF3d.");
      return;
    }
    let segment = null;
    if (data.trackAsBatch) {
      if (!data.segmentId) {
        notify("Zaznaczy\u0142e\u015B \u015Bledzenie partii \u2014 wybierz rzeczywisty segment, albo odznacz \u015Bledzenie.");
        return;
      }
      segment = batchSegments.find((s) => s.id === data.segmentId);
      if (!segment) {
        notify("Nie znaleziono wybranego segmentu.");
        return;
      }
      if (n > Number(segment.ilosc || 0)) {
        notify(`Ilo\u015B\u0107 (${n}) przekracza stan segmentu (${segment.ilosc} szt.).`);
        return;
      }
    } else {
      const have = Number(inventory[data.plantId]?.[data.container] || 0);
      if (n > have) {
        notify(`Ilo\u015B\u0107 (${n}) przekracza dost\u0119pny stan (${have} szt.).`);
        return;
      }
    }
    const cur = Number(inventory[data.plantId]?.[data.container] || 0);
    const nextVal = Math.max(0, cur - n);
    setInventory((prev) => ({ ...prev, [data.plantId]: { ...prev[data.plantId] || {}, [data.container]: nextVal } }));
    const entry = { id: uid2("st"), typ, plantId: data.plantId, container: data.container, ilosc: n, powod: data.powod, komentarz: data.komentarz || null, data: data.data || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) };
    setLosses((prev) => [entry, ...prev]);
    pushLog(`${typ === "usuniecie" ? "Usuni\u0119cie" : "Strata"}: -${n} ${plantLabel(data.plantId)} (${containerLabel(data.container)}) \u2014 ${data.powod}`);
    if (data.trackAsBatch && segment) {
      const fn = typ === "usuniecie" ? recordSegmentRemoval : recordSegmentLoss;
      const result = fn({ batches, segments: batchSegments, segmentId: segment.id, ilosc: n, powod: data.powod, komentarz: data.komentarz || null });
      if (result.ok) {
        setBatches(result.batches);
        setBatchSegments(result.segments);
      } else {
        notify(`Nie uda\u0142o si\u0119 zaktualizowa\u0107 segmentu partii: ${result.error} (inventory zaktualizowane normalnie).`);
      }
    }
  }
  function deleteLoss(id) {
    setLosses((prev) => prev.filter((l) => l.id !== id));
  }
  function performInventoryCount({ plantId, container, trackAsBatch, segmentId, stanFizyczny, powod, kosztJednostkowy, location }) {
    if (!plantId) {
      notify("Wybierz odmian\u0119.");
      return;
    }
    if (!container) {
      notify("Wybierz pojemnik.");
      return;
    }
    const fizyczna = clampInt(stanFizyczny, 0);
    if (!powod || !String(powod).trim()) {
      notify("Podaj pow\xF3d inwentaryzacji.");
      return;
    }
    let segment = null;
    if (trackAsBatch) {
      if (!segmentId) {
        notify("Zaznaczy\u0142e\u015B \u015Bledzenie partii \u2014 wybierz rzeczywisty segment, albo odznacz \u015Bledzenie.");
        return;
      }
      segment = batchSegments.find((s) => s.id === segmentId);
      if (!segment) {
        notify("Nie znaleziono wybranego segmentu.");
        return;
      }
    }
    const systemowa = trackAsBatch && segment ? Number(segment.ilosc || 0) : Number(inventory[plantId]?.[container] || 0);
    const roznica = fizyczna - systemowa;
    if (roznica === 0) {
      notify("Brak r\xF3\u017Cnicy mi\u0119dzy stanem systemowym a fizycznym \u2014 nic do zatwierdzenia.");
      return;
    }
    if (roznica > 0) {
      const koszt = Math.max(0, Number(kosztJednostkowy || 0));
      if (koszt <= 0) {
        notify("Nadwy\u017Cka wymaga podania kosztu jednostkowego.");
        return;
      }
    }
    setInventory((prev) => {
      const row = { ...prev[plantId] || {} };
      row[container] = Math.max(0, Number(row[container] || 0) + roznica);
      return { ...prev, [plantId]: row };
    });
    if (roznica > 0) {
      const koszt = Math.max(0, Number(kosztJednostkowy || 0));
      const rawPriorQty = Number(inventory[plantId]?.[container] || 0);
      const rawPriorCost = Number(costs[plantId]?.[container] || 0);
      const newQty = rawPriorQty + roznica;
      setCosts((prev) => {
        const plantCosts = { ...prev[plantId] || {} };
        plantCosts[container] = Math.round((newQty > 0 ? (rawPriorQty * rawPriorCost + roznica * koszt) / newQty : koszt) * 100) / 100;
        return { ...prev, [plantId]: plantCosts };
      });
    }
    pushLog(`Inwentaryzacja ${plantLabel(plantId)} (${containerLabel(container)}): system ${systemowa} \u2192 fizyczny ${fizyczna} (${roznica > 0 ? "+" : ""}${roznica}). Pow\xF3d: ${powod}.`);
    const resultInfo = { stanSystemowy: systemowa, stanFizyczny: fizyczna, roznica, newBatch: null };
    if (roznica < 0 && trackAsBatch && segment) {
      const result = recordSegmentInventoryCorrection({ batches, segments: batchSegments, segmentId: segment.id, stanSystemowy: segment.ilosc, stanFizyczny: Number(segment.ilosc || 0) + roznica, powod });
      if (result.ok) {
        setBatches(result.batches);
        setBatchSegments(result.segments);
      } else {
        notify(`Nie uda\u0142o si\u0119 zaktualizowa\u0107 segmentu partii: ${result.error} (inventory zaktualizowane normalnie).`);
      }
    } else if (roznica > 0 && trackAsBatch) {
      const koszt = Math.max(0, Number(kosztJednostkowy || 0));
      const newBatch = createBatch({
        tenantId: DEFAULT_TENANT_ID,
        plantId,
        source: { type: "korekta", parentBatchId: null, parentSegmentId: null },
        initialQty: roznica,
        opis: `Nieznane pochodzenie / korekta inwentaryzacyjna: +${roznica} szt. ${containerLabel(container)}. Pow\xF3d: ${powod}.`,
        existingBatches: batches
      });
      const newSegment = createSegment({
        tenantId: DEFAULT_TENANT_ID,
        batchId: newBatch.id,
        plantId,
        container,
        location: location || null,
        ilosc: roznica,
        kosztJednostkowy: koszt,
        originEventOpis: `Nadwy\u017Cka inwentaryzacyjna: +${roznica} szt. Nieznane pochodzenie.`
      });
      setBatches((prev) => [...prev, newBatch]);
      setBatchSegments((prev) => [...prev, newSegment]);
      resultInfo.newBatch = { id: newBatch.id, ilosc: roznica };
    }
    return resultInfo;
  }
  function addCustomPlant(data) {
    const plant = {
      id: uid2("c"),
      lp: allPlants.length + 1,
      nazwa_pl: data.nazwa_pl.trim(),
      odmiana: data.odmiana.trim(),
      wys_szer: data.wys_szer.trim(),
      stanowisko: data.stanowisko.trim(),
      kwitnienie: data.kwitnienie.trim(),
      zimozielona: data.zimozielona,
      opis: data.opis.trim(),
      ciecie_text: data.ciecie_months.length ? `Ci\u0119cie: ${monthsToRomanText(data.ciecie_months)}` : "",
      podzial_text: data.podzial_months.length ? `Podzia\u0142: ${monthsToRomanText(data.podzial_months)}` : "",
      ciecie_months: data.ciecie_months,
      podzial_months: data.podzial_months,
      special: !!data.special,
      custom: true
    };
    setCustomPlants((prev) => [...prev, plant]);
    pushLog(`Dodano now\u0105 odmian\u0119: ${plant.nazwa_pl} (${plant.odmiana})`);
  }
  function removeCustomPlant(id) {
    const p = customPlants.find((pp) => pp.id === id);
    setCustomPlants((prev) => prev.filter((pp) => pp.id !== id));
    setPlantContainerSizes((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    if (p) pushLog(`Usuni\u0119to w\u0142asn\u0105 odmian\u0119: ${p.nazwa_pl}`);
  }
  function addClient(data) {
    const c = { id: uid2("cl"), nazwa: data.nazwa.trim(), telefon: (data.telefon || "").trim(), notatki: (data.notatki || "").trim(), createdAt: Date.now() };
    setClients((prev) => [c, ...prev]);
    pushLog(`Dodano klienta: ${c.nazwa}`);
  }
  function deleteClient(id) {
    const c = clients.find((cc) => cc.id === id);
    setClients((prev) => prev.filter((cc) => cc.id !== id));
    if (c) pushLog(`Usuni\u0119to klienta: ${c.nazwa}`);
  }
  function addSupply(data) {
    setSupplies((prev) => [...prev, { id: uid2("sup"), ...data }]);
    pushLog(`Dodano materia\u0142: ${data.nazwa}`);
  }
  function removeSupply(id) {
    const s = supplies.find((ss) => ss.id === id);
    if (s && s.typ === "donica" && s.rozmiar) {
      const stuck = Object.values(inventory).some((row) => Number(row?.[s.rozmiar] || 0) > 0);
      if (stuck) {
        notify(`Nie mo\u017Cna usun\u0105\u0107 \u201E${s.nazwa}\u201D \u2014 s\u0105 jeszcze ro\u015Bliny w tym rozmiarze (${s.rozmiar}) w magazynie.`);
        return;
      }
    }
    setSupplies((prev) => prev.filter((ss) => ss.id !== id));
    if (s) pushLog(`Usuni\u0119to materia\u0142: ${s.nazwa}`);
  }
  function changeSupplyQty(id, nextVal) {
    setSupplies((prev) => prev.map((s) => s.id === id ? { ...s, ilosc: clampInt(nextVal, 0) } : s));
  }
  function addOverheadCost(item) {
    setOverheadCosts((prev) => [item, ...prev]);
    pushLog(`Koszt sta\u0142y: +${item.nazwa} (${item.okres}, ${money(item.kwota)} z\u0142)`);
  }
  function deleteOverheadCost(id) {
    const it = overheadCosts.find((x) => x.id === id);
    setOverheadCosts((prev) => prev.filter((x) => x.id !== id));
    if (it) pushLog(`Usuni\u0119to koszt sta\u0142y: ${it.nazwa}`);
  }
  function createOrder(order) {
    setOrders((prev) => [order, ...prev]);
    pushLog(`Nowe zam\xF3wienie \u2014 ${order.klient}: ${money(order.suma)} z\u0142`);
  }
  function deleteOrderH(id) {
    const o = orders.find((oo) => oo.id === id);
    setOrders((prev) => prev.filter((oo) => oo.id !== id));
    if (o) pushLog(`Usuni\u0119to zam\xF3wienie \u2014 ${o.klient}`);
  }
  function sellFromSegments(plantId, container, qtyNeeded, unitCena, orderId) {
    let remaining = qtyNeeded;
    let curBatches = batches, curSegments = batchSegments;
    const candidates = curSegments.filter((s) => s.plantId === plantId && s.container === container && s.status === "aktywny").sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    for (const seg of candidates) {
      if (remaining <= 0) break;
      const take = Math.min(remaining, Number(seg.ilosc || 0));
      if (take <= 0) continue;
      const result = recordSegmentSale({ batches: curBatches, segments: curSegments, segmentId: seg.id, ilosc: take, cena: unitCena, orderId });
      if (result.ok) {
        curBatches = result.batches;
        curSegments = result.segments;
        remaining -= take;
      }
    }
    return { batches: curBatches, segments: curSegments };
  }
  function fulfillOrderH(order, deduct) {
    if (deduct) {
      let addNeed = function(plantId, container, qty) {
        need[plantId] = need[plantId] || {};
        need[plantId][container] = (need[plantId][container] || 0) + qty;
      };
      const need = {};
      order.pozycje.forEach((it) => {
        if (it.kind === "plant") {
          addNeed(it.plantId, it.container, Number(it.ilosc || 0));
        } else if (it.kind === "zestaw") {
          const z = zestawy.find((zz) => zz.id === it.zestawId);
          if (z) {
            z.pozycje.forEach((comp) => {
              addNeed(comp.plantId, comp.container, Math.round(Number(comp.ilosc || 0) * Number(it.ilosc || 0)));
            });
          }
        }
      });
      const shortages = [];
      Object.entries(need).forEach(([plantId, row]) => {
        Object.entries(row).forEach(([container, qty]) => {
          const have = Number(inventory[plantId]?.[container] || 0);
          if (qty > have) {
            shortages.push(`${plantLabel(plantId)} (${containerLabel(container)}): brakuje ${qty - have} szt.`);
          }
        });
      });
      if (shortages.length > 0) {
        notify(`Stan magazynowy ni\u017Cszy ni\u017C zam\xF3wienie \u2014 ${shortages.join("; ")}.`);
      }
      setInventory((prev) => {
        const next = { ...prev };
        order.pozycje.forEach((it) => {
          if (it.kind === "plant") {
            const row = { ...next[it.plantId] || {} };
            row[it.container] = Math.max(0, Number(row[it.container] || 0) - Number(it.ilosc || 0));
            next[it.plantId] = row;
          } else if (it.kind === "zestaw") {
            const z = zestawy.find((zz) => zz.id === it.zestawId);
            if (z) {
              z.pozycje.forEach((comp) => {
                const row = { ...next[comp.plantId] || {} };
                row[comp.container] = Math.max(0, Number(row[comp.container] || 0) - Math.round(Number(comp.ilosc || 0) * Number(it.ilosc || 0)));
                next[comp.plantId] = row;
              });
            }
          }
        });
        return next;
      });
      let curBatches = batches, curSegments = batchSegments;
      Object.entries(need).forEach(([plantId, row]) => {
        Object.entries(row).forEach(([container, qty]) => {
          const hasAnySegment = curSegments.some((s) => s.plantId === plantId && s.container === container && s.status === "aktywny");
          if (!hasAnySegment) return;
          const it = order.pozycje.find((p) => p.kind === "plant" && p.plantId === plantId && p.container === container);
          const unitCena = it ? Number(it.cena || 0) : null;
          const r = sellFromSegments(plantId, container, qty, unitCena, order.id);
          curBatches = r.batches;
          curSegments = r.segments;
        });
      });
      if (curBatches !== batches) setBatches(curBatches);
      if (curSegments !== batchSegments) setBatchSegments(curSegments);
    }
    setOrders((prev) => prev.map((o) => o.id === order.id ? { ...o, status: "zrealizowane" } : o));
    pushLog(deduct ? `Zrealizowano zam\xF3wienie \u2014 ${order.klient} (odj\u0119to ${money(order.suma)} z\u0142 ze stanu)` : `Zrealizowano zam\xF3wienie \u2014 ${order.klient} (bez zmiany stanu)`);
  }
  function buildBackupJson() {
    const payload = {
      inventory,
      cennik,
      zamowienia: orders,
      "schedule-done": done,
      "custom-tasks": customTasks,
      zestawy,
      photos,
      "custom-plants": customPlants,
      clients,
      losses,
      log,
      supplies,
      "pot-sizes": potSizes,
      "plant-container-sizes": plantContainerSizes,
      "pot-recipes": potRecipes,
      "substrate-cost-per-l": substrateCostPerL,
      koszty: costs,
      "tasks-general": tasks,
      "overhead-costs": overheadCosts,
      batches,
      "batch-segments": batchSegments,
      "production-plans": productionPlans,
      "batch-photos": batchPhotos,
      "piorin-number": piorinNumber,
      "origin-country": originCountry,
      "thermal-label-size": thermalLabelSize,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    return JSON.stringify(payload, null, 2);
  }
  function handleExport() {
    try {
      const blob = new Blob([buildBackupJson()], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `szkolka-traw-kopia-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
    }
  }
  function applyImportText(text) {
    try {
      const data = JSON.parse(text);
      if (!data || typeof data !== "object" || Array.isArray(data)) {
        notify("To nie wygl\u0105da na poprawn\u0105 kopi\u0119 zapasow\u0105 szk\xF3\u0142ki.");
        return false;
      }
      const hasKnownField = KNOWN_IMPORT_KEYS.some((k) => Object.prototype.hasOwnProperty.call(data, k));
      if (!hasKnownField) {
        notify("Brak rozpoznawalnych danych szk\xF3\u0142ki \u2014 import przerwany.");
        return false;
      }
      if (data.inventory) setInventory(data.inventory);
      if (data.cennik) setCennik(data.cennik);
      if (data.zamowienia) setOrders(data.zamowienia);
      if (data["schedule-done"]) setDone(data["schedule-done"]);
      if (data["custom-tasks"]) setCustomTasks(data["custom-tasks"]);
      if (data.zestawy) setZestawy(data.zestawy);
      if (data.photos) {
        setPhotos(data.photos);
        Object.entries(data.photos).forEach(([id, dataUrl]) => saveKey(`photo:${id}`, dataUrl));
      }
      if (data["custom-plants"]) setCustomPlants(data["custom-plants"]);
      if (data.clients) setClients(data.clients);
      if (data.losses) setLosses(data.losses);
      if (data.log) setLog(data.log);
      if (data.supplies) {
        const { supplies: migratedImportedSupplies } = migrateSupplies(data.supplies, data["pot-sizes"] || []);
        setSupplies(migratedImportedSupplies);
      }
      if (data["plant-container-sizes"]) setPlantContainerSizes(data["plant-container-sizes"]);
      if (data["pot-recipes"]) setPotRecipes(data["pot-recipes"]);
      if (data["substrate-cost-per-l"] !== void 0) setSubstrateCostPerL(data["substrate-cost-per-l"]);
      if (data.koszty) setCosts(data.koszty);
      if (data["tasks-general"]) setTasks(data["tasks-general"]);
      if (data["overhead-costs"]) setOverheadCosts(data["overhead-costs"]);
      if (data["production-plans"]) setProductionPlans(data["production-plans"]);
      if (data["batch-photos"]) setBatchPhotos(data["batch-photos"]);
      if (data["piorin-number"] !== void 0) setPiorinNumber(data["piorin-number"]);
      if (data["origin-country"]) setOriginCountry(data["origin-country"]);
      if (data["thermal-label-size"]) setThermalLabelSize(data["thermal-label-size"]);
      if (data.batches && data["batch-segments"]) {
        setBatches(data.batches);
        setBatchSegments(data["batch-segments"]);
      }
      pushLog("Przywr\xF3cono dane z kopii zapasowej.");
      notify("Kopia zapasowa wczytana.", "success");
      return true;
    } catch (err) {
      notify("Nieprawid\u0142owy tekst kopii zapasowej.");
      return false;
    }
  }
  async function handleImport(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    const text = await file.text();
    applyImportText(text);
  }
  return /* @__PURE__ */ React.createElement("div", { className: "app-shell" }, /* @__PURE__ */ React.createElement(GlobalStyle, null), /* @__PURE__ */ React.createElement(Header, { tab, potsTotal }), /* @__PURE__ */ React.createElement("main", { className: "app-content" }, !ready ? /* @__PURE__ */ React.createElement("div", { className: "loading" }, "Wczytywanie danych\u2026") : tab === "pulpit" ? /* @__PURE__ */ React.createElement(
    PulpitTab,
    {
      plants: allPlants,
      inventory,
      potsTotal,
      magazynValue,
      salesValue,
      orders,
      done,
      customTasks,
      log,
      supplies,
      tasks,
      onAddTask: addTask,
      onCycleTask: cycleTaskStatus,
      onDeleteTask: deleteTask,
      onNavigate: setTab,
      onExport: handleExport,
      onImport: handleImport,
      onGetBackupText: buildBackupJson,
      onImportText: applyImportText,
      batches,
      onJumpToBatch: jumpToBatch,
      batchSegments,
      productionPlans
    }
  ) : tab === "magazyn" ? /* @__PURE__ */ React.createElement(
    MagazynTab,
    {
      plants: allPlants,
      inventory,
      onQtyChange: changeInventoryQty,
      totals,
      containers,
      potSizes,
      onAddPotSize: addPotSize,
      plantContainerSizes,
      onTogglePlantContainer: togglePlantContainer,
      photos,
      setPhotos,
      onPhotoError: () => notify("Nie uda\u0142o si\u0119 zapisa\u0107 zdj\u0119cia \u2014 spr\xF3buj mniejsze/inne zdj\u0119cie."),
      onAddPlant: addCustomPlant,
      onRemovePlant: removeCustomPlant,
      supplies,
      onSupplyQtyChange: changeSupplyQty,
      onAddSupply: addSupply,
      onRemoveSupply: removeSupply,
      losses,
      onAddLoss: recordLoss,
      onDeleteLoss: deleteLoss,
      cennik,
      log,
      costs,
      potRecipes,
      substrateCostPerL,
      onSetPotRecipe: setPotRecipe,
      onSetSubstrateCostPerL: setSubstrateCostPerL,
      onPerformDivision: performDivision,
      onSettleDivision: settleAsDivision,
      onPerformPurchase: performPurchase,
      onPerformTransplant: performTransplant,
      onPerformInventoryCount: performInventoryCount,
      batchSegments,
      batches,
      onSetSegmentQuality: setSegmentQualityH,
      productionPlans,
      onAddPlan: addProductionPlan,
      onSetPlanStatus: setPlanStatusH,
      onDeletePlan: deleteProductionPlan,
      batchPhotos,
      onAddBatchPhoto: addBatchPhoto,
      onDeleteBatchPhoto: deleteBatchPhoto,
      jumpToBatchId,
      jumpToken,
      overheadCosts,
      onAddOverheadCost: addOverheadCost,
      onDeleteOverheadCost: deleteOverheadCost
    }
  ) : tab === "harmonogram" ? /* @__PURE__ */ React.createElement(
    HarmonogramTab,
    {
      plants: allPlants,
      done,
      setDone,
      customTasks,
      setCustomTasks,
      tasks,
      onCycleTask: cycleTaskStatus,
      batchSegments,
      batches
    }
  ) : tab === "sprzedaz" ? /* @__PURE__ */ React.createElement(
    SprzedazTab,
    {
      plants: allPlants,
      potSizes,
      plantContainerSizes,
      cennik,
      setCennik,
      costs,
      onSetCost: setCost,
      orders,
      onCreateOrder: createOrder,
      onDeleteOrder: deleteOrderH,
      onFulfillOrder: fulfillOrderH,
      zestawy,
      setZestawy,
      clients,
      onAddClient: addClient,
      onDeleteClient: deleteClient,
      overheadCosts,
      batchSegments,
      batches
    }
  ) : /* @__PURE__ */ React.createElement(
    EtykietyTab,
    {
      plants: allPlants,
      inventory,
      potSizes,
      batchSegments,
      batches,
      piorinNumber,
      setPiorinNumber,
      originCountry,
      setOriginCountry,
      thermalLabelSize,
      setThermalLabelSize
    }
  )), /* @__PURE__ */ React.createElement(BottomNav, { tab, setTab }), toast && /* @__PURE__ */ React.createElement("div", { className: `toast ${toast.type === "success" ? "success" : ""}` }, /* @__PURE__ */ React.createElement(AlertCircle2, { size: 15 }), " ", toast.msg));
}
export {
  App as default
};
